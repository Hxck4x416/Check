from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi

# URI proporcionada, recuerda reemplazar <db_password> por la contraseña real
uri = "mongodb://root:Wn85ALVOxOI8zcyN@chk-shard-00-00.g4asm.mongodb.net:27017,chk-shard-00-01.g4asm.mongodb.net:27017,chk-shard-00-02.g4asm.mongodb.net:27017/?ssl=true&replicaSet=atlas-f0fp58-shard-0&authSource=admin&retryWrites=true&w=majority&appName=chk"

# Crear un nuevo cliente y conectarse al servidor
client = MongoClient(uri, server_api=ServerApi('1'))

# Intentar enviar un ping para confirmar la conexión
try:
    client.admin.command('ping')
    print("Conectado a MongoDB!")
except Exception as e:
    print("Error:", e)

# Acceder a la base de datos y colecciones
database = client['users']
collection = database['usuarios']
collection_dos = database['keys']
collection_tres = database['groups']
collection_cuatro = database['gates']
collection_bin = database['bins']
collection_bot = database['bot']

# Aquí puedes realizar las operaciones necesarias con las colecciones


