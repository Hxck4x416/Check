import logging
from pyrogram import Client, filters

# Configura el logging
logging.basicConfig(level=logging.INFO, filename='bot_logs.txt', format='%(asctime)s - %(message)s')

@Client.on_message(filters.all)
async def log_message(client, message):
    logging.info(f"User {message.from_user.id} sent a message: {message.text}")