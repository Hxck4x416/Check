import time
from pyrogram import Client
from pyrogram import filters
import re
from gates.functions.func_bin import get_bin_info
from mongoDB import *
import requests
from datetime import datetime



@Client.on_message(filters.command(['bin'], prefixes=['/', ',', '.', '!', '$', '-']))
async def bin_autoregidtro(_, message):
    try:
        user_id = message.from_user.id
        find = collection.find_one({"_id": message.from_user.id})
        if find is None:
            mydict = {
                "_id": user_id,
                "id": user_id,
                "username": message.from_user.username,
                "plan": "FreeUser",
                "role": "User",
                "roles": "User",
                "apodo": "Ninguno",
                "status": "Activo",
                "credits": 0,
                "antispam": 50,
                "time_user": 0,
                "since": datetime.now(),
                "key": 'None',
            }
            collection.insert_one(mydict)
            text = f'''
<b>Te Registrarte Correctamente
TUS DATOS:
ID: <code>{message.from_user.id}</code>
Name: <code>{message.from_user.username}</code>
Plan: <code>Free User</code>
Creditos: <code>0</code>
Antispam: <code>50</code></b>ㅤ
'''
            url = 'https://pa1.aminoapps.com/6312/482027c4cf2646c2e8af99c7484f5326c69dcdce_hq.gif'
            await message.reply_animation(animation=url, caption=text, quote=True)
        else:
            await bin(_, message)
    except Exception as e:
        print(e)

@Client.on_message(filters.command('bin',prefixes=['.','/','!','?']))
async def bin(_,message):
    tiempo= time.perf_counter()
    encontrar_usuario = collection.find_one({"_id": message.from_user.id})
    if encontrar_usuario is None: return await message.reply(text='<b>Hey, no estás registrado, usa el comando <code>$register</code></b>',quote=True)

    if encontrar_usuario["role"] == "ban":
         return await message.reply('<i>User Ban! </i>',quote=True)
    encontrar_grupo = collection_tres.find_one({"group": str(message.chat.id)})

    if encontrar_usuario['key'] != 'None' or encontrar_grupo != None:
        if encontrar_usuario['key'] != 'None':
            if encontrar_usuario["key"] < datetime.now():            
                collection.update_one({"_id": message.from_user.id},{"$set": {"key": 'None'}})
                collection.update_one({"_id": message.from_user.id},{"$set": {"antispam": 50}})
                collection.update_one({"_id": message.from_user.id},{"$set": {"plan": 'Free User'}})
                return await message.reply(text='<b>Membresía Premium Finalizada! ❌</b>',quote=True)
        elif encontrar_grupo["key"] < datetime.now():
            collection_tres.delete_one({"group": str(message.chat.id)})

    else: return await message.reply(text='<i>Hola, este grupo o chat no se encuentran autorizados para el uso de este bot</i>',quote=True)
    BIN = message.text[len("/bin"): 11]

    if len(BIN) < 6:
            return await message.reply("<b>Error, use <code>$bin 434769xxxxx|rnd|rnd|rnd</code></b>")
    if not BIN:
            return await message.reply("<b>Error, use <code>$bin 434769xxxxx|rnd|rnd|rnd</code></b>")
    inputm = message.text.split(None, 1)[1]
    bincode = 6
    BIN = inputm[:bincode]
    user = message.from_user.username
    x = get_bin_info(BIN)
    tiempofinal = time.perf_counter()  

    await message.reply_text(f"""<i><b>
━━━━━━༺༻ ━━━━━━
⚘ Bin ➤ <code>{BIN}</code>
⚘ Info ➤ <code>{x.get("vendor")} - {x.get("type")} - {x.get("level")}</code>
⚘ Bank ➤ <code>{x.get("bank_name")} </code>
⚘ Country ➤ <code>{x.get("country")} {x.get("flag")}</code>
━━━━━━༺༻ ━━━━━━ 
⚘ Time ➤ {tiempofinal - tiempo:0.2}
⚘ Bin By ➤ @{user} [{encontrar_usuario['plan']}]
</i></b>""")



