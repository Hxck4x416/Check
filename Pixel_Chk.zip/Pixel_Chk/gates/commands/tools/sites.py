from pyrogram import Client, filters
import socket
import requests
from bs4 import BeautifulSoup

# Clase para verificar la información del sitio
class SiteSecurityChecker:
    def __init__(self, domain):
        self.domain = domain

    async def check_ip_range(self):
        try:
            ip_addresses = socket.gethostbyname_ex(self.domain)[-1]
            for ip in ip_addresses:
                if ip.startswith("104."):
                    return True
            return False
        except socket.gaierror:
            return False

    async def check_dns(self):
        try:
            resolved_ips = socket.gethostbyname_ex(self.domain)[-1]
            for ip in resolved_ips:
                if ip.startswith("172.") or ip.startswith("198.") or ip.startswith("199."):
                    return True
            return False
        except socket.gaierror:
            return False

    async def is_using_cloudflare(self):
        if await self.check_ip_range() or await self.check_dns():
            return True
        return False

    async def has_captcha_protection(self):
        response = requests.get(f"{self.domain}")
        soup = BeautifulSoup(response.text, "html.parser")

    # Identificar elementos específicos de la página que sugieran un tipo de CAPTCHA
        if soup.find("div", {"class": "g-recaptcha"}):
            return "reCAPTCHA."
        elif soup.find("div", {"class": "h-captcha"}):
            return "HCAPTCHA."
        elif soup.find("input", {"type": "hidden", "name": "recaptcha_response_field"}):
            return "CAPTCHA personalizado"
        else:
            return "No se pudo identificar el tipo de CAPTCHA"

    async def get_server_type(self):
         try:
             response = requests.head(f"{self.domain}")
             protecciones = response.headers.get('Server')
             return protecciones
         except requests.exceptions.RequestException as e:
             return "Error al realizar la solicitud: " + str(e)

# Inicializar el bot con tu API_ID y API_HASH

# Comando /site
@Client.on_message(filters.command(['sites', 'site', 'web'], prefixes=['/', ',', '.', '!', '$', '-']))
async def check_site_info(client, message):
    # Extraer el argumento del mensaje después del comando
    if len(message.command) != 2:
        await message.reply("Debes proporcionar un sitio web después del comando.")
        return

    domain = message.command[1]
    checker = SiteSecurityChecker(domain)

    cloudflare_result = "SI" if await checker.is_using_cloudflare() else "NO"
    captcha_type = await checker.has_captcha_protection()
    server_type = await checker.get_server_type()

    reply_message = f"""<b>
    <i>Información del sitio: <code></i>{domain}</code>
    -
    <i>Usa Cloudflare: </i>{cloudflare_result}
    -
    <i>Tipo de CAPTCHA: </i>{captcha_type}
    -
    <i>Tipo de servidor web:</i> {server_type}</b>"""

    await message.reply_text(reply_message)
    

# Definir y ejecutar el bucle de eventos asincrónico

