import requests
from asyncio import sleep
from pyrogram import Client, filters
from pyrogram.types import (
    Message,
    InlineKeyboardButton,
    InlineKeyboardMarkup
)

API_URL = 'https://randomuser.me/api/1.2/?nat'

@Client.on_message(filters.command(["rnd"], ["/", "."]))
async def rnd(_, m: Message):
    
    rnd = m.text[len("/rnd"):]
    if not rnd:
        await m.reply("Use de /rnd US")
    
    spli = rnd.split()
    rnd = spli[0]

    data = requests.get(f'https://randomuser.me/api/1.2/?nat=<code>{rnd}</code>').json()
#CAPTURAS
#data = /rnd["data"]
    user_data = data['results'][0]
    street = user_data['location']['street']
    city = user_data['location']['city']
    state = user_data['location']['state']
    phone = user_data['phone']
    name = user_data['name']['first']
    last = user_data['name']['last']
    postcode = user_data['location']['postcode']
    ssn = user_data['id']['value']
    cell = user_data['cell']
    country = user_data['location']['city']


    edit1 = await m.reply_text("<b>Buscando Infomaciones.</b>")
    await sleep(1.5)
    
    await edit1.edit(f"""<b>Random Adress Generator
━━━━━━━━━━━━━
➤ †| Street Address: <code>{street}</code>
➤ †| Name: <code>{name}</code>
➤ †| Last Name: <code>{last}</code>
➤ †| City: <code>{city}</code>
➤ †| State: <code>{state}</code>
➤ †| ZipCode: <code>{postcode}</code>
➤ †| SSN: <code>{ssn}</code>
➤ †| Phone Number: <code>{phone}</code>
➤ †| Cell Number: <code>{cell}</code>
➤ †| Country: <code>{country}</code></b>""")
    