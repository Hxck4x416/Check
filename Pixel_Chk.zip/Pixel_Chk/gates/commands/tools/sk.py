import json
import requests
import time
import asyncio
from asyncio import sleep
from pyrogram import Client, filters                         # aqui dice que de configs importe lan classe config
from pyrogram.types import (
    Message,
    InlineKeyboardButton,
    InlineKeyboardMarkup
)

@Client.on_message(filters.command('sk',prefixes=['.','!','/',',','-','$','%','#']))
async def chk(_, m: Message):
    tic = time.perf_counter()
    user = m.text[len('/sk '):]
    fg = user[0:10]
    kg = user[-6:]
    tiempoinicio = time.perf_counter()
    tiempofinal = time.perf_counter()
    password = ""
    if not user:
        await m.reply("""<b>[✅] SK → [FREE]
[☇] Info → SK BALANCE LOOKUP
[☇] Format → <code>/sk sk_live_11Kj9dqULiCDAN3LT9ZoVhTx</code></b>""")

    cc = "4543218722787334"
    cvc = "780"
    mes = "07"
    ano = "2026"

    headers = {
        "Content-Type": "application/x-www-form-urlencoded"
    }

    data = {
        "card[number]": cc,
        "card[cvc]": cvc,
        "card[exp_month]": mes,
        "card[exp_year]": ano
    }

    url1 = requests.post(f"https://api.stripe.com/v1/tokens", data=data, headers=headers, auth=(user, ""))
    
    url2 = 'https://api.stripe.com/v1/balance'
    re = requests.get(url2, auth=(user, password))
    #res = re.text
    jee = re.json()
    blnc = jee["pending"]
    for blc in blnc:
     amt = blc["amount"]
     curr = blc["currency"]
    toc = time.perf_counter()

    if 'Invalid API Key provided' in url1.text:
        await m.reply(f"""<b>
𝙎𝙠:  <code>{user}</code>
𝙎𝙩𝙖𝙩𝙪𝙨:  Dead 
𝙍𝙚𝙨𝙪𝙡𝙩:  Invalid API Key provided

𝙂𝙖𝙩𝙚𝙬𝙖𝙮𝙨: SK BALANCE LOOKUP
𝘾𝙝𝙚𝙘𝙠𝙚𝙙 𝙗𝙮: <code>@{m.from_user.username}</code> 
</b>""")


    elif 'api_key_expired' in url1.text:
        await m.reply(f"""<b>
𝙎𝙠:  <code>{user}</code>
𝙎𝙩𝙖𝙩𝙪𝙨:  Dead 
𝙍𝙚𝙨𝙪𝙡𝙩:  api_key_expired

𝙂𝙖𝙩𝙚𝙬𝙖𝙮𝙨: SK BALANCE LOOKUP
𝘾𝙝𝙚𝙘𝙠𝙚𝙙 𝙗𝙮: <code>@{m.from_user.username}</code>
</b>""")
    elif 'testmode_charges_only' in url1.text:
        await m.reply(f"""<b>
𝙎𝙠:  <code>{user}</code>
𝙎𝙩𝙖𝙩𝙪𝙨:  Dead 
𝙍𝙚𝙨𝙪𝙡𝙩:  testmode_charges_only

𝙂𝙖𝙩𝙚𝙬𝙖𝙮𝙨: SK BALANCE LOOKUP
𝘾𝙝𝙚𝙘𝙠𝙚𝙙 𝙗𝙮: <code>@{m.from_user.username}</code> 
</b>""")





    elif 'test_mode_live_card' in url1.text:
        await m.reply(f"""<b>
𝙎𝙠:  <code>{user}</code>
𝙎𝙩𝙖𝙩𝙪𝙨:  Dead 
𝙍𝙚𝙨𝙪𝙡𝙩:  test_mode_live_card

𝙂𝙖𝙩𝙚𝙬𝙖𝙮𝙨: SK BALANCE LOOKUP
𝘾𝙝𝙚𝙘𝙠𝙚𝙙 𝙗𝙮: <code>@{m.from_user.username}</code> 
</b>""")


    elif 'Your card was declined.' in url2:
        await m.reply(f"""<b>
𝙎𝙠:  <code>{user}</code>
𝙎𝙩𝙖𝙩𝙪𝙨:  Live! ✅
𝙍𝙚𝙨𝙪𝙡𝙩:  Rate Limit 50%!

𝘼𝙢𝙤𝙪𝙣𝙩:  ${amt}
𝘾𝙪𝙧𝙧𝙚𝙣𝙘𝙮: {curr}

𝙂𝙖𝙩𝙚𝙬𝙖𝙮𝙨: SK BALANCE LOOKUP
𝘾𝙝𝙚𝙘𝙠𝙚𝙙 𝙗𝙮: <code>@{m.from_user.username}</code> 
</b>
""")
    elif 'card_error' in url2:
        await m.reply(f"""<b>
𝙎𝙠:  <code>{user}</code>
𝙎𝙩𝙖𝙩𝙪𝙨:  Live! ✅
𝙍𝙚𝙨𝙪𝙡𝙩:  Rate Limit 100%!

𝘼𝙢𝙤𝙪𝙣𝙩:  ${amt}
𝘾𝙪𝙧𝙧𝙚𝙣𝙘𝙮: {curr}

𝙂𝙖𝙩𝙚𝙬𝙖𝙮𝙨: SK BALANCE LOOKUP
𝘾𝙝𝙚𝙘𝙠𝙚𝙙 𝙗𝙮: <code>@{m.from_user.username}</code> 
</b>""")





    else:
        await m.reply(f"""<b>
𝙎𝙠:  <code>{user}</code>
𝙎𝙩𝙖𝙩𝙪𝙨:  Live! ✅
𝙍𝙚𝙨𝙪𝙡𝙩:  Rate Limit!

𝘼𝙢𝙤𝙪𝙣𝙩:  ${amt}
𝘾𝙪𝙧𝙧𝙚𝙣𝙘𝙮: {curr}
𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲: Succeeded ✅

𝙂𝙖𝙩𝙚𝙬𝙖𝙮𝙨: SK BALANCE LOOKUP
𝘾𝙝𝙚𝙘𝙠𝙚𝙙 𝙗𝙮: <code>@{m.from_user.username}</code> 
</b>""")


    


  