from datetime import datetime
from luhn import *
from pyrogram.types import *
import time
from pyrogram import Client
from pyrogram import filters
import re
from pyrogram import enums
from gates.functions.func_bin import get_bin_info
from mongoDB import *
import requests
from datetime import datetime

@Client.on_message(filters.command(['gen'], prefixes=['/', ',', '.', '!', '$', '-']))
async def genccs(_, msg):
    tiempo= time.perf_counter()  
    await msg.reply_chat_action(enums.ChatAction.TYPING)
    encontrar_usuario = collection.find_one({"_id": msg.from_user.id})
    if encontrar_usuario is None: return await msg.reply(text='<b>Por favor registrate con el comando <code>!register</code></b>',quote=True)
    
    if encontrar_usuario["role"] == "ban":
        return await msg.reply('<i>User Ban! </i>',quote=True)
    
    bin_prohibido=['1','2','7','8','9']
    
    
    encontrar_grupo = collection_tres.find_one({"group": str(msg.chat.id)})

    if encontrar_usuario['key'] != 'None' or encontrar_grupo != None:
        if encontrar_usuario['key'] != 'None':
            if encontrar_usuario["key"] < datetime.now():            
                collection.update_one({"_id": msg.from_user.id},{"$set": {"key": 'None'}})
                collection.update_one({"_id": msg.from_user.id},{"$set": {"antispam": 50}})
                collection.update_one({"_id": msg.from_user.id},{"$set": {"plan": 'Free'}})
                return await msg.reply(text='<b>Suscripcion premium Concluida!</b>',quote=True)
        elif encontrar_grupo["key"] < datetime.now():
            collection_tres.delete_one({"group": str(msg.chat.id)})

        else: return await msg.reply(text='<b>Suscripcion premium Concluida o no activa.</b>',quote=True)
        user = msg.from_user.username
        
    
        ccbin = msg.text[len('/gen '):]
        if not ccbin: return await msg.reply('<i>Invalid Bin! ⚠️</i>',quote=True)
        if len(str(ccbin)) < 6: return await msg.reply('<i>Invalid Bin! ⚠️</i>',quote=True)

        geneo = re.findall(r'[0-9]+',msg.text)
        if not geneo: return await msg.reply('<i>Invalid Bin! ⚠️</i>',quote=True)
        
        else:
            if len(geneo) == 1:
                cc = geneo[0]
                mes = 'x'
                ano = 'x'
                cvv = 'x'
            elif len(geneo) ==2:
                cc = geneo[0]
                mes = geneo[1]
                ano = 'x'
                cvv = 'x'
            elif len(geneo) ==3:
                cc = geneo[0]
                mes = geneo[1]
                ano = geneo[2]
                cvv = 'x'
            elif len(geneo) ==4:
                cc = geneo[0]
                mes = geneo[1]
                ano = geneo[2]
                cvv = geneo[3]
            else:
                cc = geneo[0]
                mes = geneo[1]
                ano = geneo[2]
                cvv = geneo[3]
            
            if cc[0] in bin_prohibido: return await msg.reply('<i>Invalid Bin! ⚠️</i>',quote=True)    
            x = get_bin_info(ccbin[0:6])

            cc1,cc2,cc3,cc4,cc5,cc6,cc7,cc8,cc9,cc10, = cc_gen(cc,mes,ano,cvv)
            
            extra = str(cc) + 'xxxxxxxxxxxxxxxxxxxxxxx'
            if mes == 'x':
             mes_2 = 'rnd'
            else:
             mes_2 = mes
            if ano == 'x':
             ano_2 = 'rnd'
            else:
             ano_2 = ano
            if cvv == 'x':
             cvv_2 = 'rnd'
            else:
             cvv_2 = cvv

            
            reply_markup = InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton( 
                            "Re Gen🔄",
                            callback_data="gen_pro"
                        ),
                        InlineKeyboardButton( 
                            "Re Gen Mass🔄",
                            callback_data="genm_pro"
                        ),
                    
                    ],
                ]
            )
            
        tiempofinal = time.perf_counter()
    
        text = f"""<b>
ϟ 𝙂𝙚𝙣𝙚𝙧𝙖𝙩𝙤𝙧 𝘾𝙖𝙧𝙙𝙨 ϟ
━━━━━━༺༻ ━━━━━━
⚘ Bin ➤ <code>{cc[0:6]}</code>
⚘ Info ➤ <code>{x.get("vendor")} - {x.get("type")} - {x.get("level")}</code>
⚘ Bank ➤ <code>{x.get("bank_name")} </code>
⚘ Country ➤ <code>{x.get("country")} {x.get("flag")}</code>
━━━━━━༺༻ ━━━━━━
<code>{cc1}</code>
<code>{cc2}</code>  
<code>{cc3}</code>
<code>{cc4}</code> 
<code>{cc5}</code>
<code>{cc6}</code>
<code>{cc7}</code>
<code>{cc8}</code>
<code>{cc9}</code>
<code>{cc10}</code>
━━━━━━༺༻ ━━━━━━ 
⚘ Time ➤ {tiempofinal - tiempo:0.2}
⚘ Gen By ➤ @{user} [{encontrar_usuario['plan']}]
</b>"""
    
        return await Client.send_message(_,chat_id=msg.chat.id,text=text,reply_to_message_id=msg.id,reply_markup=reply_markup)