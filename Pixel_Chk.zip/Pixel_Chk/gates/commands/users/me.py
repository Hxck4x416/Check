from pyrogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup
)
from pyrogram import (
    Client,
    filters
)
from pymongo.errors import *
from mongoDB import *
import os
from pyrogram import enums
from datetime import datetime
import locale
from datetime import timedelta


@Client.on_message(filters.command(['me'], prefixes=['/', ',', '.', '!', '$', '-']))
async def me(_,message):
    await message.reply_chat_action(enums.ChatAction.TYPING)
    
    encontrar_usuario = collection.find_one({"_id": message.from_user.id})
    if encontrar_usuario is None: return await message.reply(text='<b>Hey, no estás registrado, usa el comando <code>$register</code></</b>',quote=True)
    
    creditos = encontrar_usuario["credits"]
    
    id_usuario = encontrar_usuario["_id"]
    user_name = encontrar_usuario["username"]
    plan = encontrar_usuario["plan"]
    antispam = encontrar_usuario["antispam"]
    role = encontrar_usuario["role"]
    key_ = encontrar_usuario["key"]
    if key_ != 'None':
        key_ = key_.strftime('%d %B %X')
    else:
        key_ = 'None.'
        
    caption = f"""<i>      
━━━━━━━━━━━━━━━━━━━
⚘ User Id ➤ <code>{message.from_user.id}</code>
⚘ UserName ➤ <code>@{message.from_user.username}</code>
⚘ Plan ➤ {plan}
⚘ Role ➤ {role}
⚘ AntiSpam ➤ {antispam}
⚘ Creditos ➤ {creditos}
⚘ Key ➤ {key_}
━━━━━━━━━━━━━━━━━━━
</i>"""
    reply_markup = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton(
                    "Atras",
                    callback_data="start"
                ),
        ]
        ]
    )


    await message.reply(caption,reply_markup=reply_markup,quote=True)

        