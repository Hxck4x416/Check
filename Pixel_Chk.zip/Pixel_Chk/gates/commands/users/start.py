from pyrogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup
)
from pyrogram import (
    Client,
    filters
)
from pymongo.errors import *
from mongoDB import *
import os
from datetime import datetime
import locale
from datetime import timedelta


@Client.on_message(filters.command(['start'], prefixes=['/', ',', '.', '!', '$', '-']))
async def Start(_, message):
    try:
        user_id = message.from_user.id
        find = collection.find_one({"_id": user_id})
        if not find:
            user_data = {
                "_id": user_id,
                "id": user_id,
                "username": message.from_user.username,
                "plan": "FreeUser",
                "role": "User",
                "roles": "User",
                "apodo": "Ninguno",
                "status": "Activo",
                "credits": 0,
                "antispam": 50,
                "time_user": 0,
                "since": datetime.now(),
                "key": 'None',
            }
            collection.insert_one(user_data)
            caption = f'''
<b>Te Registrarte Correctamente
TUS DATOS:
ID: <code>{message.from_user.id}</code>
Name: <code>{message.from_user.username}</code>
Plan: <code>Free User</code>
Creditos: <code>0</code>
Antispam: <code>50</code></b>
'''
            url = 'https://imgur.com/krMbGcV.gif'
            await Client.send_video(_,video='https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExMGEwMzBjeDl3YWc5dDNldWc4cGN0Y3ZvcHN1MzZhOTA4M3NwcXZraSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/aHHMrXxsR3liFiAYiL/source.gif',chat_id=message.chat.id,caption=caption,reply_to_message_id=message.id, reply_markup=reply_markup)
        else:
            caption = f'''<b>Bienvenido a Hxck Chk Puedes iniciarme usando /cmds
</b>'''

            botones = [
                [
                    InlineKeyboardButton("𝙂𝙖𝙩𝙚𝙬𝙖𝙮𝙨", callback_data='gates'),
                    InlineKeyboardButton("𝙏𝙤𝙤𝙡𝙨", callback_data='tools'),
                ],
                [

                ],

                [

                    InlineKeyboardButton('Perfil', callback_data='user_perfil'),
                ]
            ]
            reply_markup = InlineKeyboardMarkup(botones)

            await Client.send_video(_,video='https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExMGEwMzBjeDl3YWc5dDNldWc4cGN0Y3ZvcHN1MzZhOTA4M3NwcXZraSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/aHHMrXxsR3liFiAYiL/source.gif',chat_id=message.chat.id,caption=caption,reply_to_message_id=message.id, reply_markup=reply_markup)
    except Exception as e:
        print(e)