from pyrogram import (
    Client,
    filters
)
from pyrogram.types import (
    Message,
    InlineKeyboardMarkup, 
    InlineKeyboardButton)
from pymongo.errors import *
from mongoDB import *
import os
from datetime import datetime
import locale
from datetime import timedelta
import time
            
@Client.on_message(filters.command('register',prefixes=['/',',','.','!','$','-']))
async def register(_,message):
    try:
        find = collection.find_one({"_id": message.from_user.id})
        if find is None:
                            
            mydict = {
            "_id": message.from_user.id,
            "username": message.from_user.username,
            "plan": "FreeUser",
            "role": "User",
            "credits": 0,
            "antispam": 50,
            "time_user": 0,
            "since": datetime.now(),
            "key" : 'None',
            }
            mydicts = {
            "Status": "False",
            }
            keyboard = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("Canal", url="https://t.me/+rtV8voEx9vA0ODRh"),
               
            ]
        ]
    )
            
            collection_bot.insert_one(mydicts)
        
            collection.insert_one(mydict)
            text = f'''<b>Tu Registro fue Existosamente
━━━━━━༺༻ ━━━━━━
⚘ User Id ➤ <code>{message.from_user.id}</code>
⚘ UserName ➤ <code>@{message.from_user.username}</code>
⚘ Plan ➤ Free Users
⚘ AntiSpam ➤ 50s
⚘ Creditos ➤ 0
</b>'''
            await message.reply(text=text,quote=False, disable_web_page_preview=True,
            reply_markup=keyboard)
        else:
            await message.reply(text='<b>Ya estas Registado En mi Base de datos</b>',quote=True)
    except Exception as e:
        print(e)