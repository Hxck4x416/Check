from pyrogram import Client
from pyrogram import filters
import time
from mongoDB import *
from datetime import date , datetime
from datetime import timedelta




@Client.on_message(filters.command('claim',prefixes=['.','!','/',',','-','$','%','#']))
async def claim(_,message):
	buscar_permisos = collection.find_one({"_id": message.from_user.id})
	if buscar_permisos is None: return await message.reply(text='<b>NO ESTAS EN MI BASE DE DATOS USA  /register PARA ESTAR</b>',quote=True)

	ccs = message.text[len('/claim'):]
	espacios = ccs.split()
	if len(espacios)==0: return await message.reply('<b>/claim key</b>',quote=True)
	key = espacios[0]

	encontrar_key = collection_dos.find_one({"key": key})
	if encontrar_key is None: return await message.reply(text='<b>KEY INVALIDA O YA FUE RECLAMADA</b>',quote=True)
		
	dias = encontrar_key['days']
	x = datetime.now() + timedelta(days=dias)

	collection.update_one({"_id": message.from_user.id},{"$set": {"key": x}})
	collection.update_one({"_id": message.from_user.id},{"$set": {"antispam": 30}})
	collection.update_one({"_id": message.from_user.id},{"$set": {"plan": 'Premium'}})
	collection_dos.delete_one({"key": key})

	texto = f'''<b>[<a href="https://t.me/+rtV8voEx9vA0ODRh">✯</a>] Antispam: <code>30s</code>
[<a href="https://t.me/+rtV8voEx9vA0ODRh">✯</a>] Type: <code>All gates</code>
[<a href="https://t.me/+rtV8voEx9vA0ODRh">✯</a>] Dias: <code>{x.strftime("%d %B %X")}</code>
━━━━━━━━━━━━━━
[<a href="https://t.me/+rtV8voEx9vA0ODRh">✯</a>] Checked by: @{message.from_user.username}</b>
'''

	await message.reply(texto,quote=True)
