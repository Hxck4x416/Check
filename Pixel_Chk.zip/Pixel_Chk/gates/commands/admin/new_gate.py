from pyrogram import Client
from pyrogram import filters
from mongoDB import *


@Client.on_message(filters.command('addgate', prefixes=['.', '!', '/', ',', '-', '$', '%', '#']))
async def registrar_comando(_, message):
    buscar_permisos = collection.find_one({"_id": message.from_user.id})
    if buscar_permisos is None:
        return await message.reply(text='<b>You are not currently registered in my database. /register</b>', quote=True)

    if buscar_permisos["role"] == "Owner" or buscar_permisos["role"] == "Dev":
        # Obtiene los argumentos del comando
        args = message.text.split()[1:]
        if len(args) != 2:
            return await message.reply(text="Por favor, proporciona los siguientes argumentos: /addgate /comando nombre.")

        comando, nombre = args

        collection_cuatro.insert_one({
            "comando": comando[1:],
            "nombre": nombre,
            "gate": "ON✅",
            "estado": "✅",
        })
        await message.reply(text=f"""SE AÑADIO GATE: NOMBRE: {nombre} COMANDO: {comando} ESTATUS: ON✅""")