from gates.Func import connect_to_db
import datetime
from asyncio import sleep
from pyrogram import Client, filters



@Client.on_message(filters.command(['mantenimiento'], prefixes=['/', '.']))
def toggle_maintenance_mode(client, message):
    # Conectar a la base de datos SQLite
    conn = connect_to_db()
    cursor = conn.cursor()

    cursor.execute('SELECT valor FROM configuracion WHERE clave = ?', ('maintenance_mode_enabled',))
    result = cursor.fetchone()
    if result and result[0] == 'true':
        cursor.execute('UPDATE configuracion SET valor = ? WHERE clave = ?', ('false', 'maintenance_mode_enabled'))
        conn.commit()
        message.reply('<b>El modo de mantenimiento ha sido desactivado.</b>')
    else:
        cursor.execute('UPDATE configuracion SET valor = ? WHERE clave = ?', ('true', 'maintenance_mode_enabled'))
        conn.commit()
        message.reply('<b>El modo de mantenimiento ha sido activado.</b>')