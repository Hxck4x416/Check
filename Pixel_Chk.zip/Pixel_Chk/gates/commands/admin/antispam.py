from pyrogram import Client
from pyrogram import filters
from mongoDB import *

@Client.on_message(filters.command('setspam', prefixes=['.', '!', '/', ',', '-', '$', '%', '#']))
async def promoved(_, message):
    buscar_permisos = collection.find_one({"_id": message.from_user.id})
    if buscar_permisos is None:
        return await message.reply(text='<b>You are not currently registered in my database. /register</b>', quote=True)

    if buscar_permisos["role"] == "Owner" or buscar_permisos["role"] == "Seller":
        pass
    else:
        return await message.reply(text='<b>Only administrators can use this command.</b>', quote=True)

    ccs = message.text[len('/setspam'):]
    espacios = ccs.split()
    if len(espacios) != 2:
        return await message.reply('<b>/setspam User_ID Antispam</b>', quote=True)

    user_id = int(espacios[0])
    antispam = int(espacios[1])
    



    user = collection.find_one({"_id": user_id})
    if user is None:
        return await message.reply('Uso incorrecto del comando. Debe ser: /setspam User_ID Antispam')


    collection.update_one({"_id": user_id}, {"$set": {"antispam": antispam}})

    

    return await message.reply(f'<b>El ID: {user_id} Tiene de antispam: {antispam}.</b>', quote=True)