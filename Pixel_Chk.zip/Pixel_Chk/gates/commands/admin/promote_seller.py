from pyrogram import Client
from pyrogram import filters
import time
import random
from datetime import datetime, timedelta
from mongoDB import *

@Client.on_message(filters.command(['addseller', 'addadmin', 'addadm'], prefixes=['.', '!', '/', ',', '-', '$', '%', '#']))
async def promoved(_, message):
    buscar_permisos = collection.find_one({"_id": message.from_user.id})
    if buscar_permisos is None:
        return await message.reply(text='<b>You are not currently registered in my database. /register</b>', quote=True)

    if buscar_permisos["roles"] == "Admin" or buscar_permisos["role"] == "Owner":
        pass
    else:
        return await message.reply(text='<b>Only administrators can use this command.</b>', quote=True)

    ccs = message.text[len('/addseller'):]
    espacios = ccs.split()
    if len(espacios) != 2:
        return await message.reply('<b>/addseller user_id Dias</b>', quote=True)

    user_id = int(espacios[0])
    days = int(espacios[1])
    x = datetime.now() + timedelta(days=days)



    user = collection.find_one({"_id": user_id})
    if user is None:
        return await message.reply(f'<b>User with ID {user_id} is not registered in the database.</b>', quote=True)


    collection.update_one({"_id": user_id}, {"$set": {"role": "Seller"}})
    collection.update_one({"_id": user_id}, {"$set": {"roles": "Sllr"}})
    collection.update_one({"_id": user_id}, {"$set": {"key": x}})
    collection.update_one({"_id": user_id}, {"$set": {"antispam": 20}})
    collection.update_one({"_id": user_id}, {"$set": {"plan": "Premium"}})

    

    return await message.reply(f'<b>User with ID {user_id} has been promoted to the "Seller" role.</b>', quote=True)
