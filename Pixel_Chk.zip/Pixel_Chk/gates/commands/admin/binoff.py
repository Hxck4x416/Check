from pyrogram import Client
from pyrogram import filters
import time
import random
from mongoDB import *

@Client.on_message(filters.command('binoff', prefixes=['.', '!', '/', ',', '-', '$', '%', '#']))
async def binoff(_, message):
    buscar_permisos = collection.find_one({"_id": message.from_user.id})
    if buscar_permisos is None:
        return await message.reply(text='<b>You are not currently registered in my database. /register</b>', quote=True)

    if buscar_permisos["role"] == "Owner" or buscar_permisos["role"] == "Seller":
        comando = message.text.split()[1]

        comando_registrado = collection_bin.find_one({"comando": comando})
        if comando_registrado is None:
            return await message.reply(text=f"El Bin {comando} no está registrado en la base de datos.")

        collection_bin.update_one({"comando": comando}, {"$set": {"estado": "❌"}})

        await message.reply(text=f"""EL Bin {comando} ESTA BANEADO""")