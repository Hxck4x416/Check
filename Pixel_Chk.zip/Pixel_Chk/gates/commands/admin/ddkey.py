from pyrogram import Client
from pyrogram import filters
import time
import random

from mongoDB import *
@Client.on_message(filters.command('ddkey', prefixes=['.', '!', '/', ',', '-', '$', '%', '#']))
async def delete_key(_, message):
    buscar_permisos = collection.find_one({"_id": message.from_user.id})
    if buscar_permisos is None:
        return await message.reply(text='<b>You are not currently registered in my database. /register</b>', quote=True)

    if buscar_permisos["role"] == "Seller" or buscar_permisos["role"] == "Owner":
        pass
    else:
        return await message.reply(text='<b>Only administrators can use this command.</b>', quote=True)
    key_to_delete = message.text.split(' ', 1)[1].strip() 

    document = collection_dos.find_one({"key": key_to_delete})
    if document:
        collection_dos.delete_one({"key": key_to_delete})
        return await Client.send_message(_, chat_id=message.chat.id, text=f"La clave {key_to_delete} ha sido eliminada.")
    else:
        return await Client.send_message(_, chat_id=message.chat.id, text=f"No se encontró la clave {key_to_delete}.")