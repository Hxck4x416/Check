from pyrogram import Client
from pyrogram import filters
import time
import random
from mongoDB import *

@Client.on_message(filters.command('panel', prefixes=['.', '!', '/', ',', '-', '$', '%', '#']))
async def panel_(_, message):
    buscar_permisos = collection.find_one({"_id": message.from_user.id})
    if buscar_permisos is None:
        return await message.reply(text='<b>You are not currently registered in my database. /register</b>', quote=True)

    if buscar_permisos["role"] == "Owner" or buscar_permisos["role"] == "Seller":
        contra = await message.reply(f"""
<b>🩵Ｈｘｃｋ🩵Ｃｈｋ🩵Ｂｏｔ🩵
Verificado Si eres Admin o Seller Espere un momento porfavor.
</b>""", reply_to_message_id=message.id) 
        
        
        await contra.edit_text(text=f"""<b>🩵Ｈｘｃｋ🩵Ｃｈｋ🩵Ｂｏｔ🩵
                            
Panel Command Seller
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Format: /genkey dias
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: ON✅
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Format: /ban user_id
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: ON✅
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Format: /setspam user_id Antispam
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: ON✅
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Format: /reset user_id
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: ON✅
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Format: /desban user_id
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: ON✅
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Format: /ddkey Key
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: ON✅
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Format: /setcrd user_id creditos
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: ON✅
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Format: /addgp dias
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: ON✅
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Format: /my O /mygp
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: ON✅
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
</b>""")
    else:
        await message.reply(text=f"""NO TIENES PERMISO PARA USAR ESTE COMANDO""")