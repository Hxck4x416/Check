from pyrogram import Client
from pyrogram import filters
import time
import random
from mongoDB import *


@Client.on_message(filters.command('reset', prefixes=['.', '!', '/', ',', '-', '$', '%', '#']))
async def reset_plan(_, message):
    buscar_permisos = collection.find_one({"_id": message.from_user.id})
    if buscar_permisos is None:
        return await message.reply(text='<b>You are not currently registered in my database. /register</b>', quote=True)

    if buscar_permisos["role"] == "Owner" or buscar_permisos["role"] == "Seller":
        pass
    else:
        return await message.reply(text='<b>Only administrators can use this command.</b>', quote=True)

    if message.reply_to_message:
        user_id = message.reply_to_message.from_user.id
    else:
        ccs = message.text.split()
        if len(ccs) != 2:
            return await message.reply('<b>/reset user_id</b>', quote=True)
        user_id = ccs[1]

    try:
        user_id = int(user_id)
    except ValueError:
        return await message.reply('<b>Invalid user ID. Please provide a valid numeric ID.</b>', quote=True)

    user = collection.find_one({"_id": user_id})
    if user is None:
        return await message.reply(f'<b>User with ID {user_id} is not registered in the database.</b>', quote=True)

    if user["plan"] == "FreeUser":
        return await message.reply(f'<b>User with ID {user_id} already has the Free plan.</b>', quote=True)
    

    collection.update_one({"_id": user_id}, {"$set": {"key": 'None', "antispam": 50, "plan": 'FreeUser', "role": 'User'}})


    return await message.reply(f'<b>Plan of user with ID {user_id} has been reset to free. User information has been deleted </b>', quote=True)