from pyrogram import filters
from pyrogram import Client
from datetime import datetime, timedelta
from mongoDB import *


@Client.on_message(filters.command('apodo', prefixes=['.', '!', '/', ',', '-', '$', '%', '#']))
async def set_command(client, message):
    buscar_permisos = collection.find_one({"_id": message.from_user.id})
    if buscar_permisos is None:
        return await message.reply(text='<b>You are not currently registered in my database. /register</b>', quote=True)

    if buscar_permisos["role"] == "Owner" or buscar_permisos["roles"] == "Seller":
        pass
    else:
        return await message.reply(text='<b>Only administrators can use this command.</b>', quote=True)

    ccs = message.text[len('/apodo'):].split()
    if len(ccs) < 2:
        return await message.reply('<b>/apodo user id-apodo</b>', quote=True)

    user_id = ccs[0]
    apodo = ' '.join(ccs[2:]).strip()

    try:
        user_id = int(user_id)
    except ValueError:
        return await message.reply('<b>Invalid user ID. Please provide a valid numeric ID.</b>', quote=True)

    user = collection.find_one({"_id": user_id})
    if user is None:
        return await message.reply(f'<b>User with ID {user_id} is not registered in the database.</b>', quote=True)

    collection.update_one({"_id": user_id}, {"$set": {"apodo": apodo}})




    await client.send_message(chat_id=int(user_id), text=f"subido a premium felicidades grax por comprar el bot culero ok no")

    return await message.reply(f'<b>User with ID {user_id} has been promoted to the "{apodo}" Apodo and assigned /b>', quote=True)