from pyrogram import Client
from pyrogram import filters
import time
import random
from mongoDB import *

@Client.on_message(filters.command('ban', prefixes=['.', '!', '/', ',', '-', '$', '%', '#']))
async def ban(_, message):
    buscar_permisos = collection.find_one({"_id": message.from_user.id})
    if buscar_permisos is None:
        return await message.reply(text='<b>You are not currently registered in my database. /register</b>', quote=True)

    if buscar_permisos["role"] == "Owner" or buscar_permisos["role"] == "Co owner":
        pass
    else:
        return await message.reply(text='<b>Only administrators can use this command.</b>', quote=True)

    ccs = message.text[len('/ban'):]

    if message.reply_to_message:
        user_id = message.reply_to_message.from_user.id
    else:
        espacios = ccs.split()
        if len(espacios) != 1:
            return await message.reply('<b>/ban id</b>', quote=True)

        user_id = int(espacios[0])

    user = collection.find_one({"_id": user_id})
    if user is None:
        return await message.reply(f'<b>User with ID {user_id} is not registered in the database.</b>', quote=True)

    collection.update_one({"_id": user_id}, {"$set": {"status": "Baneado"}})

    return await message.reply(f'<b>El ID:{user_id} YA ESTA BANEADO.</b>', quote=True)