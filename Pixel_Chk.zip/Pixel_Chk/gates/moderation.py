from pyrogram import Client, filters
from pyrogram.types import ChatPermissions

@Client.on_message(filters.command("ban") & filters.group)
async def ban_user(client, message):
    if message.reply_to_message:
        await client.kick_chat_member(message.chat.id, message.reply_to_message.from_user.id)
        await message.reply(f"{message.reply_to_message.from_user.first_name} fue baneado.")
    else:
        await message.reply("Por favor, responde al mensaje del usuario que quieres banear.")

@Client.on_message(filters.command("mute") & filters.group)
async def mute_user(client, message):
    if message.reply_to_message:
        await client.restrict_chat_member(message.chat.id, message.reply_to_message.from_user.id, ChatPermissions())
        await message.reply(f"{message.reply_to_message.from_user.first_name} fue silenciado.")
    else:
        await message.reply("Por favor, responde al mensaje del usuario que quieres silenciar.")

@Client.on_message(filters.command("kick") & filters.group)
async def kick_user(client, message):
    if message.reply_to_message:
        await client.kick_chat_member(message.chat.id, message.reply_to_message.from_user.id)
        await message.reply(f"{message.reply_to_message.from_user.first_name} fue expulsado.")
    else:
        await message.reply("Por favor, responde al mensaje del usuario que quieres expulsar.")