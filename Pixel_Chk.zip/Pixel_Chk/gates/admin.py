from pyrogram import Client, filters
from pyrogram.types import ChatPermissions

OWNER_ID = '5468076787'  # Reemplaza con el ID del propietario

@Client.on_message(filters.command("addadmin") & filters.user(OWNER_ID))
async def add_admin(client, message):
    # Código para agregar administrador
    await message.reply("Nuevo administrador agregado.")

@Client.on_message(filters.command("deladmin") & filters.user(OWNER_ID))
async def del_admin(client, message):
    # Código para quitar administrador
    await message.reply("Administrador eliminado.")