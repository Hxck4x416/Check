from pyrogram import Client, filters

@Client.on_message(filters.command("help"))
async def help_command(client, message):
    help_text = (
        "Aquí hay una lista de comandos que puedes usar:\n"
        "/start - Iniciar el bot\n"
        "/help - Mostrar esta ayuda\n"
        "/reiniciar - Reiniciar el bot (solo para el propietario)\n"
        "/ban - Banear a un usuario (solo para administradores)\n"
        "/mute - Silenciar a un usuario\n"
        "/kick - Expulsar a un usuario"
    )
    await message.reply(help_text)