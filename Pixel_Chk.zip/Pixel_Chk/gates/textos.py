bin_prohibido = ['458796','2','7','8','9']
paises_disponibles = ['US','USA','UK','CA','AU','CANADA','AUSTRALIA'] 