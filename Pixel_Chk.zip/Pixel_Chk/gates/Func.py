import sqlite3
import time

def connect_to_db():
    conn = sqlite3.connect('main.db')
    return conn

def is_user_registered(user_id, cursor):
    cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
    result = cursor.fetchone()
    return result is not None

def is_user_banned(user_id: int, cursor: sqlite3.Cursor) -> str:
    cursor.execute('SELECT rango FROM users WHERE user_id = ?', (user_id,))
    user_data = cursor.fetchone()
    if user_data:
        rango = user_data[0]
        if rango in ["Baneado", "Blocked"]:
            return rango
    return "Unbanned"


def antispam(user_id):
    # Obtener información del usuario
        # Crear una nueva conexión de base de datos
    pro = sqlite3.connect('main.db')
    si = pro.cursor()
    si.execute('SELECT antispam, Time_User FROM users WHERE user_id = ?', (user_id,))
    user_data = si.fetchone()
    if not user_data:
        return False
    
    # Verificar si ha pasado el tiempo mínimo desde la última vez que se usó el comando
    last_used = user_data[1] or 0
    time_since_last_used = time.time() - last_used
    if time_since_last_used < user_data[0]:
        time_left = int(user_data[0] - time_since_last_used)
        message = f"<b>Para Volver a Chekear Espera {time_left}</b>"
        return message
    
    # Actualizar el tiempo de uso del usuario en la base de datos
    si.execute('UPDATE users SET Time_User = ? WHERE user_id = ?', (time.time(), user_id))
    pro.commit()
    
    return True