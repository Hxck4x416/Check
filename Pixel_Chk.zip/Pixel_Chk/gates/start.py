from pyrogram import Client, filters

@Client.on_message(filters.command("start"))
async def start_command(client, message):
    await message.reply("¡Hola! Soy tu bot. Usa /help para ver la lista de comandos.")