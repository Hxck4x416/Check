import json
import requests
import time
import asyncio
from asyncio import sleep
from pyrogram import Client, filters
#from configs import Config                         # aqui dice que de configs importe lan classe config
from pyrogram.types import (
    Message,
    InlineKeyboardButton,
    InlineKeyboardMarkup
)

@Client.on_message(filters.command(['id', 'ids', 'mayid'],prefixes=['.','!','/',',','-','$','%','#', '']))
async def id(client,message):
    keyboard = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("Canal", url="https://t.me/+rtV8voEx9vA0ODRh"),
               
            ]
        ]
    )
    await message.reply(f"""<b>
━━━━━━༺༻ ━━━━━━
⚘ User Id ➤ <code>{message.from_user.id}</code>
⚘ Chat Id ➤ <code>{message.chat.id}</code>
    """, quote=False, disable_web_page_preview=True,
            reply_markup=keyboard)