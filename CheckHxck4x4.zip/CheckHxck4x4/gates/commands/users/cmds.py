from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from pyrogram import Client, filters
from pymongo.errors import *
from mongoDB import collection, collection_cuatro  # Asegúrate de importar las colecciones
import os
from pyrogram import enums
from datetime import datetime
import locale
from datetime import timedelta

@Client.on_message(filters.command(['cmds'], prefixes=['/', ',', '.', '!', '$', '-']))
async def cmds(_, message):
    await message.reply_chat_action(enums.ChatAction.TYPING)
    encontrar_usuario = collection.find_one({"_id": message.from_user.id})

    if encontrar_usuario is None:
        return await message.reply(text='<b>Hey, no estás registrado, usa el comando <code>$register</code></b>', quote=True)

    numb_gate = collection_cuatro.count_documents({})
    BOTONES = [
        [
            InlineKeyboardButton("𝙂𝙖𝙩𝙚𝙬𝙖𝙮𝙨", callback_data='gates'),
            InlineKeyboardButton("𝙏𝙤𝙤𝙡𝙨", callback_data='tools'),
        ],
        [
            InlineKeyboardButton("Perfil", callback_data='user_perfil'),
        ]
    ]
    REPLY_MARKUP = InlineKeyboardMarkup(BOTONES)
    text = f"""<b>🩵Ｈｘｃｋ🩵Ｃｈｋ🩵Ｂｏｔ🩵

    𝙂𝘼𝙏𝙀𝙒𝘼𝙔𝙎-↯ {numb_gate}
    𝙏𝙊𝙊𝙇𝙎-↯ 10
    𝘽𝙊𝙏 𝙎𝙏𝘼𝙏𝙐𝙎-↯ ON ✅
    𝘽𝙊𝙏 𝘽𝙔-↯ <code>@user1538837</code>|<code>@Jander_07</code></b>"""

    await message.reply(text, reply_markup=REPLY_MARKUP, quote=True)