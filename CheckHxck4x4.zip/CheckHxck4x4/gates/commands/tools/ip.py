

import requests
from pyrogram import Client, filters

API_URL = 'http://ipwho.is/api/json/'


@Client.on_message(filters.command('ip', prefixes=['.', '/', '!', '?'], case_sensitive=False) & filters.text) 
async def ip_command(client, message):
    ip_address = message.text.split(' ', 1)[-1].strip()

    if not ip_address: 
        await message.reply('Utiliza `/ip 1.1.1.1`')
        return

    try:
        data = requests.get(API_URL, params={'ip': ip_address}).json()

        scamalytics_data = {
         "risk_level": "0 IP FRAUD",
          "fraud_score": "0",       
          "risk_level": "Bajo (Menos de 10)",
          "fraud_score": "10",        
          "risk_level": "Normal [Menos de 20]",
          "fraud_score": "20",                            
          "risk_level": "Normal [Menos de 30]",
          "fraud_score": "Medio Alto [Menos de 30]",          
          "risk_level": "[Menos de 40]",
          "fraud_score": "40",
          "risk_level": "Medio Alto [Menos de 50]",
          "fraud_score": "50",         
          "risk_level": "Medio Alto [Menos de 60]",
          "fraud_score": "60",
          "risk_level": "Medio Alto [Menos de 70]",
          "fraud_score": "70",
          "risk_level": "Medio Alto [Menos de 80]",
          "fraud_score": "80",
          "risk_level": "Medio Alto [Menos de 90]",
          "fraud_score": "90",
          "risk_level": "Medio Alto [Mas de de 100]",
          "fraud_score": "100"

} 

        msg = build_message(ip_address, data, scamalytics_data)

        await message.reply(msg)
    except Exception as e:
        await message.reply(f'error ip :v  {str(e)}')

def build_message(ip, data, scamalytics_data):
    if scamalytics_data:
        risk_lvl = scamalytics_data.get("risk_level", "Desconocido")
        fraud_score = scamalytics_data.get("fraud_score", "Desconocido")
    else:
        risk_lvl = "Desconocido"
        fraud_score = "Desconocido"

    msg = f"- - - - - - - - - - - - - - - - - - - - - - - - - - - -\n**➤ †|IP CHECK**\n- - - - - - - - - - - - - - - - - - - - - - - - - - - -\n➤ †|IP: `{ip}`\n➤ †| Country: {data.get('country', '-')}\n➤ †| City: {data.get('city', '-')}\n➤ †| Time: {data.get('timezone', {}).get('current_time', '-')}\n- - - - - - - - - - - - - -"

    return msg
