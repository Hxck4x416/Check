from pyrogram import Client
from pyrogram import filters
import time
import asyncio
import random
import re
import os
from mongoDB import *
from gates.textos import *
from pyrogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup
)
from datetime import datetime
from gates.functions.func_bin import get_bin_info
from gates.functions.func_imp import get_time_taken
from gates.functions.func_sa import auto_sho_async
import socket

def ocultar_ip(archivo):
    with open(archivo, 'r') as file:
        contenido = file.read().splitlines()

    for proxy in contenido:
        partes = proxy.split(".")
        partes[-1] = ''
        partes[-3] = '.xxxx'
    return ''.join(partes)



async def verificar_proxies(archivo):
    with open(archivo, 'r') as file:
        contenido = file.read().splitlines()

    for proxy in contenido:
        proxy_ip, proxy_port = proxy.split(":")
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    try:
        sock.settimeout(5)
        sock.connect((proxy_ip, int(proxy_port)))
        return "Live! ✅"
    except socket.error as err:
        return "Dead! ❌", err
    finally:
        sock.close()
        
archivo = "/storage/emulated/0/Pixel_Chk/proxys.txt"  # Reemplaza con la ruta y nombre de tu archivo de texto
verificar_proxies(archivo)

@Client.on_message(filters.command('stp',prefixes=['.','!','/',',','-','$','%','#']))
async def stp_(_,message):

    

    tiempo = time.time()

    if message.reply_to_message:
      input = re.findall(r'[0-9]+',str(message.reply_to_message.text))
    else:
      input = re.findall(r'[0-9]+',str(message.text))

    encontrar_usuario = collection.find_one({"_id": message.from_user.id})
    encontrar_comando = collection_cuatro.find_one({"comando": "stp"})

    #
    if encontrar_usuario is None: return await message.reply(text='<b>You are not currently registered in my database. /register</b>',quote=True)

    estado_comando = encontrar_comando.get("estado")
    if estado_comando == "❌":
        return await message.reply(text="""
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Gateway: <code>Shopify+b3 $11.00 </code>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Estados: <code>❌</code>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Format: <code>/stp cc|month|year|cvv.</code></b>""")
        


    encontrar_grupo = collection_tres.find_one({"group": str(message.chat.id)})

    if encontrar_usuario['key'] != 'None' or encontrar_grupo != None:
        if encontrar_usuario['key'] != 'None':
            if encontrar_usuario["key"] < datetime.now():            
                collection.update_one({"_id": message.from_user.id},{"$set": {"key": 'None'}})
                collection.update_one({"_id": message.from_user.id},{"$set": {"antispam": 50}})
                collection.update_one({"_id": message.from_user.id},{"$set": {"plan": 'Free'}})
                return await message.reply(text='<b>your key has expired.</b>',quote=True)
        elif encontrar_grupo["key"] < datetime.now():
            collection_tres.delete_one({"group": str(message.chat.id)})

    else: return await message.reply(text='<b>Contact an administrator to get a key.</b>',quote=True)

    alaa = f'''
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Gateway: <code>Shopify+b3 $11.00 </code>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Estados: <code>✅</code>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Format: <code>/stp cc|month|year|cvv.</code></b>
'''
    if len(input) < 4: return await message.reply(text=alaa,quote=True)      

    tiempo_usuario = int(encontrar_usuario["time_user"])
    spam_time = int(time.time()) - tiempo_usuario
    if spam_time < encontrar_usuario['antispam']:
        tiempo_restante = encontrar_usuario['antispam'] - spam_time
        texto_spam = f"""
<b>[ANTI_SPAM_DETECTED] Try again after <code>{tiempo_restante}</code>'s</b> 
    """
        return await Client.send_message(_,chat_id=message.chat.id,text=texto_spam,reply_to_message_id=message.id)
    
    user = collection.find_one({'_id': message.from_user.id})

    collection.update_one({"_id": message.from_user.id},{"$set": {"time_user": int(time.time())}})
  

    cc = input[0]
    mes = input[1]
    users = message.from_user.username
    ano = input[2]
    cvv = input[3]
    bin_code = cc[:6]
    archivo = "/storage/emulated/0/Pixel_Chk/proxys.txt"
    ip = ocultar_ip(archivo)
    x = get_bin_info(cc[0:6])
    proxy = await verificar_proxies(archivo)
    
    # Verificar si el bin está en la lista de bins prohibidos 
    banned_file = "gates/bin_banned.txt" 
    if os.path.exists(banned_file): 
        with open(banned_file, "r") as file: 
                banned_bins = file.read().splitlines() 
                if bin_code in banned_bins: 
                    await message.reply_text("Bin Banned") 
                    return 
   #dabese variable
    
    if user and user['credits'] > 0:
        ñ = await message.reply(f"""
<b>🩵Ｈｘｃｋ🩵Ｃｈｋ🩵Ｂｏｔ🩵

<b><a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Card: <code>{cc}|{mes}|{ano}|{cvv}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Type: <code>{x.get("vendor")} / {x.get("type")} / {x.get("level")}</code>

⪨<a href="https://t.me/+rtV8voEx9vA0ODRh">🜲</a>⪩ User: @{users} [{encontrar_usuario["plan"]}]
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a></b>""", reply_to_message_id=message.id, disable_web_page_preview=True) 
    else:
        await message.reply('No tienes créditos suficientes para continuar.')
    
    resultado = await auto_sho_async(cc,mes,ano,cvv)
    if resultado == 'None':
        mensaje = 'Charged $15.99 USD'
        status = 'Approved'
        logo = '✅'
    elif resultado == '2001 Insufficient Funds':
        mensaje = '2001 Insufficient Funds'
        status = 'Approved'
        logo = '✅' 
    elif resultado == '2010 Card Issuer Declined CVV':
        mensaje = '2010 Card Issuer Declined CVV'
        status = 'Approved'
        logo = '✅'
    elif resultado == '2000 Do Not Honor':
        mensaje = '2000 Do Not Honor'
        status = 'Declined'
        logo = '❌'
    elif resultado == '2014 Processor Declined - Fraud Suspected':
        mensaje = '2014 Processor Declined - Fraud Suspected'
        status = 'Declined'
        logo = '❌'
    elif resultado == '2038 Processor Declined':
        mensaje = '2038 Processor Declined'
        status = 'Declined'
        logo = '❌'
    elif resultado == '2044 Declined - Call Issuer':
        mensaje = '2044 Declined - Call Issuer'
        status = 'Declined'
        logo = '❌'
    elif resultado == '2047 Call Issuer. Pick Up Card.':
        mensaje = '2047 Call Issuer. Pick Up Card.'
        status = 'Declined'
        logo = '❌'
    elif resultado == '2007 No Account':
        mensaje = '2007 No Account'
        status = 'Declined'
        logo = '❌'
    elif resultado == '2004 Expired Card':
        mensaje = '2004 Expired Card'
        status = 'Declined'
        logo = '❌'
    elif resultado == '2015 Transaction Not Allowed':
        mensaje = '2015 Transaction Not Allowed'
        status = 'Declined'
        logo = '❌'
    elif resultado == '2019 Invalid Transaction':
        mensaje = '2019 Invalid Transaction'
        status = 'Declined'
        logo = '❌'
    elif resultado == 'There was a problem processing the payment. Try refreshing this page or check your internet connection.':
        mensaje = 'There was a problem processing the payment. Try refreshing this page or check your internet connection.'
        status = 'Declined'
        logo = '❌'
    else:
        mensaje = resultado
        status = 'Declined'
        logo = '❌'        

    texto_final = (f"""<b>🩵Ｈｘｃｋ🩵Ｃｈｋ🩵Ｂｏｔ🩵

<b><a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Card: <code>{cc}|{mes}|{ano}|{cvv}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: <code>{status} {logo}</code></b> 
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Reponse: <code>{mensaje}</code>
✄┈┈┈┈┈┈┈┈┈┈┈┈┈┈
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bin: <code>{cc[0:6]}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Type: <code>{x.get("vendor")} / {x.get("type")} / {x.get("level")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bank : <code>{x.get("bank_name")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Country: <code>{x.get("country")} {x.get("flag")}</code>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Gateways: <code> Shopify+b3 </code>

⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Proxy: <code>{ip} {proxy}</code>
⪨<a href="https://t.me/+rtV8voEx9vA0ODRh">🜲</a>⪩ User: @{users} [{encontrar_usuario["plan"]}]
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a></b>""")
    await ñ.edit(text=texto_final, disable_web_page_preview=True)
    if "Approved ✅" in texto_final:
        credits = collection.find_one({"_id": message.from_user.id})["credits"]
        new_credits = max(0, credits - 2)
        collection.update_one({"_id": message.from_user.id}, {"$set": {"credits": new_credits}})
        texto_crd = f"""
<b>Tus créditos restantes son: {new_credits}</b> 
    """
        return await Client.send_message(_,chat_id=message.chat.id,text=texto_crd,reply_to_message_id=message.id)

