from gates.functions.chk import *
from gates.functions.chk import chks
from pyrogram import Client
from pyrogram import filters
import time
import asyncio
import random
import re
import os
from mongoDB import *
from gates.textos import *
from pyrogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup
)
from datetime import datetime
from gates.functions.func_bin import get_bin_info
from gates.functions.func_imp import get_time_taken
from gates.functions.func_sa import auto_sho_async
import socket


def ocultar_ip(archivo):
    with open(archivo, 'r') as file:
        contenido = file.read().splitlines()

    for proxy in contenido:
        partes = proxy.split(".")
        partes[-1] = ''
        partes[-3] = '.xxxx'
    return ''.join(partes)



async def verificar_proxies(archivo):
    with open(archivo, 'r') as file:
        contenido = file.read().splitlines()

    for proxy in contenido:
        proxy_ip, proxy_port = proxy.split(":")
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    try:
        sock.settimeout(5)
        sock.connect((proxy_ip, int(proxy_port)))
        return "Live! ✅"
    except socket.error as err:
        return "Dead! ❌", err
    finally:
        sock.close()
        
archivo = "/storage/emulated/0/Pixel_Chk/proxys.txt"  # Reemplaza con la ruta y nombre de tu archivo de texto
verificar_proxies(archivo)

@Client.on_message(filters.command('mass',prefixes=['.','!','/',',','-','$','%','#']))
async def mass_(_,msg):
    
    tiempo = time.time()
    

    if msg.reply_to_message:
      input = re.findall(r'[0-9]+',str(msg.reply_to_message.text))
    else:
      input = re.findall(r'[0-9]+',str(msg.text))

    encontrar_usuario = collection.find_one({"_id": msg.from_user.id})
    encontrar_comando = collection_cuatro.find_one({"comando": "mass"})

    #
    if encontrar_usuario is None: return await msg.reply(text='You are not currently registered in my database. /register</b>',quote=True)

    estado_comando = encontrar_comando.get("estado")
    if estado_comando == "❌":
        return await msg.reply(text="""
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Gateway: <code>Stripe Charged $10.00 </code>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Estados: <code>❌</code>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Format: <code>/mass cc|month|year|cvv.</code></b>""")

    encontrar_grupo = collection_tres.find_one({"group": str(msg.chat.id)})

    if encontrar_usuario['key'] != 'None' or encontrar_grupo != None:
        if encontrar_usuario['key'] != 'None':
            if encontrar_usuario["key"] < datetime.now():            
                collection.update_one({"_id": msg.from_user.id},{"$set": {"key": 'None'}})
                collection.update_one({"_id": msg.from_user.id},{"$set": {"antispam": 60}})
                collection.update_one({"_id": msg.from_user.id},{"$set": {"plan": 'Free'}})
                return await msg.reply(text='your key has expired.</b>',quote=True)
        elif encontrar_grupo["key"] < datetime.now():
            collection_tres.delete_one({"group": str(msg.chat.id)})

    else: return await msg.reply(text='Contact an administrator to get a key.</b>',quote=True)

    
    alaa = f'''
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Gateway: <code>Stripe Charged $10.00</code></b>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Estados: <code>✅</code>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Format: <code>/mass cc|month|year|cvv.</code>
'''
    if len(input) < 4: return await msg.reply(text=alaa,quote=True)      

    tiempo_usuario = int(encontrar_usuario["time_user"])
    spam_time = int(time.time()) - tiempo_usuario
    if spam_time < encontrar_usuario['antispam']:
        tiempo_restante = encontrar_usuario['antispam'] - spam_time
        texto_spam = f"""
[ANTI_SPAM_DETECTED] Try again after <code>{tiempo_restante}</code>'s</b> 
    """
        return await Client.send_Message(_,chat_id=msg.chat.id,text=texto_spam,reply_to_message_id=msg.id)

    collection.update_one({"_id": msg.from_user.id},{"$set": {"time_user": int(time.time())}})
    user = collection.find_one({'_id': msg.from_user.id})
    users = msg.from_user.username
    archivo = "/storage/emulated/0/Pixel_Chk/proxys.txt"
    ip = ocultar_ip(archivo)
    hola = await msg.reply(f"""
<b>����𝚕 𝙲�� ���

<b><a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Info: Checando Tus Ccs 

⪨<a href="https://t.me/+rtV8voEx9vA0ODRh">🜲</a>⪩ User: @{users} [{encontrar_usuario["plan"]}]
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a></b>""", reply_to_message_id=msg.id)
    time.sleep(3)
    if user and user['credits'] > 0:
        msgg = '<b>����𝚕 𝙲�� ���</b>'
    msgga = await hola.edit_text(msgg)
    ccs = msg.text[len('/mass '): ]
    ss = ccs.split(',')
    if not ccs: return await msgga.edit_text('<b>Error ingrese las ccs</b>')
    else:
        for cc in ss:
            cssa = cc.split('\n')
            if len(cssa) <= 10:
                for css in cssa:
                    xxx = css.split('|')
                    cc = xxx[0]
                    mes = xxx[1]
                    ano = xxx[2]
                    cvv = xxx[3]
                    chka = chks(cc,mes,ano,cvv)
                    x = get_bin_info (cc[0:6])
                    proxys = await verificar_proxies(archivo)
                    if "stripe_3ds2_fingerprint" in chka.text:
                        msgg += f"""<b>
<b><a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Card: <code>{css}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: <code>Declined ❌</code></b> 
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Reponse: <code>3D dectec</code>
</b>"""

                        await hola.edit_text(text=msgg, disable_web_page_preview=True)
                    elif "Your card has insufficient funds." in chka.text:
                        code = chka.json()['error']['code']
                        _mmsg = chka.json()['error']['message']
                        msgg += f"""<b>
<b><a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Card: <code>{css}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: <code>Approved ✅</code></b> 
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Reponse: <code>{_mmsg}</code>
</b>"""

                        await hola.edit_text(text=msgg, disable_web_page_preview=True)

                    elif "Your card's security code is incorrect." in chka.text:

                        code = chka.json()['error']['code']
                        _mmsg = chka.json()['error']['message']
                        msgg +=  f"""<b>
<b><a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Card: <code>{css}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: <code>Approved ✅</code></b> 
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Reponse: <code>{_mmsg}</code>
</b>"""
                        await hola.edit_text(text=msgg, disable_web_page_preview=True)
                    elif "Your card was declined." in chka.text:

                        code = chka.json()['error']['code']
                        _mmsg = chka.json()['error']['message']
                        msgg += f"""<b>
<b><a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Card: <code>{css}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: <code>Declined ❌</code></b> 
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Reponse: <code>{_mmsg}</code>
</b>"""
                        await hola.edit_text(text=msgg, disable_web_page_preview=True)
                    elif "success"in chka.text:

                        code = chka.json()['error']['code']
                        _mmsg = chka.json()['error']['message']
                        msgg += f"""<b>
<b><a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Card: <code>{css}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: <code>Approved ✅</code></b> 
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Reponse: <code>{_mmsg}</code>
</b>"""
                        await hola.edit_text(text=msgg, disable_web_page_preview=True)

                    else:
                        code = chka.json()['error']['code']
                        _mmsg = chka.json()['error']['message']
                        msgg += f"""<b>
<b><a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Card: <code>{css}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Status: <code>{code}</code> 
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Reponse: <code>{_mmsg}</code>
</b>"""

                        await hola.edit_text(text=msgg, disable_web_page_preview=True)
                        time.sleep(2)
                msgg += f"""<b>
<a href="https://t.me/+rtV8voEx9vA0ODRh">━━━━━━༺༻ ━━━━━━</a>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bin: <code>{cc[0:6]}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Type: <code>{x.get("vendor")} / {x.get("type")} / {x.get("level")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Bank : <code>{x.get("bank_name")}</code>
⧼<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Country: <code>{x.get("country")} {x.get("flag")}</code>
⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Gateways: <code> Mass Stripe </code>

⧽<a href="https://t.me/+rtV8voEx9vA0ODRh">ඩා</a>⧽ Proxy: <code>{ip} {proxys}</code>
⪨<a href="https://t.me/+rtV8voEx9vA0ODRh">🜲</a>⪩ User: @{users} [{encontrar_usuario["plan"]}]</b>"""
                await hola.edit_text(text=msgg, disable_web_page_preview=True)
            if "Approved ✅" in msgg:
                credits = collection.find_one({"_id": msg.from_user.id})["credits"]
                new_credits = max(0, credits - 5)
                collection.update_one({"_id": msg.from_user.id}, {"$set": {"credits": new_credits}})
                texto_crd = f"""
<b>Tus créditos restantes son: {new_credits}</b> 
    """
                return await Client.send_message(_,chat_id=msg.chat.id,text=texto_crd,reply_to_message_id=msg.id)