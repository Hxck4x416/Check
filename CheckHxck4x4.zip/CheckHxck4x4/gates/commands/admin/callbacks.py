import os
from pyrogram import filters, Client
from pyrogram.types import (
    InlineKeyboardMarkup, InlineKeyboardButton)
import re
import time
from mongoDB import *
import requests
import pyrogram.errors
from pyrogram.errors import RPCError
from pyrogram.errors import BadRequest, Forbidden
from gates.functions.func_bin import get_bin_info
from gates.functions.func_gen import cc_gen 
from gates.functions.func_imp import make_order,get_sms 
from gates.functions.func_bin import get_bin_info
from gates.functions.func_gen import cc_gen
from gates.functions.func_imp import get_time_taken


     
async def perfil(Client, message, update): ######PERFIL
    buttons = [[InlineKeyboardButton('Back',callback_data='start')]]


    reply_markup = InlineKeyboardMarkup(buttons)

    encontrar_usuario = collection.find_one({"_id": message.reply_to_message.from_user.id})

    if encontrar_usuario is None:
        texto_xd = "<b>TU NO TE HAS REGISTRADO USA /register</b>"
    else:      
        creditos = encontrar_usuario["credits"]
        id_usuario = encontrar_usuario["_id"]
        user_name = encontrar_usuario["username"]
        plan = encontrar_usuario["plan"]
        role = encontrar_usuario["role"]
        ant = encontrar_usuario["antispam"]
        key_ = encontrar_usuario["key"]
        if key_ != 'None':
            key_ = key_.strftime('%d %B %X')
        else:
            key_ = 'NO HAY REGRISTO DE KEY'


        texto_xd = f"""<b>━━━━━━━━━━━━━━━━━━━
⚘ User Id ➤ <code>{id_usuario}</code>
⚘ UserName ➤ <code>@{user_name}</code>
⚘ Plan ➤ {plan}
⚘ Role ➤ {role}
⚘ AntiSpam ➤ {ant}
⚘ Creditos ➤ {creditos}
⚘ Key ➤ {key_}
━━━━━━━━━━━━━━━━━━━
</b>
            """

    await Client.edit_message_text(
        chat_id=message.chat.id,
        text=texto_xd,
        reply_markup=reply_markup,
        message_id=message.id,
        disable_web_page_preview=True
    )
    
async def pane(Client, message , update):   ####PAGATESSSSSS
    BOTONES = [
        [
            InlineKeyboardButton('↠	', callback_data='panale')
        ]
    ]
    REPLY_MARKUP = InlineKeyboardMarkup(BOTONES)
    
    text=f"""<b>𝗚𝗔𝗧𝗘𝗦 | 𝗖𝗢𝗠𝗔𝗡𝗗𝗦
⌦|Gateways: Braintree
⌦|Comand: /b3 
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Gateways: Payfloow
⌦|Comand: /pay 
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Gateways: Sh+B3
⌦|Comand: /stp 
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Gateways: Sh+vtv
⌦|Comand: /vtv 
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Gateways: Paypal
⌦|Comand: /pp 
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Gateways: Paypal
⌦|Comand: /ppp 
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Gateways: Paypal
⌦|Comand: /it 
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
</b>"""

    await Client.edit_message_text(
        chat_id=message.chat.id,
        text=text,
        reply_markup=REPLY_MARKUP,
        message_id=message.id,
        disable_web_page_preview=True)
 
async def pagenale(Client, message , update):   ####PANELGATESSSSSS
    BOTONES = [
        [
            InlineKeyboardButton('↞',callback_data='pane'),
        ]
    ]
    REPLY_MARKUP = InlineKeyboardMarkup(BOTONES)
    
    text=f"""<b>𝗚𝗔𝗧𝗘𝗦 | 𝗖𝗢𝗠𝗔𝗡𝗗𝗦
⌦|Gateways: Stripe
⌦|Comand: /ps 
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Gateways: Stripe
⌦|Comand: /st 
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Gateways: Stripe
⌦|Comand: /stp 
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Gateways: Stripe
⌦|Comand: /tp 
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Gateways: Paypal
⌦|Comand: /pp
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Gateways: Paypal
⌦|Comand: /ppp 
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Gateways: Paypal
⌦|Comand: /it 
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
</b>"""

    await Client.edit_message_text(
        chat_id=message.chat.id,
        text=text,
        reply_markup=REPLY_MARKUP,
        message_id=message.id,
        disable_web_page_preview=True)
       
async def gates(Client, message , update):   ####GATESSSSSS
    numb_gate = collection_cuatro.count_documents({})
    # Contar comandos con estado "ON"
    comandos_on = collection_cuatro.count_documents({"estado": "✅"})
    # Contar comandos con estado "OFF"
    comandos_off = collection_cuatro.count_documents({"estado": "❌"})
    buttons = [
    [
        InlineKeyboardButton('Stripe', callback_data='authgate'),
        InlineKeyboardButton('Braintre', callback_data='chargedgate'),
        InlineKeyboardButton('Paypal', callback_data='ppgate'),
      
    ],
    [
        InlineKeyboardButton('Especial', callback_data='specialgate'),
        InlineKeyboardButton('Back', callback_data='start')
    ]
    ]
    reply_markup = InlineKeyboardMarkup(buttons)
    text = f"""   
<b>🩵Ｈｘｃｋ🩵Ｃｈｋ🩵Ｂｏｔ🩵

𝙂𝘼𝙏𝙀𝙒𝘼𝙔𝙎-↯ {numb_gate}
𝙊𝙉𝙇𝙄𝙉𝙀-↯ {comandos_on} ✅
𝙊𝙁𝙁𝙇𝙄𝙉𝙀-↯ {comandos_off} ❌
𝘽𝙊𝙏 𝘽𝙔-↯ @user1538837
</b> 
    """
    await Client.edit_message_text(
        chat_id=message.chat.id,
        text=text,
        reply_markup=reply_markup,
        message_id=message.id,
        disable_web_page_preview=True
    )

    

async def gates2(Client, message , update):   ### RETURN A EL INICIO
    numb_gate = collection_cuatro.count_documents({})
    BOTONES = [
        [
            InlineKeyboardButton(
                "𝙂𝙖𝙩𝙚𝙬𝙖𝙮𝙨",callback_data='gates'),
            InlineKeyboardButton(
                "𝙏𝙤𝙤𝙡𝙨",callback_data='tools'),
        ],
        [
            InlineKeyboardButton(
                "Perfil", callback_data='user_perfil'),
        ]
    ]
    REPLY_MARKUP = InlineKeyboardMarkup(BOTONES)
    text=f"""
<b>🩵Ｈｘｃｋ🩵Ｃｈｋ🩵Ｂｏｔ🩵

𝙂𝘼𝙏𝙀𝙒𝘼𝙔𝙎-↯ {numb_gate}
𝙏𝙊𝙊𝙇𝙎-↯ 10
𝘽𝙊𝙏 𝙎𝙏𝘼𝙏𝙐𝙎-↯ ON ✅
𝘽𝙊𝙏 𝘽𝙔-↯ @user1538837</b>       
    """
    
    
    await Client.edit_message_text(
        chat_id=message.chat.id,
        text=text,
        reply_markup=REPLY_MARKUP,
        message_id=message.id,
        disable_web_page_preview=True
    )


async def authgatecomand(Client, message,update):
    a = collection_cuatro.find_one({"comando": "pix"})
    psa = a.get("estado")
    if psa == "❌": 
        ps = "OFF❌"
    else:
        ps = "ON✅"
    a = collection_cuatro.find_one({"comando": "dx"})
    psa = a.get("estado")
    if psa == "❌": 
        st = "OFF❌"
    else:
        st = "ON✅"
    a = collection_cuatro.find_one({"comando": "tp"})
    psa = a.get("estado")
    if psa == "❌": 
        tp = "OFF❌"
    else:
        tp = "ON✅"
    BOTONES = [
        [
            InlineKeyboardButton('↞',callback_data='gates'),
            InlineKeyboardButton('↠	', callback_data='page1')
        ]
    ]
    REPLY_MARKUP = InlineKeyboardMarkup(BOTONES)
    text=f"""<b>𝗚𝗔𝗧𝗘𝗦 | 𝗖𝗢𝗠𝗔𝗡𝗗𝗦
⌦|Gateways: Stripe Charged $280 
⌦|Comand: /pix cc|mes|año|cvv
⌦|Rango: Premium
⌦|Estado: {ps}
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Gateways: Stripe Charged $30.98
⌦|Comand: /dx cc|mes|año|cvv
⌦|Rango: Premium
⌦|Estado: {st}
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Gateways: Stripe Charged $14.99
⌦|Comand: /tp cc|mes|año|cvv
⌦|Rango: Premium
⌦|Estado: {tp}
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a></b>
    """
    await Client.edit_message_text(
        chat_id=message.chat.id,
        text=text,
        reply_markup=REPLY_MARKUP,
        message_id=message.id,
        disable_web_page_preview=True)

async def auth2gatecomand(Client, message,update):
    a = collection_cuatro.find_one({"comando": "b3"})
    psa = a.get("estado")
    if psa == "❌": 
        b3 = "OFF❌"
    else:
        b3 = "ON✅"
    a = collection_cuatro.find_one({"comando": "ps"})
    psa = a.get("estado")
    if psa == "❌": 
        ps = "OFF❌"
    else:
        ps = "ON✅"
    a = collection_cuatro.find_one({"comando": "st"})
    psa = a.get("estado")
    if psa == "❌": 
        st = "OFF❌"
    else:
        st = "ON✅"
    a = collection_cuatro.find_one({"comando": "tp"})
    psa = a.get("estado")
    if psa == "❌": 
        tp = "OFF❌"
    else:
        tp = "ON✅"
    BOTONES = [
        [
            InlineKeyboardButton('↞',callback_data='gates'),
            InlineKeyboardButton('↠	', callback_data='page4')
        ]
    ]
    REPLY_MARKUP = InlineKeyboardMarkup(BOTONES)
    text=f"""
<b>𝗚𝗔𝗧𝗘𝗦 | 𝗖𝗢𝗠𝗔𝗡𝗗𝗦
⌦|Gateways: Stripe Charged $40.00 
⌦|Comand: /ps cc|mes|año|cvv
⌦|Rango: Premium
⌦|Estado: {ps}
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Gateways: Stripe Auth CCN
⌦|Comand: /st cc|mes|año|cvv
⌦|Rango: Premium
⌦|Estado: {st}
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Gateways: Stripe Auth
⌦|Comand: /sta cc|mes|año|cvv
⌦|Rango: Premium
⌦|Estado: {tp}
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a></b>
    """
    await Client.edit_message_text(
        chat_id=message.chat.id,
        text=text,
        reply_markup=REPLY_MARKUP,
        message_id=message.id,
        disable_web_page_preview=True)

async def auth3gatecomand(Client, message,update):
    a = collection_cuatro.find_one({"comando": "b3"})
    psa = a.get("estado")
    if psa == "❌": 
        b3 = "OFF❌"
    else:
        b3 = "ON✅"
    a = collection_cuatro.find_one({"comando": "ps"})
    psa = a.get("estado")
    if psa == "❌": 
        ps = "OFF❌"
    else:
        ps = "ON✅"
    a = collection_cuatro.find_one({"comando": "st"})
    psa = a.get("estado")
    if psa == "❌": 
        st = "OFF❌"
    else:
        st = "ON✅"
    a = collection_cuatro.find_one({"comando": "tp"})
    psa = a.get("estado")
    if psa == "❌": 
        tp = "OFF❌"
    else:
        tp = "ON✅"
    BOTONES = [
        [
            InlineKeyboardButton('↞',callback_data='gates'),
            InlineKeyboardButton('HOME', callback_data='start')
        ]
    ]
    REPLY_MARKUP = InlineKeyboardMarkup(BOTONES)
    text=f"""
<b>𝗚𝗔𝗧𝗘𝗦 | 𝗖𝗢𝗠𝗔𝗡𝗗𝗦
⌦|Gateways: Stripe Auth 
⌦|Comand: / cc|mes|año|cvv
⌦|Rango: Premium
⌦|Estado: {ps}
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Gateways: Stripe Auth 
⌦|Comand: / cc|mes|año|cvv
⌦|Rango: Premium
⌦|Estado: {st}
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Gateways: Stripe Auth
⌦|Comand: / cc|mes|año|cvv
⌦|Rango: Premium
⌦|Estado: {tp}
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a></b>
    """
    await Client.edit_message_text(
        chat_id=message.chat.id,
        text=text,
        reply_markup=REPLY_MARKUP,
        message_id=message.id,
        disable_web_page_preview=True)
    
async def chargedgatecomand(Client, message,update):
    ma = "OFF❌"
    a = collection_cuatro.find_one({"comando": "b3"})
    psa = a.get("estado")
    if psa == "❌": 
        b3 = "OFF❌"
    else:
        b3 = "ON✅"
    a = collection_cuatro.find_one({"comando": "ps"})
    psa = a.get("estado")
    if psa == "❌": 
        ps = "OFF❌"
    else:
        ps = "ON✅"
    a = collection_cuatro.find_one({"comando": "st"})
    psa = a.get("estado")
    if psa == "❌": 
        st = "OFF❌"
    else:
        st = "ON✅"
    a = collection_cuatro.find_one({"comando": "tp"})
    psa = a.get("estado")
    if psa == "❌": 
        tp = "OFF❌"
    else:
        tp = "ON✅"
    BOTONES = [
        [
            InlineKeyboardButton('↞',callback_data='gates'),
            InlineKeyboardButton('↠	', callback_data='page2')
        ]
    ]
    REPLY_MARKUP = InlineKeyboardMarkup(BOTONES)
    text=f"""
<b>𝗚𝗔𝗧𝗘𝗦 | 𝗖𝗢𝗠𝗔𝗡𝗗𝗦
⌦|Gateways: Braintree Charged $27.48 
⌦|Comand: /b3 cc|mes|año|cvv
⌦|Rango: Premium
⌦|Estado: {b3}
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Gateways: Braintree
⌦|Comand: /ps cc|mes|año|cvv
⌦|Rango: Premium
⌦|Estado: {ma}
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Gateways: Braintree
⌦|Comand: /st cc|mes|año|cvv
⌦|Rango: Premium
⌦|Estado: {ma}
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a></b>
    """
    await Client.edit_message_text(
        chat_id=message.chat.id,
        text=text,
        reply_markup=REPLY_MARKUP,
        message_id=message.id,
        disable_web_page_preview=True)

async def chargedgatecomand_2(Client,message,update):
    a = collection_cuatro.find_one({"comando": "b3"})
    psa = a.get("estado")
    if psa == "❌": 
        b3 = "OFF❌"
    else:
        b3 = "ON✅"
    a = collection_cuatro.find_one({"comando": "ps"})
    psa = a.get("estado")
    if psa == "❌": 
        ps = "OFF❌"
    else:
        ps = "ON✅"
    a = collection_cuatro.find_one({"comando": "st"})
    psa = a.get("estado")
    if psa == "❌": 
        st = "OFF❌"
    else:
        st = "ON✅"
    a = collection_cuatro.find_one({"comando": "tp"})
    psa = a.get("estado")
    if psa == "❌": 
        tp = "OFF❌"
    else:
        tp = "ON✅"
    BOTONES = [
        [
            InlineKeyboardButton('↞',callback_data='chargedgatecomand'),
            #InlineKeyboardButton('↠',callback_data='page3')

        ]
    ]
    REPLY_MARKUP = InlineKeyboardMarkup(BOTONES)

    text=f"""
<b>Proximamente</b>
    """ 

    await Client.edit_message_text(
        chat_id=message.chat.id,
        text=text,
        reply_markup=REPLY_MARKUP,
        message_id=message.id,
        disable_web_page_preview=True)



async def chargedgatecomand_3(Client,message,update):
    a = collection_cuatro.find_one({"comando": "b3"})
    psa = a.get("estado")
    if psa == "❌": 
        b3 = "OFF❌"
    else:
        b3 = "ON✅"
    a = collection_cuatro.find_one({"comando": "ps"})
    psa = a.get("estado")
    if psa == "❌": 
        ps = "OFF❌"
    else:
        ps = "ON✅"
    a = collection_cuatro.find_one({"comando": "st"})
    psa = a.get("estado")
    if psa == "❌": 
        st = "OFF❌"
    else:
        st = "ON✅"
    a = collection_cuatro.find_one({"comando": "tp"})
    psa = a.get("estado")
    if psa == "❌": 
        tp = "OFF❌"
    else:
        tp = "ON✅"
    BOTONES = [
        [
            InlineKeyboardButton('↞',callback_data='page2'),
            InlineKeyboardButton('HOME',callback_data='start')

        ]
    ]
    REPLY_MARKUP = InlineKeyboardMarkup(BOTONES)

    text=f"""
<b>PROXIMO</b>
    """

    await Client.edit_message_text(
        chat_id=message.chat.id,
        text=text,
        reply_markup=REPLY_MARKUP,
        message_id=message.id,
        disable_web_page_preview=True)


async def specialgatecomand(Client, message,update):
    a = collection_cuatro.find_one({"comando": "stp"})
    psa = a.get("estado")
    if psa == "❌": 
        stp = "OFF❌"
    else:
        stp = "ON✅"
    a = collection_cuatro.find_one({"comando": "pay"})
    psa = a.get("estado")
    if psa == "❌": 
        pay = "OFF❌"
    else:
        pay = "ON✅"
    a = collection_cuatro.find_one({"comando": "vtv"})
    psa = a.get("estado")
    if psa == "❌": 
        vtv = "OFF❌"
    else:
        vtv = "ON✅"
    a = collection_cuatro.find_one({"comando": "tp"})
    psa = a.get("estado")
    if psa == "❌": 
        tp = "OFF❌"
    else:
        tp = "ON✅"
    BOTONES = [
        [
            InlineKeyboardButton('Back',callback_data='gates'),
        ]
    ]
    REPLY_MARKUP = InlineKeyboardMarkup(BOTONES)
    text=f"""<b>𝗚𝗔𝗧𝗘𝗦 | 𝗖𝗢𝗠𝗔𝗡𝗗𝗦
⌦|Gateways: Shopify + Vtv 
⌦|Comand: /vtv cc|mes|año|cvv
⌦|Rango: Premium
⌦|Estado: {vtv}
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Gateways: Payfloow
⌦|Comand: /pay cc|mes|año|cvv
⌦|Rango: Premium
⌦|Estado: {pay}
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Gateways: Shopify + Braintree
⌦|Comand: /stp cc|mes|año|cvv
⌦|Rango: Premium
⌦|Estado: {stp}
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a></b>
    """
    await Client.edit_message_text(
        chat_id=message.chat.id,
        text=text,
        reply_markup=REPLY_MARKUP,
        message_id=message.id,
        disable_web_page_preview=True)


async def ppgatecomand(Client, message,update):
    a = collection_cuatro.find_one({"comando": "pp"})
    psa = a.get("estado")
    if psa == "❌": 
        pp = "OFF❌"
    else:
        pp = "ON✅"
    a = collection_cuatro.find_one({"comando": "ppp"})
    psa = a.get("estado")
    if psa == "❌": 
        ppp = "OFF❌"
    else:
        ppp = "ON✅"
    a = collection_cuatro.find_one({"comando": "it"})
    psa = a.get("estado")
    if psa == "❌": 
        it = "OFF❌"
    else:
        it = "ON✅"
    a = collection_cuatro.find_one({"comando": "tp"})
    psa = a.get("estado")
    if psa == "❌": 
        tp = "OFF❌"
    else:
        tp = "ON✅"
    BOTONES = [
        [
            InlineKeyboardButton('Back',callback_data='gates'),
        ]
    ]
    REPLY_MARKUP = InlineKeyboardMarkup(BOTONES)
    text=f"""<b>𝗚𝗔𝗧𝗘𝗦 | 𝗖𝗢𝗠𝗔𝗡𝗗𝗦
⌦|Gateways: Paypal Guest $0.01 
⌦|Comand: /pp cc|mes|año|cvv
⌦|Rango: Premium
⌦|Estado: {pp}
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Gateways: Paypal Charged $5
⌦|Comand: /ppp cc|mes|año|cvv
⌦|Rango: Premium
⌦|Estado: {ppp}
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Gateways: Paypal
⌦|Comand: /it cc|mes|año|cvv
⌦|Rango: Premium
⌦|Estado: {it}
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a></b>
"""
    await Client.edit_message_text(
        chat_id=message.chat.id,
        text=text,
        reply_markup=REPLY_MARKUP,
        message_id=message.id,
        disable_web_page_preview=True)
        
async def tools(Client, message , update):  ##TOOLS 1
    buttons = [
        [
            InlineKeyboardButton('Back',callback_data='start'),
            InlineKeyboardButton('Next',callback_data='sexo'),
        ]
    ]
   
    reply_markup = InlineKeyboardMarkup(buttons)
    text_tools_2 = f"""<b>𝗧𝗢𝗢𝗟𝗦 | 𝗖𝗢𝗠𝗔𝗡𝗗𝗦
⌦|Tools: FAKE LAG BR-CLA
⌦|Comand: /br ip:port
⌦|Rango: Premium
⌦|Estado: ON ✅
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Tools: FAKE LAG DE-CLA
⌦|Comand: /de ip:port
⌦|Rango: Premium
⌦|Estado: ON ✅
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
</b>
    """
    await Client.edit_message_text(
        chat_id=message.chat.id,
        text=text_tools_1,
        reply_markup=reply_markup,
        message_id=message.id,
        disable_web_page_preview=True
    )


async def tools_2(Client, message , update):  ##TOOLS 1
    buttons = [
        [
            InlineKeyboardButton('Back',callback_data='start'),
            InlineKeyboardButton('Next',callback_data='sexo'),
        ]
    ]
   
    reply_markup = InlineKeyboardMarkup(buttons)
    text_tools_2 = f"""<b>𝗧𝗢𝗢𝗟𝗦 | 𝗖𝗢𝗠𝗔𝗡𝗗𝗦
⌦|Tools: SK LIVE
⌦|Comand: /sk sk_live
⌦|Rango: Premium
⌦|Estado: ON ✅
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Tools: GEN CCS
⌦|Comand: /gen 456789|rnd|rdn|rdn
⌦|Rango: Premium
⌦|Estado: ON ✅
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Tools: BIN LOOKUP
⌦|Comand: /bin 456789|rnd|rdn|rdn
⌦|Rango: FREE
⌦|Estado: ON ✅
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Tools: EXTRA CCS
⌦|Comand: /extra 456789|rnd|rdn|rdn
⌦|Rango: FREE
⌦|Estado: ON ✅
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Tools: Sites Lookup
⌦|Comand: /sites Url
⌦|Rango: FREE
⌦|Estado: ON ✅
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
</b>
    """
    await Client.edit_message_text(
        chat_id=message.chat.id,
        text=text_tools_2,
        reply_markup=reply_markup,
        message_id=message.id,
        disable_web_page_preview=True
    )

async def tools_3(Client, message , update):   ##TOOLS 2
    buttons = [
        [
            InlineKeyboardButton('Back',callback_data='tools'),
            InlineKeyboardButton('Home',callback_data='start'),
        ]
    ]
    text_tools_3 = f"""<b>𝗧𝗢𝗢𝗟𝗦 | 𝗖𝗢𝗠𝗔𝗡𝗗𝗦
⌦|Tools: LUHN CHECK
⌦|Comand: /luhn sk_live
⌦|Rango: FREE
⌦|Estado: ON ✅
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Tools: INFO TLG
⌦|Comand: /infos
⌦|Rango: FREE
⌦|Estado: ON ✅
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Tools: IP LOOKUP
⌦|Comand: /ip 8.8.8.8
⌦|Rango: Premium
⌦|Estado: ON ✅
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Tools: RANDOM PAIS
⌦|Comand: /rnd US
⌦|Rango: Premium
⌦|Estado: ON ✅
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
⌦|Tools: Mail Lookup
⌦|Comand: /email
⌦|Rango: FREE
⌦|Estado: ON ✅
<a href="https://t.me/+rtV8voEx9vA0ODRh">❛ ━━━━━━･❪ ❁ ❫ ･━━━━━━ ❜</a>
</b>
    """
   
    reply_markup = InlineKeyboardMarkup(buttons)

    await Client.edit_message_text(
        chat_id=message.chat.id,
        text=text_tools_3,
        reply_markup=reply_markup,
        message_id=message.id,
        disable_web_page_preview=True
    )

@Client.on_callback_query(filters.regex("gen_pro"))
async def regen(client, msg): 
    tiempo= time.perf_counter()  
    men = msg.message.reply_to_message.text
    geneoa= men.split()[1]
    
    geneo = re.findall(r'[0-9]+',geneoa)
    if len(geneo) == 1:
        cc = geneo[0]
        mes = 'x'
        ano = 'x'
        cvv = 'x'
    elif len(geneo) ==2:
        cc = geneo[0]
        mes = geneo[1]
        ano = 'x'
        cvv = 'x'
    elif len(geneo) ==3:
        cc = geneo[0]
        mes = geneo[1]
        ano = geneo[2]
        cvv = 'x'
    elif len(geneo) ==4:
        cc = geneo[0]
        mes = geneo[1]
        ano = geneo[2]
        cvv = geneo[3]
    else:
        cc = geneo[0]
        mes = geneo[1]
        ano = geneo[2]
        cvv = geneo[3]

    cc1,cc2,cc3,cc4,cc5,cc6,cc7,cc8,cc9,cc10 = cc_gen(cc,mes,ano,cvv)
    
    user=msg.from_user.username
    
    extra = str(cc) + 'xxxxxxxxxxxxxxxxxxxxxxx'
    if mes == 'x':
        mes_2 = 'rnd'
    else:
        mes_2 = mes
    if ano == 'x':
        ano_2 = 'rnd'
    else:
        ano_2 = ano
    if cvv == 'x':
        cvv_2 = 'rnd'
    else:
        cvv_2 = cvv


    cc1,cc2,cc3,cc4,cc5,cc6,cc7,cc8,cc9,cc10, = cc_gen(cc,mes,ano,cvv)
    
    
    x = get_bin_info(geneoa[0:6])
            

    encontrar_usuario = collection.find_one({"_id": msg.message.reply_to_message.from_user.id})
    
    reply_markup = InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton( 
                            "Re Gen🔄",
                            callback_data="gen_pro"
                        ),
                        InlineKeyboardButton( 
                            "Re Gen Mass🔄",
                            callback_data="genm_pro"
                        ),
                    
                    ],
                ]
            )
    tiempofinal = time.perf_counter()

    gen = f"""<b>
ϟ 𝙂𝙚𝙣𝙚𝙧𝙖𝙩𝙤𝙧 𝘾𝙖𝙧𝙙𝙨 ϟ
━━━━━━༺༻ ━━━━━━
⚘ Bin ➤ <code>{cc[0:6]}</code>
⚘ Info ➤ <code>{x.get("vendor")} - {x.get("type")} - {x.get("level")}</code>
⚘ Bank ➤ <code>{x.get("bank_name")} </code>
⚘ Country ➤ <code>{x.get("country")} {x.get("flag")}</code>
━━━━━━༺༻ ━━━━━━
<code>{cc1}</code><code>{cc2}</code>  <code>{cc3}</code><code>{cc4}</code> <code>{cc5}</code><code>{cc6}</code><code>{cc7}</code><code>{cc8}</code><code>{cc9}</code><code>{cc10}</code>
━━━━━━༺༻ ━━━━━━ 
⚘ Time ➤ {tiempofinal - tiempo:0.2}
⚘ Gen By ➤ @{user} [{encontrar_usuario['plan']}]
</b>"""



    await msg.edit_message_text(gen,reply_markup=reply_markup)

@Client.on_callback_query(filters.regex("genm_pro"))
async def regenma(client, msg): 
    tiempo= time.perf_counter()  
    men = msg.message.reply_to_message.text
    geneoa= men.split()[1]
    
    geneo = re.findall(r'[0-9]+',geneoa)
    if len(geneo) == 1:
        cc = geneo[0]
        mes = 'x'
        ano = 'x'
        cvv = 'x'
    elif len(geneo) ==2:
        cc = geneo[0]
        mes = geneo[1]
        ano = 'x'
        cvv = 'x'
    elif len(geneo) ==3:
        cc = geneo[0]
        mes = geneo[1]
        ano = geneo[2]
        cvv = 'x'
    elif len(geneo) ==4:
        cc = geneo[0]
        mes = geneo[1]
        ano = geneo[2]
        cvv = geneo[3]
    else:
        cc = geneo[0]
        mes = geneo[1]
        ano = geneo[2]
        cvv = geneo[3]

    cc1,cc2,cc3,cc4,cc5,cc6,cc7,cc8,cc9,cc10 = cc_gen(cc,mes,ano,cvv)
    
    user=msg.from_user.username
    
    extra = str(cc) + 'xxxxxxxxxxxxxxxxxxxxxxx'
    if mes == 'x':
        mes_2 = 'rnd'
    else:
        mes_2 = mes
    if ano == 'x':
        ano_2 = 'rnd'
    else:
        ano_2 = ano
    if cvv == 'x':
        cvv_2 = 'rnd'
    else:
        cvv_2 = cvv


    cc1,cc2,cc3,cc4,cc5,cc6,cc7,cc8,cc9,cc10, = cc_gen(cc,mes,ano,cvv)
    
    
    x = get_bin_info(geneoa[0:6])
            

    encontrar_usuario = collection.find_one({"_id": msg.message.reply_to_message.from_user.id})
    
    reply_markup = InlineKeyboardMarkup(
                [
                    [
                        InlineKeyboardButton( 
                            "Re Gen🔄",
                            callback_data="gen_pro"
                        ),
                        InlineKeyboardButton( 
                            "Re Gen Mass🔄",
                            callback_data="genm_pro"
                        ),
                    
                    ],
                ]
            )
    tiempofinal = time.perf_counter()

    gen = f"""<b>
ϟ 𝙂𝙚𝙣𝙚𝙧𝙖𝙩𝙤𝙧 𝘾𝙖𝙧𝙙𝙨 ϟ
━━━━━━༺༻ ━━━━━━
⚘ Bin ➤ <code>{cc[0:6]}</code>
⚘ Info ➤ <code>{x.get("vendor")} - {x.get("type")} - {x.get("level")}</code>
⚘ Bank ➤ <code>{x.get("bank_name")} </code>
⚘ Country ➤ <code>{x.get("country")} {x.get("flag")}</code>
━━━━━━༺༻ ━━━━━━
<code>{cc1}{cc2}{cc3}{cc4}{cc5}{cc6}{cc7}{cc8}{cc9}{cc10}</code>
━━━━━━༺༻ ━━━━━━ 
⚘ Time ➤ {tiempofinal - tiempo:0.2}
⚘ Gen By ➤ @{user} [{encontrar_usuario['plan']}]
</b>"""



    await msg.edit_message_text(gen,reply_markup=reply_markup)
    
async def otp_telegram(Client,message,update):

    buttons = [
        [
            InlineKeyboardButton('Cancel Order',callback_data='#'),
            InlineKeyboardButton('Skip Number',callback_data='#'),
        ]
    ]

    reply_markup = InlineKeyboardMarkup(buttons)

    x = await make_order()

    if not x:
        text = f'''
PAPI HA SUCEDIDO UN ERROR... LO SIENTO
'''
        return await Client.edit_message_text(
        chat_id=message.chat.id,
        text=text,
        reply_markup=reply_markup,
        message_id=message.id,
        disable_web_page_preview=True)

    orderid, numero = x

    texto_1 = f'''
<b>Numero: <code>+44 {numero}</code>
Order Id: <code>{orderid}</code>
Service: <code>Telegram</code>
━━━━━━━━━━━━━━
[<a href="https://t.me/Universechkbot">✦</a> Message: <code>please wait for the code...</code></b>
'''

    await Client.edit_message_text(
        chat_id=message.chat.id,
        text=texto_1,
        reply_markup=reply_markup,
        message_id=message.id,
        disable_web_page_preview=True)

    a = await get_sms(orderid)

    if not a:
        return await Client.edit_message_text(
        chat_id=message.chat.id,
        text=f'Algo ha fallado',
        reply_markup=reply_markup,
        message_id=message.id,
        disable_web_page_preview=True)

    texto_2 = f'''
<b>Numero: <code>{numero}</code>
<b>Order Id: <code>{orderid}</code>
<b>Service: <code>Telegram</code>
━━━━━━━━━━━━━━
<b>[<a href="https://t.me/Universechkbot">✦</a> Message: <code>{a}</code></b>
'''

    return await Client.edit_message_text(
        chat_id=message.chat.id,
        text=texto_2,
        reply_markup=reply_markup,
        message_id=message.id,
        disable_web_page_preview=True)








@Client.on_callback_query()
async def button(Client, update):
      cb_data = update.data
      text = 'Hola'
      try:
            if update.message.reply_to_message.from_user.id == update.from_user.id:
                if "gates" in cb_data:
                    await gates(Client, update.message,update)
                elif "close" in cb_data:
                    await update.message.delete()
                elif "start" in cb_data:
                    await gates2(Client, update.message,update)
                elif "authgate" in cb_data:
                    await authgatecomand(Client, update.message,update)
                elif "chargedgate" in cb_data:
                    await chargedgatecomand(Client, update.message,update)
                elif "specialgate" in cb_data:
                    await specialgatecomand(Client, update.message,update)
                elif "tools" in cb_data:
                    await tools(Client, update.message,update)
                elif "page1" in cb_data:
                    await auth2gatecomand(Client,update.message,update)
                elif "pane" in cb_data:
                    await pane(Client,update.message,update)
                elif "panale" in cb_data:
                    await pagenale(Client,update.message,update)
                elif "page4" in cb_data:
                    await auth3gatecomand(Client,update.message,update)
                elif "page2" in cb_data:
                    await chargedgatecomand_2(Client,update.message,update)
                elif "page3" in cb_data:
                    await chargedgatecomand_3(Client,update.message,update)
                elif "ppgate" in cb_data:
                    await ppgatecomand(Client,update.message,update)
                elif "sexo" in cb_data:
                    await tools_2(Client, update.message, update)
                elif "user_perfil" in cb_data:
                    await perfil(Client, update.message, update)
                elif "otp_telegram" in cb_data:
                    await otp_telegram(Client, update.message, update)
            else:
                await Client.answer_callback_query(
            callback_query_id=update.id,
            text=text,
            show_alert="true"
          )
      except RPCError as e:
          print(e)
      except BadRequest as e:
          print(e)
      except Forbidden as e:
          print(e)
            

     
            
 
