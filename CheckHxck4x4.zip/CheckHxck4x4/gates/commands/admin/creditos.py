from pyrogram import Client
from pyrogram import filters
from mongoDB import *

@Client.on_message(filters.command(['addcrd', 'addcreditos', 'addcredi', 'setcrd'], prefixes=['.', '!', '/', ',', '-', '$', '%', '#']))
async def promoved(_, message):
    buscar_permisos = collection.find_one({"_id": message.from_user.id})
    if buscar_permisos is None:
        return await message.reply(text='<b>You are not currently registered in my database. /register</b>', quote=True)

    if buscar_permisos["role"] == "Owner" or buscar_permisos["role"] == "Seller":
        pass
    else:
        return await message.reply(text='<b>Only administrators can use this command.</b>', quote=True)

    ccs = message.text[len('/addcrd'):]
    espacios = ccs.split()
    if len(espacios) != 2:
        return await message.reply('<b>/addcrd user_id Creditos/b>', quote=True)

    user_id = int(espacios[0])
    creditos = int(espacios[1])
    



    user = collection.find_one({"_id": user_id})
    if user is None:
        return await message.reply('Uso incorrecto del comando. Debe ser: /addcrd <id> <monto>')


    collection.update_one({"_id": user_id}, {"$set": {"credits": creditos}})

    

    return await message.reply(f'<b>Se añadio Creditos al ID:{user_id} Creditos: {creditos} /b>', quote=True)

