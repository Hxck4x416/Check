from pyrogram import Client, filters
import asyncio
import os
import sys

@Client.on_message(filters.command("echo"))
async def echo_message(client, message):
    await message.reply(message.text.split(" ", 1)[1])

@Client.on_message(filters.command("reiniciar"))
async def restart_bot(client, message):
    await message.reply("Reiniciando el bot...")
    await asyncio.sleep(2)
    os.execv(sys.executable, ['python'] + sys.argv)