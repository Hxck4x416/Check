import aiohttp
from tenacity import retry, stop_after_attempt
from urllib.parse import urlparse, quote
import asyncio
import random
import time
import requests
import string
from aiohttp_socks.connector import ProxyConnector
from gates.functions.func_imp import find_between,get_random_string


def find_between( data, first, last ):
  try:
    start = data.index( first ) + len( first )
    end = data.index( last, start )
    return data[start:end]
  except ValueError:
    return None


@retry(stop=stop_after_attempt(3))
async def auto_sho_async(cc,mes,ano,cvv):
    
	
    
    session = requests.session()


    headers = {
    'authority': 'us.brandymelville.com',
    'accept': 'application/javascript',
    'accept-language': 'es-ES,es;q=0.9',
    'content-type': 'application/json',
    # 'cookie': 'secure_customer_sig=; localization=US; _tracking_consent=%7B%22region%22%3A%22VEF%22%2C%22reg%22%3A%22%22%2C%22con%22%3A%7B%22CMP%22%3A%7B%22a%22%3A%22%22%2C%22s%22%3A%22%22%2C%22p%22%3A%22%22%2C%22m%22%3A%22%22%7D%7D%2C%22lim%22%3A%5B%22CCPA%22%5D%2C%22v%22%3A%222.1%22%7D; _y=7fceb083-013c-4be7-bf0e-d5983ffb23ed; _s=7225bbb4-2cdd-4472-b76b-068cdc7c7a2a; _shopify_y=7fceb083-013c-4be7-bf0e-d5983ffb23ed; _shopify_s=7225bbb4-2cdd-4472-b76b-068cdc7c7a2a; _orig_referrer=; _landing_page=%2F; _shopify_sa_p=; _gid=GA1.2.704648594.1691617459; __zlcmid=1HGm2BcOOi3xogD; _gat=1; _shopify_sa_t=2023-08-09T21%3A45%3A32.111Z; _ga_LSSD6RDD8K=GS1.1.1691617455.1.1.1691617532.0.0.0; _ga=GA1.2.1217410807.1691617455; __kla_id=eyIkcmVmZXJyZXIiOnsidHMiOjE2OTE2MTc0NjMsInZhbHVlIjoiIiwiZmlyc3RfcGFnZSI6Imh0dHBzOi8vdXMuYnJhbmR5bWVsdmlsbGUuY29tLz9wYWdlPTEifSwiJGxhc3RfcmVmZXJyZXIiOnsidHMiOjE2OTE2MTc1MzMsInZhbHVlIjoiIiwiZmlyc3RfcGFnZSI6Imh0dHBzOi8vdXMuYnJhbmR5bWVsdmlsbGUuY29tLz9wYWdlPTEifX0=; amazon-pay-connectedAuth=connectedAuth_general; apay-session-set=aR8ugFGpUMlXZja3gxYTlrjFanv8%2F5RIeV7fR0USJSVtyziLCETJNqYwr0BAs%2BM%3D; keep_alive=32082090-6c85-4b30-ba15-583ae23fb93a; _cmp_a=%7B%22purposes%22%3A%7B%22a%22%3Atrue%2C%22p%22%3Atrue%2C%22m%22%3Atrue%2C%22t%22%3Atrue%7D%2C%22display_banner%22%3Afalse%2C%22merchant_geo%22%3A%22US%22%2C%22sale_of_data_region%22%3Afalse%7D; _shopify_ga=_ga=2.232187929.704648594.1691617459-1217410807.1691617455',
    'origin': 'https://us.brandymelville.com',
    'referer': 'https://us.brandymelville.com/products/copy-of-cotton-scrunchie',
    'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Opera GX";v="100"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 OPR/100.0.0.0',
}

    json_data = {
    'Color': 'Sage Green',
    'options[Color]': 'Heather Grey',
    'quantity': '1',
    'form_type': 'product',
    'utf8': '✓',
    'id': '39997015195857',
    'sections': [
        'ajax-cart-product',
        'cart-icon-bubble',
        'ajax-cart-total',
        'ajax-cart-free-shipping',
        'ajax-cart-delivery-date',
    ],
    'sections_url': '/products/copy-of-cotton-scrunchie',
}

    req1 = session.post('https://us.brandymelville.com/cart/add', headers=headers, json=json_data)

    req2 = session.get('https://us.brandymelville.com/checkout')

    url = req2.url

    req3 = session.get(url=url)

    texto_1 = req3.text

    token_1 = find_between(texto_1,'input type="hidden" name="authenticity_token" value="','"')



    headers_2 = {
    'authority': 'us.brandymelville.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'es-ES,es;q=0.9',
    'cache-control': 'max-age=0',
    'content-type': 'application/x-www-form-urlencoded',
    # 'cookie': 'checkout=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVUyTTJNd09UUmhOMlV5TUdZMU5UTm1ZVEZrTURRME5tVmhOR1V4WkRFMU5BWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOC0zMFQyMTo1MjoyMy43NzhaIiwicHVyIjoiY29va2llLmNoZWNrb3V0In19--7f8ea45f0826d45a7641c7ef82d6b4b53af42d91; checkout_legacy=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVUyTTJNd09UUmhOMlV5TUdZMU5UTm1ZVEZrTURRME5tVmhOR1V4WkRFMU5BWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOC0zMFQyMTo1MjoyMy43NzhaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X2xlZ2FjeSJ9fQ%3D%3D--7046c4713a44d887b0e2eec4cdb550ea6173499b; tracked_start_checkout=980d0739537430db8c16db940404ad8d; checkout_token=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVU1T0RCa01EY3pPVFV6TnpRek1HUmlPR014Tm1SaU9UUXdOREEwWVdRNFpBWTZCa1ZVIiwiZXhwIjoiMjAyNC0wOC0wOVQyMTo1MjoyMy43NzhaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X3Rva2VuIn19--b2f80a57ed983c50f4a72d7b6e3b46b4bf682410; checkout_token_legacy=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVU1T0RCa01EY3pPVFV6TnpRek1HUmlPR014Tm1SaU9UUXdOREEwWVdRNFpBWTZCa1ZVIiwiZXhwIjoiMjAyNC0wOC0wOVQyMTo1MjoyMy43NzhaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X3Rva2VuX2xlZ2FjeSJ9fQ%3D%3D--a2eca29009f801c234a3ef525f5e1f9847cf3223; secure_customer_sig=; localization=US; _tracking_consent=%7B%22region%22%3A%22VEF%22%2C%22reg%22%3A%22%22%2C%22con%22%3A%7B%22CMP%22%3A%7B%22a%22%3A%22%22%2C%22s%22%3A%22%22%2C%22p%22%3A%22%22%2C%22m%22%3A%22%22%7D%7D%2C%22lim%22%3A%5B%22CCPA%22%5D%2C%22v%22%3A%222.1%22%7D; _y=7fceb083-013c-4be7-bf0e-d5983ffb23ed; _s=7225bbb4-2cdd-4472-b76b-068cdc7c7a2a; _shopify_y=7fceb083-013c-4be7-bf0e-d5983ffb23ed; _shopify_s=7225bbb4-2cdd-4472-b76b-068cdc7c7a2a; _orig_referrer=; _landing_page=%2F; _shopify_sa_p=; _gid=GA1.2.704648594.1691617459; __zlcmid=1HGm2BcOOi3xogD; __kla_id=eyIkcmVmZXJyZXIiOnsidHMiOjE2OTE2MTc0NjMsInZhbHVlIjoiIiwiZmlyc3RfcGFnZSI6Imh0dHBzOi8vdXMuYnJhbmR5bWVsdmlsbGUuY29tLz9wYWdlPTEifSwiJGxhc3RfcmVmZXJyZXIiOnsidHMiOjE2OTE2MTc1MzMsInZhbHVlIjoiIiwiZmlyc3RfcGFnZSI6Imh0dHBzOi8vdXMuYnJhbmR5bWVsdmlsbGUuY29tLz9wYWdlPTEifX0=; amazon-pay-connectedAuth=connectedAuth_general; apay-session-set=aR8ugFGpUMlXZja3gxYTlrjFanv8%2F5RIeV7fR0USJSVtyziLCETJNqYwr0BAs%2BM%3D; cart=bb87f71c5a0db6969a80abb5aa76e65c; cart_currency=USD; cart_sig=0dd727ea9afe3f9a32c99a93d9f0aaf4; _shopify_ga=_ga=2.126272139.704648594.1691617459-1217410807.1691617455; cart_ts=1691617624; cart_ver=gcp-us-east1%3A4; _secure_session_id=ab3554d542e79ee8768860db17f18a2e; keep_alive=48e9caeb-8541-44c0-bcbb-9b0af7bfedf9; _cmp_a=%7B%22purposes%22%3A%7B%22a%22%3Atrue%2C%22p%22%3Atrue%2C%22m%22%3Atrue%2C%22t%22%3Atrue%7D%2C%22display_banner%22%3Afalse%2C%22merchant_geo%22%3A%22USUSNJ%22%2C%22sale_of_data_region%22%3Afalse%7D; _checkout_queue_token=AglSEo8NzB7XNZ1ST9WZrj8rPg61dFeU34aDPux8D2hX2ewljoi6sn3BqnrgfzuUNRD3o8I_VBdTuo-gK36-KxAaZPdPOeKtvcN3Epd-w2ilJW4wCPC23PDvAI0BGEZbU3u7wgtC1BoensYaR1cYhBpzy2O9Mduje5Zi5MYo8nVLfzryp5SazQyS93U46Q%3D%3D; _checkout_queue_checkout_token=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVU1T0RCa01EY3pPVFV6TnpRek1HUmlPR014Tm1SaU9UUXdOREEwWVdRNFpBWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOC0wOVQyMjo1MToxNS42MzdaIiwicHVyIjoiY29va2llLl9jaGVja291dF9xdWV1ZV9jaGVja291dF90b2tlbiJ9fQ%3D%3D--96100ca7e1fa2d2446263cffd331fed85cb6910c; _shopify_sa_t=2023-08-09T21%3A52%3A24.643Z; _gat=1; _ga=GA1.1.1217410807.1691617455; unique_interaction_id=4da72194-bc80-41e5-e5d4-857f0103370d; _ga_LSSD6RDD8K=GS1.1.1691617455.1.1.1691617957.0.0.0',
    'origin': 'https://us.brandymelville.com',
    'referer': 'https://us.brandymelville.com/',
    'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Opera GX";v="100"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 OPR/100.0.0.0',
}
    data_1 = f'_method=patch&authenticity_token={token_1}&previous_step=contact_information&step=shipping_method&checkout%5Bemail%5D=alespro123%40gmail.com&checkout%5Bbuyer_accepts_marketing%5D=0&checkout%5Bshipping_address%5D%5Bfirst_name%5D=&checkout%5Bshipping_address%5D%5Blast_name%5D=&checkout%5Bshipping_address%5D%5Baddress1%5D=&checkout%5Bshipping_address%5D%5Baddress2%5D=&checkout%5Bshipping_address%5D%5Bcity%5D=&checkout%5Bshipping_address%5D%5Bcountry%5D=&checkout%5Bshipping_address%5D%5Bprovince%5D=&checkout%5Bshipping_address%5D%5Bzip%5D=&checkout%5Bshipping_address%5D%5Bphone%5D=&checkout%5Bshipping_address%5D%5Bcountry%5D=United+States&checkout%5Bshipping_address%5D%5Bfirst_name%5D=xds&checkout%5Bshipping_address%5D%5Blast_name%5D=+pro&checkout%5Bshipping_address%5D%5Baddress1%5D=UNIT+APERTEAMW222&checkout%5Bshipping_address%5D%5Baddress2%5D=FL+4&checkout%5Bshipping_address%5D%5Bcity%5D=NEW+YORK&checkout%5Bshipping_address%5D%5Bprovince%5D=NY&checkout%5Bshipping_address%5D%5Bzip%5D=10080&checkout%5Bshipping_address%5D%5Bphone%5D=%28205%29+815-2323&checkout%5Bremember_me%5D=false&checkout%5Bremember_me%5D=0&checkout%5Bclient_details%5D%5Bbrowser_width%5D=493&checkout%5Bclient_details%5D%5Bbrowser_height%5D=759&checkout%5Bclient_details%5D%5Bjavascript_enabled%5D=1&checkout%5Bclient_details%5D%5Bcolor_depth%5D=24&checkout%5Bclient_details%5D%5Bjava_enabled%5D=false&checkout%5Bclient_details%5D%5Bbrowser_tz%5D=240'

    req4 = session.post(url=url,headers=headers_2,data=data_1)

    url_2 = req4.url

    req5 = session.get(url=url_2)

    texto_2 = req5.text

    token_2 = find_between(texto_2,'input type="hidden" name="authenticity_token" value="','"')

    headers_3 = {
    'authority': 'us.brandymelville.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'es-ES,es;q=0.9',
    'cache-control': 'max-age=0',
    'content-type': 'application/x-www-form-urlencoded',
    # 'cookie': 'checkout=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVUyTTJNd09UUmhOMlV5TUdZMU5UTm1ZVEZrTURRME5tVmhOR1V4WkRFMU5BWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOC0zMFQyMTo1MjozOS43NDZaIiwicHVyIjoiY29va2llLmNoZWNrb3V0In19--1cdb90d7f3231a57f665b451cb482af2b098e1a0; checkout_legacy=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVUyTTJNd09UUmhOMlV5TUdZMU5UTm1ZVEZrTURRME5tVmhOR1V4WkRFMU5BWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOC0zMFQyMTo1MjozOS43NDZaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X2xlZ2FjeSJ9fQ%3D%3D--72c49b118ac20a29509acbe71310b6d9aca7088c; tracked_start_checkout=980d0739537430db8c16db940404ad8d; checkout_token=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVU1T0RCa01EY3pPVFV6TnpRek1HUmlPR014Tm1SaU9UUXdOREEwWVdRNFpBWTZCa1ZVIiwiZXhwIjoiMjAyNC0wOC0wOVQyMTo1MjozOS43NDZaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X3Rva2VuIn19--f1b399cda8bae7b60f9afc7625e2f2d9586e45f3; checkout_token_legacy=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVU1T0RCa01EY3pPVFV6TnpRek1HUmlPR014Tm1SaU9UUXdOREEwWVdRNFpBWTZCa1ZVIiwiZXhwIjoiMjAyNC0wOC0wOVQyMTo1MjozOS43NDZaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X3Rva2VuX2xlZ2FjeSJ9fQ%3D%3D--0de0a0498622619e03258680211e52d6e40df172; secure_customer_sig=; localization=US; _tracking_consent=%7B%22region%22%3A%22VEF%22%2C%22reg%22%3A%22%22%2C%22con%22%3A%7B%22CMP%22%3A%7B%22a%22%3A%22%22%2C%22s%22%3A%22%22%2C%22p%22%3A%22%22%2C%22m%22%3A%22%22%7D%7D%2C%22lim%22%3A%5B%22CCPA%22%5D%2C%22v%22%3A%222.1%22%7D; _y=7fceb083-013c-4be7-bf0e-d5983ffb23ed; _s=7225bbb4-2cdd-4472-b76b-068cdc7c7a2a; _shopify_y=7fceb083-013c-4be7-bf0e-d5983ffb23ed; _shopify_s=7225bbb4-2cdd-4472-b76b-068cdc7c7a2a; _orig_referrer=; _landing_page=%2F; _shopify_sa_p=; _gid=GA1.2.704648594.1691617459; __zlcmid=1HGm2BcOOi3xogD; __kla_id=eyIkcmVmZXJyZXIiOnsidHMiOjE2OTE2MTc0NjMsInZhbHVlIjoiIiwiZmlyc3RfcGFnZSI6Imh0dHBzOi8vdXMuYnJhbmR5bWVsdmlsbGUuY29tLz9wYWdlPTEifSwiJGxhc3RfcmVmZXJyZXIiOnsidHMiOjE2OTE2MTc1MzMsInZhbHVlIjoiIiwiZmlyc3RfcGFnZSI6Imh0dHBzOi8vdXMuYnJhbmR5bWVsdmlsbGUuY29tLz9wYWdlPTEifX0=; amazon-pay-connectedAuth=connectedAuth_general; apay-session-set=aR8ugFGpUMlXZja3gxYTlrjFanv8%2F5RIeV7fR0USJSVtyziLCETJNqYwr0BAs%2BM%3D; cart=bb87f71c5a0db6969a80abb5aa76e65c; cart_currency=USD; cart_sig=0dd727ea9afe3f9a32c99a93d9f0aaf4; _shopify_ga=_ga=2.126272139.704648594.1691617459-1217410807.1691617455; cart_ts=1691617624; cart_ver=gcp-us-east1%3A4; _secure_session_id=ab3554d542e79ee8768860db17f18a2e; keep_alive=48e9caeb-8541-44c0-bcbb-9b0af7bfedf9; _cmp_a=%7B%22purposes%22%3A%7B%22a%22%3Atrue%2C%22p%22%3Atrue%2C%22m%22%3Atrue%2C%22t%22%3Atrue%7D%2C%22display_banner%22%3Afalse%2C%22merchant_geo%22%3A%22USUSNJ%22%2C%22sale_of_data_region%22%3Afalse%7D; _checkout_queue_token=AkE5ZUSiZb_HHrueYSLWXgyNwKKnVybo8qphuM6LIghuwbizCWTThP1smkKBNHeAZARU5FRVusRjYODUf-axNVBD27Qpv5pE8PygsUG7638vV6rIfrwcNeyF9eD2Ibq4wJaAYOuts5zQDCfluGRr8aKbuE90bQgraTcECulbX95qh9H6zzLh0jgVRr9m8A%3D%3D; _checkout_queue_checkout_token=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVU1T0RCa01EY3pPVFV6TnpRek1HUmlPR014Tm1SaU9UUXdOREEwWVdRNFpBWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOC0wOVQyMjo1MjozOS41NDRaIiwicHVyIjoiY29va2llLl9jaGVja291dF9xdWV1ZV9jaGVja291dF90b2tlbiJ9fQ%3D%3D--8d0fcc262a13be1a6f521eff7aa49d656788c729; _shopify_sa_t=2023-08-09T21%3A52%3A40.412Z; _ga=GA1.1.1217410807.1691617455; unique_interaction_id=7ddeaa79-ae79-4521-7473-c5674d508e30; _ga_LSSD6RDD8K=GS1.1.1691617455.1.1.1691618100.0.0.0',
    'origin': 'https://us.brandymelville.com',
    'referer': 'https://us.brandymelville.com/',
    'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Opera GX";v="100"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 OPR/100.0.0.0',
}
    data_2 = f'_method=patch&authenticity_token={token_2}&previous_step=shipping_method&step=payment_method&checkout%5Bshipping_rate%5D%5Bid%5D=shopify-FedEx%2520Ground-7.50&checkout%5Bclient_details%5D%5Bbrowser_width%5D=493&checkout%5Bclient_details%5D%5Bbrowser_height%5D=759&checkout%5Bclient_details%5D%5Bjavascript_enabled%5D=1&checkout%5Bclient_details%5D%5Bcolor_depth%5D=24&checkout%5Bclient_details%5D%5Bjava_enabled%5D=false&checkout%5Bclient_details%5D%5Bbrowser_tz%5D=240'

    req6 = session.post(url=url_2,headers=headers_3,data=data_2)

    url_3 = req6.url

    req7 = session.get(url=url_3)

    texto_3 = req7.text

    token_3 = find_between(texto_3,'input type="hidden" name="authenticity_token" value="','"')

    headers = {
    'Accept': 'application/json',
    'Accept-Language': 'es-ES,es;q=0.9',
    'Connection': 'keep-alive',
    'Content-Type': 'application/json',
    'Origin': 'https://checkout.shopifycs.com',
    'Referer': 'https://checkout.shopifycs.com/',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-site',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 OPR/100.0.0.0',
    'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Opera GX";v="100"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
}

    json_data = {
    'credit_card': {
        'number': cc,
        'name': 'andres',
        'month': mes,
        'year': ano,
        'verification_value': cvv,
    },
    'payment_session_scope': 'us.brandymelville.com',
}

    req8 = session.post('https://deposit.us.shopifycs.com/sessions', headers=headers, json=json_data).json()

    id1 = req8['id']

    headers_4 = {
    'authority': 'us.brandymelville.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'es-ES,es;q=0.9',
    'cache-control': 'max-age=0',
    'content-type': 'application/x-www-form-urlencoded',
    # 'cookie': 'checkout=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVUyTTJNd09UUmhOMlV5TUdZMU5UTm1ZVEZrTURRME5tVmhOR1V4WkRFMU5BWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOC0zMFQyMTo1NTowMi41MzZaIiwicHVyIjoiY29va2llLmNoZWNrb3V0In19--e0e55c119f5f627362f5d6f955fffbe582ccb1e1; checkout_legacy=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVUyTTJNd09UUmhOMlV5TUdZMU5UTm1ZVEZrTURRME5tVmhOR1V4WkRFMU5BWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOC0zMFQyMTo1NTowMi41MzZaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X2xlZ2FjeSJ9fQ%3D%3D--a2339b6b6ad6cb1f6b259dbbc27670b9506d2b25; tracked_start_checkout=980d0739537430db8c16db940404ad8d; checkout_token=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVU1T0RCa01EY3pPVFV6TnpRek1HUmlPR014Tm1SaU9UUXdOREEwWVdRNFpBWTZCa1ZVIiwiZXhwIjoiMjAyNC0wOC0wOVQyMTo1NTowMi41MzZaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X3Rva2VuIn19--c8bff1de8d8ff5487ca07b390d43d0e0f442791c; checkout_token_legacy=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVU1T0RCa01EY3pPVFV6TnpRek1HUmlPR014Tm1SaU9UUXdOREEwWVdRNFpBWTZCa1ZVIiwiZXhwIjoiMjAyNC0wOC0wOVQyMTo1NTowMi41MzZaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X3Rva2VuX2xlZ2FjeSJ9fQ%3D%3D--85a9d72f47692b262913b8c2cf65cd4d4da6b978; secure_customer_sig=; localization=US; _tracking_consent=%7B%22region%22%3A%22VEF%22%2C%22reg%22%3A%22%22%2C%22con%22%3A%7B%22CMP%22%3A%7B%22a%22%3A%22%22%2C%22s%22%3A%22%22%2C%22p%22%3A%22%22%2C%22m%22%3A%22%22%7D%7D%2C%22lim%22%3A%5B%22CCPA%22%5D%2C%22v%22%3A%222.1%22%7D; _y=7fceb083-013c-4be7-bf0e-d5983ffb23ed; _s=7225bbb4-2cdd-4472-b76b-068cdc7c7a2a; _shopify_y=7fceb083-013c-4be7-bf0e-d5983ffb23ed; _shopify_s=7225bbb4-2cdd-4472-b76b-068cdc7c7a2a; _orig_referrer=; _landing_page=%2F; _shopify_sa_p=; _gid=GA1.2.704648594.1691617459; __zlcmid=1HGm2BcOOi3xogD; __kla_id=eyIkcmVmZXJyZXIiOnsidHMiOjE2OTE2MTc0NjMsInZhbHVlIjoiIiwiZmlyc3RfcGFnZSI6Imh0dHBzOi8vdXMuYnJhbmR5bWVsdmlsbGUuY29tLz9wYWdlPTEifSwiJGxhc3RfcmVmZXJyZXIiOnsidHMiOjE2OTE2MTc1MzMsInZhbHVlIjoiIiwiZmlyc3RfcGFnZSI6Imh0dHBzOi8vdXMuYnJhbmR5bWVsdmlsbGUuY29tLz9wYWdlPTEifX0=; amazon-pay-connectedAuth=connectedAuth_general; apay-session-set=aR8ugFGpUMlXZja3gxYTlrjFanv8%2F5RIeV7fR0USJSVtyziLCETJNqYwr0BAs%2BM%3D; cart=bb87f71c5a0db6969a80abb5aa76e65c; cart_currency=USD; cart_sig=0dd727ea9afe3f9a32c99a93d9f0aaf4; _shopify_ga=_ga=2.126272139.704648594.1691617459-1217410807.1691617455; cart_ts=1691617624; cart_ver=gcp-us-east1%3A4; _secure_session_id=ab3554d542e79ee8768860db17f18a2e; keep_alive=48e9caeb-8541-44c0-bcbb-9b0af7bfedf9; _cmp_a=%7B%22purposes%22%3A%7B%22a%22%3Atrue%2C%22p%22%3Atrue%2C%22m%22%3Atrue%2C%22t%22%3Atrue%7D%2C%22display_banner%22%3Afalse%2C%22merchant_geo%22%3A%22USUSNJ%22%2C%22sale_of_data_region%22%3Afalse%7D; _checkout_queue_token=AvYOdo7njbQuJa8VN1XsIYd8DiRlmYFkYrlbqtUoMtUlv19uRczk8516ytAhAtTB7CFyQXkRph7bwkvZomNfyz1Q3vgs7e8__oGzmZXpx-BGz7I9n4U0DUAMpI30HLs5seNLLw81a5Nblk4uLrh1_QWiEj8vUkQ6dkap5nVHlzrI6DFCoEfjikmbInz6Xw%3D%3D; _checkout_queue_checkout_token=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVU1T0RCa01EY3pPVFV6TnpRek1HUmlPR014Tm1SaU9UUXdOREEwWVdRNFpBWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOC0wOVQyMjo1NTowMi4yMTlaIiwicHVyIjoiY29va2llLl9jaGVja291dF9xdWV1ZV9jaGVja291dF90b2tlbiJ9fQ%3D%3D--67947fd0b0ef372d330f19d0a026584bcc6c03f5; _shopify_sa_t=2023-08-09T21%3A55%3A03.507Z; _ga=GA1.1.1217410807.1691617455; unique_interaction_id=fbddd35e-70ef-44a0-44b1-f8e9fbc8b4c1; _ga_LSSD6RDD8K=GS1.1.1691617455.1.1.1691618317.0.0.0',
    'origin': 'https://us.brandymelville.com',
    'referer': 'https://us.brandymelville.com/',
    'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Opera GX";v="100"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 OPR/100.0.0.0',
}
    data_3 = f'_method=patch&authenticity_token={token_3}&previous_step=payment_method&step=&s={id1}&checkout%5Bpayment_gateway%5D=58397360292&checkout%5Bcredit_card%5D%5Bvault%5D=false&checkout%5Bdifferent_billing_address%5D=false&checkout%5Btotal_price%5D=1144&complete=1&checkout%5Bclient_details%5D%5Bbrowser_width%5D=493&checkout%5Bclient_details%5D%5Bbrowser_height%5D=759&checkout%5Bclient_details%5D%5Bjavascript_enabled%5D=1&checkout%5Bclient_details%5D%5Bcolor_depth%5D=24&checkout%5Bclient_details%5D%5Bjava_enabled%5D=false&checkout%5Bclient_details%5D%5Bbrowser_tz%5D=240'


    req9 = session.post(url=url,headers=headers_4,data=data_3)

    time.sleep(5)

    req10 = session.get(url=str(url) + '?from_processing_page=1&validate=true')

    texto_4 = req10.text

    response = find_between(texto_4,'<div class="notice__content"><p class="notice__text">','</p></div></div>')
    if '/thank_you' in str(req9.url) or '/orders/' in str(req9.url) or '/post_purchase' in str(req9.url):
     response = 'Charged'

    return response