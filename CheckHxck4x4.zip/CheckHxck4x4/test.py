from telegram import Update
from telegram.ext import Updater, CommandHandler, CallbackContext
from telegram import ChatMember
import logging

# Habilitar el registro para monitorear el comportamiento del bot
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)

# Función para obtener la lista de miembros con diferentes rangos en el grupo (excluyendo bots)
def staff(update: Update, context: CallbackContext) -> None:
    chat_id = update.effective_chat.id
    members = context.bot.get_chat_administrators(chat_id)
    
    report = "STAFF del GRUPO\n\n"
    for member in members:
        user = member.user
        status = member.status
        if status in (ChatMember.CREATOR, ChatMember.ADMINISTRATOR, "Cofundador", ChatMember.MEMBER, ChatMember.RESTRICTED, ChatMember.LEFT) and not user.is_bot:
            if status == ChatMember.CREATOR:
                report += f"👑 Fundador \n@{user.username}\n"
            elif status == ChatMember.ADMINISTRATOR:
                report += f"🛡️ Administrator: \n@{user.username}\n"
            elif status == "Cofundador":
                report += f"🤝 Cofounder: \n@{user.username}\n"
    if report == "Miembros con diferentes rangos en el grupo:\n":
        report += "No se encontraron miembros con diferentes rangos en el grupo."
    update.message.reply_text(report)

# Configuración del bot y manejo del comando /staff
updater = Updater("7800628210:AAFUkWQFotmJbsCjqS0alWkrvslfG9xpjd0", use_context=True)
dispatcher = updater.dispatcher
dispatcher.add_handler(CommandHandler("staff", staff))

# Inicio del bot
updater.start_polling()
updater.idle()
