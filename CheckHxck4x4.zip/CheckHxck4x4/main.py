from pyrogram.types import (
    Message,
    InlineKeyboardButton,
    InlineKeyboardMarkup
)

from pyrogram import Client, filters
import logging
import signal
import subprocess
import os
import sys
from pyrogram.errors import RPCError, BadRequest
from mongoDB import *  

logging.basicConfig(level=logging.INFO)

logo = """
████   ██████ ██       ██   ████████    ██
██  ██   ██     ██   ██     ██          ██
████     ██       ███       ████████    ██
██       ██      ██  ██     ██          ██
██     ██████  ██      ██   ████████    ██████
██████████████████████████████████████████████████████            
"""

print(logo)

# Crea una instancia del cliente Pyrogram
app = Client(
    'CheckHxck_Bot',
    api_id='29655078',
    api_hash='1e1ec9d727f5fe3db95cd65bba405518',
    bot_token='7773767662:AAFKt1BJoFdMed20bpZbO_Cqv6rqpwWhs7U',
    plugins=dict(root="gates"),
)

staff_group_id = -1002412491185, -1002280989123
referencia_channel_id = -1002412491185
        
@app.on_message(filters.command("msg"))
async def msg_command(client, message):
    if len(message.command) > 1:
        mensaje = " ".join(message.command[1:])
        usuarios = collection.find({})
        keyboard = InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton("Canal", url="https://t.me/7800628210"),
                ]
            ]
        )
        
        for usuario in usuarios:
            user_id = usuario["_id"]
            try:
                await app.send_message(chat_id=user_id, text=mensaje, reply_markup=keyboard)
            except Exception as e:
                logging.error(f"No se pudo enviar el mensaje a {user_id}: {str(e)}")

        await message.reply_text("El mensaje ha sido enviado a todos los usuarios registrados como parte del broadcast.")
    else:
        await message.reply_text("Uso incorrecto del comando. Por favor, proporciona un mensaje válido.")

@app.on_message(filters.command(["referencia", "refe"]))
async def referencia_command(client, message):
    if message.reply_to_message and message.reply_to_message.photo:
        # Obtener la foto o imagen enviada como respuesta
        photo = message.reply_to_message.photo.file_id
        mensaje = " ".join(message.command[1:]) if len(message.command) > 1 else "Sin mensaje"
        
        # Enviar la foto o imagen al grupo del personal con los appones de aprobación y denegación
        await app.send_photo(
            chat_id=staff_group_id,
            photo=photo,
            caption=f"""<b>𝙿𝚒𝚡𝚎𝚕 𝙲𝚑𝚔  | 𝗥𝗲𝗳𝗲𝗿𝗲𝗻𝗰𝗶𝗮𝘀
━━━━━━༺༻ ━━━━━━
⚘ User ID ➤ [<a href="https://t.me/{message.from_user.username}">{message.from_user.id}</a>]
━━━━━━༺༻ ━━━━━━
⚘ Message ➤ {mensaje}
━━━━━━༺༻ ━━━━━━</b>"""
        )
        await message.reply_text("Muchas gracias por tu referencia Del chk")
        
    else:
        await message.reply_text("Uso incorrecto del comando. Por favor, responde a una foto o imagen para enviarla al personal. Ejemplo: /refe Mensaje")

@app.on_message(filters.command("reinicio"))
async def reinicio_command(client, message):
    buscar_permisos = collection.find_one({"_id": message.from_user.id})
    if buscar_permisos is None:
        return await message.reply(text='<b>No estás registrado en mi base de datos. Usa /register</b>', quote=True)

@app.on_message(filters.command("mycommand"))
async def my_command(client, message):
    if not is_admin(message.from_user.id):
        return await message.reply(
            text='<b>Solo los administradores pueden usar este comando.</b>',
            quote=True
        )
    

    await message.reply_text("Reiniciando la aplicación... Por favor, espera un momento.")
    python = sys.executable
    subprocess.Popen([python] + sys.argv)
    os.kill(os.getpid(), signal.SIGINT)

def handle_signal(signal, frame):
    app.stop()
    sys.exit(0)

signal.signal(signal.SIGINT, handle_signal)

app.run()