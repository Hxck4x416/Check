import os

# Ruta al directorio donde están los archivos
directorio = '/storage/emulated/0/Pixel_Chk/gates/'

# Asegúrate de que la ruta existe antes de continuar
if not os.path.exists(directorio):
    print(f"La ruta {directorio} no existe.")
else:
    # Texto exacto que deseas buscar y reemplazar
    texto_a_reemplazar = 'Bienvenido a 𝙿𝚒𝚡𝚎𝚕 𝙲𝚑𝚔 Puedes iniciarme usando /cmds'

    # Nuevo texto que reemplazará el anterior
    nuevo_texto = 'Bienvenido a Hxck Chk Puedes iniciarme usando /cmds'

    # Recorre todo el directorio, incluidos los subdirectorios
    for carpeta_raiz, subcarpetas, archivos in os.walk(directorio):
        for archivo in archivos:
            # Solo selecciona archivos con extensión .py
            if archivo.endswith(".py"):
                ruta_archivo = os.path.join(carpeta_raiz, archivo)
                
                # Abre el archivo en modo lectura
                with open(ruta_archivo, 'r', encoding='utf-8') as file:
                    contenido = file.read()
                
                # Verifica si el texto exacto está en el contenido
                if texto_a_reemplazar in contenido:
                    print(f"Texto encontrado en {archivo}. Procediendo con el reemplazo.")
                    
                    # Reemplaza el texto
                    nuevo_contenido = contenido.replace(texto_a_reemplazar, nuevo_texto)
                    
                    # Si hay cambios, guarda el archivo
                    with open(ruta_archivo, 'w', encoding='utf-8') as file:
                        file.write(nuevo_contenido)
                    print(f"Reemplazo realizado en: {archivo}")
                else:
                    print(f"El texto no se encontró en {archivo}. No se hizo ningún reemplazo.")

print("Proceso completado.")